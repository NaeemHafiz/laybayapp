<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Memberslib
{
	var $CI;

	function Memberslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	// Function to get members from database
	//
	// Parameters:
	//
	// 	resultStr 	-  a string containing an error message
	//  
	// Returns:
	//
	// 	members array	- in case of success return object array
	// 	0 				- in case of error

	function getMembers($status, $start = "", $offset = "", $search = "",  $sort_col = "", $sort_dir = "")
	{
		$CI = &get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("up.first_name","up.email","ut.name");

		$limit = $search_q = $status_q = "";
		$sort_q = " ORDER BY up.first_name ";

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(up.first_name) LIKE '%".strtolower($search)."%' OR LOWER(up.last_name) LIKE '%".strtolower($search)."%' OR LOWER(up.email) LIKE '%".strtolower($search)."%' OR LOWER(ut.name) LIKE '%".strtolower($search)."%')";
		}

		// First time no dev is selected
		if ($status != 'all')
		{
			$status_q = " AND u.active = ".$CI->db->escape($status)." "; 
		}

		$query  = "SELECT u.id, up.first_name, up.last_name, up.email, u.active, ut.name FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.deleted = 'no' AND u.type_id != '4' and u.type_id != '1' ".$status_q.$search_q.$sort_q.$limit;
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	// Function to add member
	//
	// Parameters:
	//
	//  username 		- id of member
	//  password 		- id of member
	//  type 	 		- id of member
	//  first_name 		- id of member
	//  last_name 		- id of member
	//  email 	 		- id of member
	//  avatar  		- id of member
	//  telephone 		- id of member
	//  hourly_rate		- id of member
	//  company 		- id of member
	//  country 		- id of member
	//  city 	 		- id of member
	//  
	// Returns:
	//
	// 	1				- in case of success
	// 	0 				- in case of error

	function addMember($username, $password, $type, $first_name, $last_name, $email, $avatar, $phone, $hrate, $company, $homepage, $country, $city)
	{
		$CI = &get_instance();

		$q1 = "INSERT INTO ".$CI->db->dbprefix('user')." (username, password, type_id) 
				VALUES (
					".$CI->db->escape($username).",
					'".md5($password)."',
					".$CI->db->escape($type)."
					)";

		$CI->db->query($q1);
		$user_id = $CI->db->insert_id();

		if ($user_id != null && $user_id != "" && $user_id != 0)
		{
			if (strlen($hrate) > 0)
			{
				$hourly_rate_up = 'hourly_rate ,';
				$hourly_rate 	= " ".$CI->db->escape($hrate).", ";
			}
			else
			{
				$hourly_rate_up = '';
				$hourly_rate 	= '';
			}

			if (strlen($avatar) > 0)
			{
				$avatar_up 	= 'picture, ';
				$avatar 	= " ".$CI->db->escape($hrate).", ";
			}
			else
			{
				$avatar_up 	= '';
				$avatar 	= '';
			}

			$q2 = "INSERT INTO ".$CI->db->dbprefix('user_profile')." (user_id, first_name, last_name, create_date, email, ".$avatar_up." telephone, ".$hourly_rate_up." comp_name, homepage, id_country, city) VALUES (
				".$user_id.",
				".$CI->db->escape($first_name).",
				".$CI->db->escape($last_name).",
				'".date("Y-m-d")."',
				".$CI->db->escape($email).",
				".$avatar."
				".$CI->db->escape($phone).",
				".$hourly_rate."
				".$CI->db->escape($company).",
				".$CI->db->escape($homepage).",
				".$CI->db->escape($country).",
				".$CI->db->escape($city)."
				) ";

			$result = $CI->db->query($q2);

			if ($CI->db->affected_rows())
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}

	// Function to delete member
	//
	// Parameters:
	//
	//  id 			- id of member
	// 	resultStr 	- a string containing an error message
	//  
	// Returns:
	//
	// 	1				- in case of success
	// 	0 				- in case of error

	function deleteMember($id)
	{
		$CI = &get_instance();

		$query  = "UPDATE ".$CI->db->dbprefix('user')." u SET active = 'no' WHERE u.id = '".$id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete member from database
	//
	// Parameters:
	//
	//  id 			- id of member
	// 	resultStr 	- a string containing an error message
	//  
	// Returns:
	//
	// 	1				- in case of success
	// 	0 				- in case of error

	function deleteMemberFromDatabase($id)
	{
		$CI = &get_instance();

		// Delete tickets+settings when client is deleted
		$qs = "SELECT * FROM ticket_settings WHERE client_id = '".$id."'";
		$result = $CI->db->query($qs);

		if ($result->num_rows() > 0)
		{
			foreach ($result->result() as $key => $value) 
			{
				$CI->db->query("DELETE FROM tickets WHERE settings_id = '".$value->settings_id."'");
			}
		}

		$q0 = "DELETE FROM ".$CI->db->dbprefix('ticket_settings')." WHERE client_id = '".$id."'";

		// Delete member/client data
		$q1 = "DELETE FROM ".$CI->db->dbprefix('transactions')." WHERE user_id = ".$id;
		$q2 = "DELETE FROM ".$CI->db->dbprefix('task_assigned')." WHERE user_id = ".$id;
		$q3 = "DELETE FROM ".$CI->db->dbprefix('user_profile')." WHERE user_id = ".$id;
		$q4 = "DELETE FROM ".$CI->db->dbprefix('project_view')." WHERE user_id = ".$id;
		$q5 = "DELETE FROM ".$CI->db->dbprefix('user')." WHERE id = ".$id;

		$r0 = $CI->db->query($q0);
		$r1 = $CI->db->query($q1);
		$r2 = $CI->db->query($q2);
		$r3 = $CI->db->query($q3);
		$r4 = $CI->db->query($q4);
		$r5 = $CI->db->query($q5);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to get member info
	//
	// Parameters:
	//
	//  id 			- id of member
	// 	resultStr 	- a string containing an error message
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function getMemberInfo($id)
	{
		$CI = & get_instance();
		
		$query = "SELECT ut.name as type, up.hourly_rate, u.username, up.first_name, up.last_name, up.email, up.telephone, up.receive_email u.active, up.picture, ut.name as user_type FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON up.user_id = u.id LEFT JOIN user_type ut ON u.type_id = ut.id WHERE u.id = '".$id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Save member modifications by admin
	// Parameters:
	//
	//  id 			- id of member
	//  username 	- username
	//  password 	- password
	//  firstname 	- firstname
	//  lastname 	- lastname
	//  email 		- email
	//  telephone 	- telephone
	//  state 	 	- active or inactive
	//  picture 	- profile pic path
	//  hourly_rate	- hourly rate
	//  type 		- type
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	// function saveMemberModifications($id, $username, $password, $firstname, $lastname, $email, $telephone, $state, $picture, $hourly_rate, $type)
	// {
	// 	$CI = & get_instance();

	// 	if (strlen($password) > 0)
	// 		$passw = " u.password = '".md5($password)."', ";
	// 	else
	// 		$passw = "";

	// 	if (strlen($picture) > 0)
	// 		$pic = " up.picture = ".$CI->db->escape($picture).", ";
	// 	else
	// 		$pic = ""

	// 	$query  = "UPDATE user u,user_profile up,user_type ut SET u.username=".$CI->db->escape($username).", ".$passw." u.active=".$CI->db->escape($state).", up.first_name=".$CI->db->escape($firstname).", up.last_name=".$CI->db->escape($lastname).", up.email=".$CI->db->escape($email).", ".$pic." up.telephone=".$CI->db->escape($telephone).", up.hourly_rate=".$CI->db->escape($hourly_rate).", u.type_id=".$CI->db->escape($type)." WHERE u.id='".$id."' AND up.user_id='".$id."'";
	// 	$result = $CI->db->query($query);

	// 	if ($CI->db->affected_rows() > 0)
	// 	{
	// 		return 1;
	// 	}
	// 	else
	// 	{
	// 		return 0;
	// 	}
	// }
}
?>