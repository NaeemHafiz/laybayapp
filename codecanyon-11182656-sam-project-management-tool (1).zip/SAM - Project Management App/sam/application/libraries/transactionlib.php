<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transactionlib
{
	var $CI;

	function Transactionlib()
	{
		$CI=& get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	function addTransaction($user_id, $title, $estimated_hours, $balance)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('transactions')." (user_id, transaction_date, title, debit, credit, balance) VALUES (".$CI->db->escape($user_id).", '".date('Y-m-d H:i:s')."', ".$CI->db->escape($title).", 0, ".$CI->db->escape($estimated_hours).", ".$CI->db->escape($balance).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getUserTransactions($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('transactions')." WHERE user_id = ".$user_id." ORDER BY id DESC";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function CashOutTransaction($user_id, $title, $cash_out, $balance)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('transactions')." (user_id, transaction_date, title, debit, credit, balance) VALUES (".$CI->db->escape($user_id).", '".date('Y-m-d H:i:s')."', ".$CI->db->escape($title).", ".$CI->db->escape($cash_out).", '0', ".$CI->db->escape($balance).")";
		$result = $CI->db->query($query);
		
		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function addBonusToDeveloper($user_id, $amount)
	{
		$CI 	= & get_instance();
		$q 		= "SELECT * FROM ".$CI->db->dbprefix('user_profile')." WHERE user_id = ".$CI->db->escape($user_id);
		$res 	= $CI->db->query($q);

		if ($res->num_rows > 0)
		{
			$query = "UPDATE ".$CI->db->dbprefix('user_profile')." SET balance = ".($amount + $res->row()->balance)." WHERE user_id = ".$CI->db->escape($user_id);
			$CI->db->query($query);
			
			if ($CI->db->_error_message())
			{
				return 0;
			}
			else
			{
				$text = "Bonus Received";
				
				$query_transactions = "INSERT INTO ".$CI->db->dbprefix('transactions')."(user_id, transaction_date, title, debit, credit, balance) VALUES(".$CI->db->escape($user_id).", '".date("Y-m-d h:i:s")."', '".$text."', 0, ".$amount.", ".($amount+$res->row()->balance).")";
				$CI->db->query($query_transactions);

				if ($CI->db->affected_rows() > 0)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		else
		{
			return 0;
		}
	}
}
?>