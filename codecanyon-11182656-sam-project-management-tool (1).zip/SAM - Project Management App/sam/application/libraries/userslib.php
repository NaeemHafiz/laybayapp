<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Userslib
{
	var $CI;

	function Userslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	// Function to add a new user
	//
	// Parameters:
	//
	// 	username 	-  username string
	// 	password 	-  password string
	// 	type_id 	-  user types are stored here 
	//
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function addUser($username, $password, $type_id)
	{
		$CI = &get_instance();
		$md5variable = md5($password);

		$query = "INSERT INTO ".$CI->db->dbprefix('user')." (username, password, type_id) VALUES (".$CI->db->escape($username).", ".$CI->db->escape($md5variable).", ".$CI->db->escape($type_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $this->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to check if a user exists
	//
	// Parameters:
	//
	// 	username 	-  username string
	//
	// Returns:
	//
	//	1 			- if user exists
	//	0 			- if user does not exist

	function checkUsernameExists($username, $user_id)
	{
		$CI = &get_instance();

		if ($user_id > 0)
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE username = ".$CI->db->escape($username)." AND id != ".$CI->db->escape($user_id)." ";
		}
		else
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE username = ".$CI->db->escape($username)."";
		}

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to check if email exists
	//
	// Parameters:
	//
	// email 	 	- email string
	//
	// Returns:
	//
	//	1 			- if user exists
	//	0 			- if user does not exist

	function checkEmailExists($email, $user_id)
	{
		$CI = &get_instance();

		if ($user_id > 0)
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('user_profile')." WHERE email = ".$CI->db->escape($email)." AND user_id != ".$CI->db->escape($user_id)." ";
		}
		else
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('user_profile')." WHERE email = ".$CI->db->escape($email)."";
		}

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to user
	//
	// Parameters:
	//
	// 	username  		-  username string
	// 	password 		-  password string
	// 	type_id 		-  user types are stored here 
	// 	status_active 	-  active or not
	//
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function modifyUser($member_id, $cpword, $user_type, $status_active="no")
	{
		$CI = &get_instance();

		$password = "";

		if (strlen($cpword) > 0)
		{
			$md5pass = md5($cpword);
			$password = "password = '".$md5pass."', ";
		}

		$query = "UPDATE ".$CI->db->dbprefix('user')." SET ".$password." type_id = ".$CI->db->escape($user_type).", active = ".$CI->db->escape($status_active)." WHERE id = ".$member_id."";

		$result = $CI->db->query($query);

		return 1;
	}

	// Function to user
	//
	// Parameters:
	//
	// 	username  		-  username string
	// 	password 		-  password string
	// 	type_id 		-  user types are stored here 
	// 	status_active 	-  active or not
	//
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function modifyStaff($member_id, $verif, $username, $cpword, $user_type, $status_active="no")
	{
		$CI = &get_instance();

		if ($verif == 1)
		{
			$md5pass = md5($cpword);
			$query = "UPDATE ".$CI->db->dbprefix('user')." SET username = ".$CI->db->escape($username).", password = ".$CI->db->escape($md5pass).", type_id = ".$CI->db->escape($user_type).", active = ".$CI->db->escape($status_active)." WHERE id = ".$member_id."";
		}
		else
		{
			$query = "UPDATE ".$CI->db->dbprefix('user')." SET username = ".$CI->db->escape($username).", type_id = ".$CI->db->escape($user_type).", active = ".$CI->db->escape($status_active)." WHERE id = ".$member_id."";
		}

		$result = $CI->db->query($query);

		return 1;
	}

	// Function to delete user
	//
	// Parameters:
	//
	// 	id 		 	- user id
	//  
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function deleteUser($id)
	{
		$CI = &get_instance();

		$query = "DELETE FROM ".$CI->db->dbprefix('user')." WHERE id = '".$id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete client
	//
	// Parameters:
	//
	// 	id 		 	- user id
	//  
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function deleteClientDefinitely($id)
	{
		$CI = &get_instance();
		$q2 = "DELETE FROM ".$CI->db->dbprefix('user_profile')." WHERE user_id = '".$id."'";

	}

	// Function to activate user
	//
	// Parameters:
	//
	// 	id 			- user id
	//  
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function activateUser($id)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." SET activ = 'yes' WHERE id = '".$id."' ";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to deactivate user
	//
	// Parameters:
	//
	// 	id 			- user id
	//  
	// Returns:
	//
	//	1 			- in case of success
	//	0 			- in case of error

	function deactivateUser($id)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." SET activ = 'no' WHERE id = '".$id."' ";
		$result = mysql_query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to add new user profile.
	//
	// Parameters:
	//
	// 	first_name  	-  first_name string
	// 	last_name 		-  last_name string
	// 	email 			-  email string
	// 	telephone 		-  telephone int
	// 	hourly_rate 	-  hourly_rate int
	//  
	// Returns:
	//
	// 	1 				- return id of aded user profile
	// 	0 				- in case of error

	function addUserProfile($user_id, $first_name, $last_name, $email, $telephone, $hourly_rate)
	{
		$CI = & get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('user_profile')." (user_id, first_name, last_name, create_date, email, telephone, hourly_rate)
				    VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($first_name).", ".$CI->db->escape($last_name).", '".date("Y-m-d")."', ".$CI->db->escape($email).", ".$CI->db->escape($telephone).", ".$CI->db->escape($hourly_rate).")";
				    
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $this->db->insert_id();
		}
		else
		{
			return 0;
		}
	} 

	// Function to modify user profile.
	//
	// Parameters:
	//
	// 	first_name 		-  first_name string
	// 	last_name    	-  last_name string
	// 	email        	-  email string
	// 	telephone    	-  telephone int
	// 	hourly_rate  	-  hourly_rate int
	//  
	// Returns:
	//
	// 	1 				- in case of success
	// 	0 				- in case of error

	function modifyUserProfile($member_id, $fname, $lname, $email, $paypal_account, $phone, $cname, $homepage, $country, $city, $rcv_email, $rcv_notif)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user_profile')." SET first_name = ".$CI->db->escape($fname).", last_name = ".$CI->db->escape($lname).",
				email = ".$CI->db->escape($email).", paypal_account = ".$CI->db->escape($paypal_account).", telephone = ".$CI->db->escape($phone).", comp_name = ".$CI->db->escape($cname).", homepage = ".$CI->db->escape($homepage).", id_country = ".$CI->db->escape($country).", city = ".$CI->db->escape($city).", receive_email = ".$CI->db->escape($rcv_email).", receive_notifications = ".$CI->db->escape($rcv_notif)." WHERE user_id = ".$member_id."";
		$result = $CI->db->query($query);

		return 1;
	}

	// Function to modify user profile.
	//
	// Parameters:
	//
	// 	first_name 		-  first_name string
	// 	last_name    	-  last_name string
	// 	email        	-  email string
	// 	telephone    	-  telephone int
	// 	hourly_rate  	-  hourly_rate int
	//
	// Returns:
	//
	// 	1 				- in case of success
	// 	0 				- in case of error

	function modifyStaffProfile($member_id, $fname, $lname, $email, $phone, $hrate, $cname, $homepage, $country, $city)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user_profile')." SET first_name = ".$CI->db->escape($fname).", last_name = ".$CI->db->escape($lname).", email = ".$CI->db->escape($email).", telephone = ".$CI->db->escape($phone).", hourly_rate = ".$CI->db->escape($hrate).", comp_name = ".$CI->db->escape($cname).", homepage = ".$CI->db->escape($homepage).", id_country = ".$CI->db->escape($country).", city = ".$CI->db->escape($city)." WHERE user_id = ".$member_id."";
		$result = $CI->db->query($query);

		return 1;
	}

	// Function to get user from database
	//
	// Parameters:
	//
	//  
	// Returns:
	//
	// 	1 			- in case of success return object array
	// 	0 			- in case of error

	function getUsers()
	{
		$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE deleted = 'no'";
		$result = mysql_query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get user from database after id
	//
	// Parameters:
	//
	// 	id 			-  user id
	//  
	// Returns:
	//
	// 	1 			- in case of success return object array
	// 	0 			- in case of error

	function getUserData($id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE id = ".$id."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Function to get user from database after id
	//
	// Parameters:
	//
	// 	resultStr 	-  a string containing an error message
	//  
	// Returns:
	//
	// 	1 			- in case of success return object array
	// 	0 			- in case of error

	function getUserNames($id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user_profile')." WHERE user_id = ".$id."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Function to get user types from database
	//
	// Parameters:
	//  
	// Returns:
	//	1			- in case of success return object array
	//	0 			- in case of error

	function getUserTypes($order_asc)
	{
		$CI = &get_instance();

		$sql_order = "";
		if ($order_asc == "yes")
		{
			$sql_order = "ORDER BY name";
		}

		$query = "SELECT * FROM ".$CI->db->dbprefix('user_type')." ".$sql_order." ";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to update user types from database
	//
	// Parameters:
	//  
	// Returns:
	//	1			- in case of success return object array
	//	0 			- in case of error

	function updateUserTypes($id, $new_user_type)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user_type')." SET name = ".$CI->db->escape($new_user_type)." WHERE id = ".$id." ";
		$result = $CI->db->query($query);

		return 1;
	}

	// Function to get user types without client
	//
	// Parameters:
	//  
	// Returns:
	//	1			- in case of success return object array
	//	0 			- in case of error

	function getUserTypesWithoutClient()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user_type')." WHERE id != 4 ORDER BY name";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to log in
	//
	// Parameters:
	//
	// 	username 	- user
	//  password 	- password
	//  
	// Returns:
	//	1 			- in case of successfully log in
	//	0			- in case of error

	function userLogin($username, $password)
	{
		$CI = &get_instance();
		$CI->load->library('session');

		$query = "SELECT u.id, u.username, u.password, u.type_id FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.active='yes' AND u.username = ".$CI->db->escape($username)."";

		$result = $CI->db->query($query);
		$count  = $result->num_rows();
		$md5 = md5($password);

		if ($count > 0)
		{
			$res = $result->row();

			if ($md5 == $res->password)
			{
				$session_vars = array(
					'user_id'  	=> $res->id,
					'username'  => $res->username,
					'password'  => $res->password,
					'user_type' => $res->type_id
               	);

				$CI->session->set_userdata($session_vars);

				return 1;
			}
		}
		else
		{
			return 0;
		}
	}

		// Function to log in
	//
	// Parameters:
	//
	// 	username 	- user
	//  password 	- password
	//  
	// Returns:
	//	1 			- in case of successfully log in
	//	0			- in case of error

	function userLoginFromCookie($username, $password)
	{
		$CI = &get_instance();
		$CI->load->library('session');

		$query = "SELECT u.id, u.username, u.password, u.type_id FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.username = ".$CI->db->escape($username)."";

		$result = $CI->db->query($query);
		$count  = $result->num_rows();
		$username = stripslashes($username);
		$username = mysql_real_escape_string($username);

		if ($count > 0)
		{
			$res = $result->row();

			if ($password == $res->password)
			{
				$session_vars = array(
					'user_id'  	=> $res->id,
					'username'  => $res->username,
					'password'  => $res->password,
					'user_type' => $res->type_id
               	);

				$CI->session->set_userdata($session_vars);

				return 1;
			}
		}
		else
		{
			return 0;
		}
	}

	// Function to log out
	//
	// Parameters:
	//  
	// unset the session variables

	function userLogout()
	{
		$CI = &get_instance();

		$session_vars = array(
					'user_id'  	=> '',
					'username'  => '',
					'password'  => '',
					'user_type' => ''
		);

		$CI->session->unset_userdata($session_vars);
		$CI->session->sess_destroy();
	}

	// Function to check user login status
	//
	// Parameters:
	//
	// Returns:
	//	1				- user logged in
	//	0				- user not logged in

	function checkLoggedUser()
	{
		$CI = &get_instance();

		$user_id = $this->session->userdata('user_id');
		$username = $this->session->userdata('username');
		$password = $this->session->userdata('password');
		$user_type = $this->session->userdata('user_type');

		if (isset($user_id) and isset($username) and isset($password) and isset($user_type))
		{
			$query = "SELECT u.id, u.username, u.password, u.type_id FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.id = '".$user_id."'";
			$result = $CI->db->query($query);

			$res = $rezult->row();

			if ($user_id == $res->id)
			{
				if ($username == $res->username)
				{
					if ($password == $res->password)
					{
						if ($user_type == $res->type_id)
						{
							return 1;
						}
						else
						{
							return 0;
						}
					}
					else 
					{
						return 0;
					}
				}
				else
				{
					return 0;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}

	// Function to get project manager names
	//
	// Parameters:
	//
	// Returns:
	//	obj array		- in case of success
	//	0				- in case of fail

	function getProjectManagerNames()
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.last_name, up.first_name FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE ut.id = 2 AND u.active = 'yes' ORDER BY up.first_name ASC";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get developer names
	//
	// Parameters:
	//	active 	- yes/no/all
	//
	// Returns:
	//	obj array		- in case of success
	//	0				- in case of fail

	function getDeveloperNames($active="all")
	{
		$CI = &get_instance();

		$w_active = "";

		if ($active != "all")
		{
			$w_active = " AND u.active='".$active."'";
		}

		$query = "SELECT up.user_id, up.last_name, up.first_name FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE ut.id = 3 ".$w_active." ORDER BY LOWER(up.first_name), LOWER(up.last_name)";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get client names
	//
	// Parameters:
	//
	// Returns:
	//	object Array	- in case of success
	//	0				- in case of fail

	function getClientNames()
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.last_name, up.first_name FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE ut.id = 4 AND u.active = 'yes' ORDER BY up.first_name ASC";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get available users
	//
	// Parameters:
	//
	// Returns:
	//	object array 	- in case of success
	//	0				- in case of fail

	function getAvailableUsers()
	{
		$CI = &get_instance();

		$query = "SELECT u.id, up.first_name, up.last_name FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON u.id = up.user_id WHERE ut.id = 3 OR ut.id = 2 ORDER BY up.first_name";

		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get client data
	//
	// Parameters:
	//  $project_id     -identify client projects
	//
	// Returns:
	//	object Array	- in case of success
	//	0				- in case of fail

	function getClientData($project_id)
	{
		$CI = &get_instance();

		$query  = "SELECT t.name, t.description, t.create_date, t.complete_date FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id WHERE p.id = '".$project_id."' AND p.deleted ='no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get Project Manager data
	//
	// Parameters:
	//	userId 			- user to be selected
	//
	// Returns:
	//	object Array	- in case of success
	//	0				- in case of fail

	function getPManagerProjectData()
	{
		$CI = &get_instance();

		$query = "SELECT p.name, p.description, p.id, p.end_date FROM ".$CI->db->dbprefix('project_view')." pv LEFT JOIN ".$CI->db->dbprefix('project')." p ON pv.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('user')." u ON pv.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE p.deleted = 'no' AND ut.id = 2";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get developer data
	//
	// Parameters:
	//  $user_id		- identify user type
	//
	// Returns:
	//	object array 	- in case of success
	//	0				- in case of fail

	function getDeveloperData($user_id)
	{
		$CI = &get_instance();

		$query  = "SELECT a.name, a.description, a.create_date, a.complete_date FROM ".$CI->db->dbprefix('task')." a
				 LEFT JOIN ".$CI->db->dbprefix('task_assigned')." b ON b.task_id = a.id
				 LEFT JOIN ".$CI->db->dbprefix('user')." c ON b.user_id = c.id WHERE c.id = '".$user_id."' and c.deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get admin data
	//
	// Parameters:
	//
	// Returns:
	//	object Array 	- in case of success
	//	0				- in case of fail

	function getAdminData()
	{
		$CI = &get_instance();

		$query = "SELECT p.name, p.description, p.create_date, p.end_date FROM ".$CI->db->dbprefix('project')." p LEFT JOIN ".$CI->db->dbprefix('task')." t ON t.project_id = p.id WHERE t.deleted = 'no'";
		$result = mysql_query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get user types
	//
	// Parameters:
	//	userId 			- id of user
	//
	// Returns:
	//	user type		- in case of success
	//	0				- in case of fail

	function getUserType($userId)
	{
		$CI = &get_instance();

		$query = "SELECT name FROM ".$CI->db->dbprefix('user_type')." ut LEFT JOIN ".$CI->db->dbprefix('user')." u ON ut.id = u.type_id WHERE u.id = '".$userId."')";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to verify user privileges
	//
	// Parameters:
	//	userId 			- id of user
	//  user_type_id    - user type
	//
	// Returns:
	//	privileges		- in case of success
	//	0				- in case of fail

	function checkUserPriviliges($user_id, $user_type_id)
	{
		$CI = &get_instance();

		// Admin
		if ($user_type_id == 1)
		{
			$output["edit"] = "true";
			$output["delete"] = "true";
		}

		// Project Manager
		if ($user_type_id == 2)
		{
			$obj = getProjectPManager($this->session->userdata("user_id"), $resultStr);

			if ($obj->project_id < 0)
			{
				$output["edit"] = "false";
				$output["delete"] = "false";
			}
			else
			{
				$output["edit"] = "true";
				$output["delete"] = "true";
			}
		}

		// Developer
		if ($user_type_id == 3)
		{
			$output["edit"] = "false";
			$output["delete"] = "false";
		}

		// Client
		if ($user_type_id == 4)
		{
			$obj = getProjectClient($this->session->userdata("user_id"), $resultStr);

			if ($obj->project_id < 0)
			{
				$output["edit"] = "false";
				$output["delete"] = "false";
			}
			else
			{
				$output["edit"] = "true";
				$output["delete"] = "false";
			}
		}

		return $output;
	}

	// Function to check user privileges over projects
	//
	// Parameters:
	//	userId 			- id of user
	//  user_type_id    - user type
	//
	// Returns:
	//	user type		- in case of success
	//	0				- in case of fail

	function checkUserPriviligesForProjects($user_id, $user_type_id)
	{
		$CI = & get_instance();
		$output = array();

		// Admin
		if ($user_type_id == 1)
		{
			$output["edit"] = "true";
			$output["delete"] = "true";
		}

		// Project Manager
		if ($user_type_id == 2)
		{
			$obj = getProjectPManager($user_id, $resultStr);

			if ($obj->project_id < 0)
			{
				$output["edit"] = "false";
				$output["delete"] = "false";
			}
			else
			{
				$output["edit"] = "true";
				$output["delete"] = "true";
			}
		}

		// Developer
		if ($user_type_id == 3)
		{
			$output["edit"] = "false";
			$output["delete"] = "false";
		}

		// Client
		if ($user_type_id == 4)
		{
			$output["edit"] = "false";
			$output["delete"] = "false";
		}

		return $output;
	}

	// Function to get user password from database
	//
	// Parameters:
	//
	//	user_id 	- user id
	//  
	// Returns:
	//	1			- in case of success return object array
	//	0 			- in case of error

	function getPassword($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT password FROM ".$CI->db->dbprefix('user')." WHERE id = '".$user_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get members from database
	//
	// Parameters:
	//  
	// Returns:
	//
	// 	members array	- in case of success return object array
	// 	0 				- in case of error

	function getMembers()
	{
		$CI = &get_instance();

		$query = "SELECT u.id, up.first_name, up.last_name, up.email, ut.name FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to delete member from database
	//
	// Parameters:
	//
	//  id 			- id of member
	//  
	// Returns:
	//
	// 	1				- in case of success
	// 	0 				- in case of error

	function deleteMember($id, &$resultStr)
	{
		$CI = &get_instance();

		$query  = "UPDATE ".$CI->db->dbprefix('user')." u SET u.deleted = 'yes', active = 'no' WHERE u.id = '".$id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get member info
	//
	// Parameters:
	//
	//  id 				- id of member
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function getMemberInfo($id)
	{
		$CI = & get_instance();

		$query = "SELECT ut.name as type, u.username, up.user_id, up.first_name, up.last_name, up.email, up.paypal_account, up.telephone, up.homepage, u.active, up.picture, up.comp_name, up.id_country, up.city, up.receive_email, up.receive_notifications FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON up.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE u.id = '".$id."'";
		$result = $CI->db->query($query);
		
		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Save member modifications by admin
	// Parameters:
	//
	//  id 			- id of member
	//  username 	- username
	//  firstname 	- firstname
	//  lastname 	- lastname
	//  email 		- email
	//  telephone 	- telephone
	//  state 	 	- active or inactive
	//  picture 	- profile pic path
	//  hourly_rate	- hourly rate
	//  type 		- type
	//  password	- new pssword
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function saveMemModif($id, $username, $firstname, $lastname, $email, $telephone, $state, $picture, $hourly_rate, $type, $password)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." u, ".$CI->db->dbprefix('user_profile')." as up, ".$CI->db->dbprefix('user_type')." ut SET u.username = ".$CI->db->escape($username).", u.password = ".$CI->db->escape(md5($password)).", u.active = ".$CI->db->escape($state).", up.first_name = ".$CI->db->escape($firstname).", up.last_name = ".$CI->db->escape($lastname).", up.email = ".$CI->db->escape($email).", up.picture = ".$CI->db->escape($picture).", up.telephone = ".$CI->db->escape($telephone).", up.hourly_rate = ".$CI->db->escape($hourly_rate).", u.type_id = (SELECT id FROM ".$CI->db->dbprefix('user_type')." WHERE name = '".$type."') WHERE u.id = '".$id."' AND up.user_id = '".$id."'";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Save member modifications by admin
	// Parameters:
	//
	//  id 			- id of member
	//  username 	- username
	//  firstname 	- firstname
	//  lastname 	- lastname
	//  email 		- email
	//  telephone 	- telephone
	//  state 	 	- active or inactive
	//  picture 	- profile pic path
	//  hourly_rate	- hourly rate
	//  type 		- type
	//  password	- new pssword
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function saveMemModifNoPic($id, $username, $firstname, $lastname, $email, $telephone, $state, $hourly_rate, $type, $password)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." u, ".$CI->db->dbprefix('user_profile')." as up, ".$CI->db->dbprefix('user_type')." ut SET u.username = ".$CI->db->escape($username).", u.password = ".$CI->db->escape(md5($password)).", u.active = ".$CI->db->escape($state).", up.first_name = ".$CI->db->escape($firstname).", up.last_name = ".$CI->db->escape($lastname).", up.email = ".$CI->db->escape($email).", up.telephone = ".$CI->db->escape($telephone).", up.hourly_rate = ".$CI->db->escape($hourly_rate).", u.type_id = (SELECT id FROM ".$CI->db->dbprefix('user_type')." WHERE name = '".$type."') WHERE u.id = '".$id."' AND up.user_id = '".$id."'";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Save member modifications by admin
	// Parameters:
	//
	//  id 			- id of member
	//  username 	- username
	//  firstname 	- firstname
	//  lastname 	- lastname
	//  email 		- email
	//  telephone 	- telephone
	//  state 	 	- active or inactive
	//  picture 	- profile pic path
	//  hourly_rate	- hourly rate
	//  type 		- type
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function saveMemModifNoPass($id, $username, $firstname, $lastname, $email, $telephone, $state, $picture, $hourly_rate, $type)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." u, ".$CI->db->dbprefix('user_profile')." as up, ".$CI->db->dbprefix('user_type')." ut SET u.username = ".$CI->db->escape($username).", u.active = ".$CI->db->escape($state).", up.first_name = ".$CI->db->escape($firstname).", up.last_name = ".$CI->db->escape($lastname).", up.email = ".$CI->db->escape($email).", up.picture = ".$CI->db->escape($picture).", up.telephone = ".$CI->db->escape($telephone).", up.hourly_rate = ".$CI->db->escape($hourly_rate).", u.type_id = (SELECT id FROM ".$CI->db->dbprefix('user_type')." WHERE name = ".$CI->db->escape($type).") WHERE u.id = '".$id."' AND up.user_id = '".$id."'";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Save member modifications by admin
	// Parameters:
	//
	//  id 			- id of member
	//  username 	- username
	//  firstname 	- firstname
	//  lastname 	- lastname
	//  email 		- email
	//  telephone 	- telephone
	//  state 	 	- active or inactive
	//  hourly_rate	- hourly rate
	//  type 		- type
	//  
	// Returns:
	//
	// 	member ifo		- in case of success
	// 	0 				- in case of error

	function saveMemModifNo($id, $username, $firstname, $lastname, $email, $telephone, $state, $hourly_rate, $type)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." u, ".$CI->db->dbprefix('user_profile')." as up, ".$CI->db->dbprefix('user_type')." ut SET u.username = ".$CI->db->escape($username).", u.active = ".$CI->db->escape($state).", up.first_name = ".$CI->db->escape($firstname).", up.last_name = ".$CI->db->escape($lastname).", up.email = ".$CI->db->escape($email).", up.telephone = ".$CI->db->escape($telephone).", up.hourly_rate = ".$CI->db->escape($hourly_rate).", u.type_id = (SELECT id FROM ".$CI->db->dbprefix('user_type')." WHERE name = ".$CI->db->escape($type).") WHERE u.id = '".$id."' AND up.user_id = '".$id."'";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getDevelopersPMs()
	{
		$CI = &get_instance();

		$query = "SELECT u.id, up.first_name, up.last_name FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON u.id = up.user_id WHERE u.deleted = 'no' AND (u.type_id = '2' OR u.type_id = '3') AND u.active = 'yes' ORDER BY up.first_name";

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getUserProfile($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.homepage, up.first_name, up.last_name, up.email, up.telephone, up.picture, up.hourly_rate, up.balance, up.comp_name, up.id_country, up.city, up.receive_email, up.receive_notifications, u.username, u.type_id, u.deleted, u.active, up.paypal_account FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('user')." u ON up.user_id = u.id WHERE up.user_id = ".$user_id."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	function updateAvatar($user_id, $path)
	{
		$CI = &get_instance();

		if ($path == "")
		{
			return 1;
		}
		else
		{
			$query = "UPDATE ".$CI->db->dbprefix('user_profile')." SET picture = ".$CI->db->escape($path)." WHERE user_id = ".$user_id."";
			$result = $CI->db->query($query);

			if ($CI->db->affected_rows() > 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}

	function checkEmail($email)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user_profile')." WHERE email = ".$CI->db->escape($email)."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	function updatePassword($user_id, $password)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('user')." SET password = '".md5($password)."' WHERE id = '".$user_id."'";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function rand_string($length)
	{
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";	

		$size = strlen($chars);
		$str = "";

		for ($i = 0; $i < $length; $i++)
		{
			$str .= $chars[rand(0, $size - 1)];
		}

		if (isset($str))
		{
			return $str;
		}	
	}

	function getAllClients()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE type_id = 4";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getAllDevelopers($start = "", $offset = "", $search = "", $start_date = "", $end_date = "", $sort_col = "", $sort_dir = "")
	{
		$CI = & get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("up.first_name", "assigned", "in_progress", "completed", "hours", "up.balance");

		$limit = $search_q = $range_b = $range_t = "";
		$sort_q = " ORDER BY LOWER(up.first_name) ";

		if (strlen($start_date) > 0 && strlen($end_date) > 0)
		{
			$range_t .= " AND t.create_date BETWEEN '".date('Y/m/d', strtotime($start_date))."' AND '".date('Y/m/d', strtotime($end_date))."' ";
			$range_b .= " AND t.complete_date BETWEEN '".date('Y/m/d', strtotime($start_date))."' AND '".date('Y/m/d', strtotime($end_date))."' ";
		}

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			if ($sort_col != 0)
			{
				$sort_q = " ORDER BY ".$sort[$sort_col]." ".$sort_dir." ";
			}
			else
			{
				$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
			}
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(up.first_name) LIKE '%".strtolower($search)."%' OR LOWER(up.last_name) LIKE '%".strtolower($search)."%')";
		}

		$query = "
		SELECT up.first_name, up.last_name, u.id, up.balance,
			(SELECT COUNT(t.id) FROM task_assigned ta 
     			LEFT JOIN task t ON t.id = ta.task_id 
     			WHERE ta.user_id = u.id AND t.status = 'Completed' ".$range_b.") as completed, 
    		(SELECT COUNT(t.id) FROM task_assigned ta 
    		 	LEFT JOIN task t ON t.id = ta.task_id 
    		 	WHERE ta.user_id = u.id AND t.status = 'In Progress' ".$range_t.") as in_progress, 
    		(SELECT COUNT(t.id) FROM task_assigned ta 
    		 	LEFT JOIN task t ON t.id = ta.task_id 
    		 	WHERE ta.user_id = u.id AND t.status = 'Assigned' ".$range_t.") as assigned, 
    		(SELECT SUM(t.estimated_time) FROM task t 
    		 	LEFT JOIN task_assigned ta ON t.id = ta.task_id 
    		 	WHERE ta.user_id = u.id ".$range_b.") as hours 
    	FROM user u 
    	LEFT JOIN user_profile up ON u.id = up.user_id 
    	WHERE u.type_id = 3 AND u.active = 'yes' ".$search_q.$sort_q.$limit;

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	function getUserByUsername($username)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('user')." WHERE username = ".$CI->db->escape($username)."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	function getUserTodoList($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('todo_list')." WHERE user_id = ".$CI->db->escape($user_id)." ORDER BY due_date";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function addTodo($user_id, $task, $due_date)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('todo_list')." (user_id, task, due_date) VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($task).", ".$CI->db->escape($due_date).")";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	function deleteTodo($todo_id)
	{
		$CI = &get_instance();

		$query = "DELETE FROM ".$CI->db->dbprefix('todo_list')." WHERE id = ".$todo_id."";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			// $this->db->insert_id();
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to modify user profile balance.
	//
	// Parameters:
	//
	// user_id 			- user_id int 
	// balance  		- balance float
	//  
	// Returns:
	//
	// 	1 				- in case of success
	// 	0 				- in case of error

	function modifyUserProfileBalance($user_id, $operation, $estimate_hour)
	{
		$CI = &get_instance();
		$str = "";

		if ($operation == "add")
		{
			$str .= "+ ".$estimate_hour." ";
		}

		if ($operation == "minus" )
		{
			$str .= "- ".$estimate_hour." ";
		}

		$query = "UPDATE ".$CI->db->dbprefix('user_profile')." SET balance = balance ".$str." WHERE user_id = ".$user_id."";
		$result = $CI->db->query($query);

		return 1;
	}

	// Function to get first registration date
	//
	// Parameters:
	//  
	// Returns:
	//
	// 	object 			- in case of success
	// 	0 				- in case of error
	function getFirstRegistration()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM user_profile ORDER BY create_date ASC LIMIT 1";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}
}
?>