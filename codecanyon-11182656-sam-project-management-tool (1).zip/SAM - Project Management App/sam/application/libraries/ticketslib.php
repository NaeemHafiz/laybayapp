<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ticketslib
{
	var $CI;

	function Ticketslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

// Ticket functions 

	// Function to get all tickets for datatable
	//
	// Parameters:
	//
	// 	start_date 	-  start date range date
	// 	end_date 	-  end date range date
	// 	start 		-  start pagination index integer
	// 	offset 		-  offset pagination index integer
	// 	search 		-  search string varchar
	//
	// Returns:
	//
	//	2d array 	- in case of success
	//	0 			- in case of error

	function getAllTickets($start_date, $end_date, $start = "", $offset = "", $search = "", $sort_col = "", $sort_dir = "")
	{
		$CI = &get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("id", "subject", "added_by", "added_on", "status");

		$date_range = $search_q = $limit = "";
		$sort_q = " ORDER BY t.added_on DESC, t.id DESC";

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			if ($sort_col == 0 || $sort_col == 3)
			{
				$sort_q = " ORDER BY ".$sort[$sort_col]." ".$sort_dir." ";
			}
			else
			{
				$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
			}
		}

		if (strlen($start_date) > 0)
		{
			$date_range .= " AND t.added_on >= '".$start_date."'";
		}

		if (strlen($end_date) > 0)
		{
			$date_range .= " AND t.added_on <= '".$end_date."'";
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset." ";
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(t.subject) LIKE '%".strtolower($search)."%' OR LOWER(t.added_by) LIKE '%".strtolower($search)."%' OR LOWER(ts.name) LIKE '%".strtolower($search)."%') ";
		}

		$query = "SELECT t.id, t.subject, t.added_by, t.added_on, ts.name as status FROM tickets t 
					LEFT JOIN ticket_status ts ON t.status_id = ts.id 
					LEFT JOIN ticket_settings tss ON t.settings_id = tss.id 
					WHERE tss.active = 'yes' ".$date_range.$search_q.$sort_q.$limit;

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	// Function to get ticket info
	//
	// Parameters:
	//
	//  ticket_id 	- ticket id integer
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function getTicketInfo($ticket_id)
	{
		$CI = &get_instance();

		$query = "SELECT t.id, t.added_by, t.email, t.phone, t.subject, t.message, t.added_on, t.status_id, t.respondent_id, t.closing_id, t.answer, t.close_message, tt.type, ts.app_url as domain, ts.active, ts.notification_email as emails, tst.name as status FROM tickets t 
					LEFT JOIN ticket_settings ts ON t.settings_id = ts.id 
					LEFT JOIN ticket_type tt ON t.type_id = tt.id 
					LEFT JOIN ticket_status tst ON t.status_id = tst.id 
					WHERE ts.active = 'yes' and t.id = ".$ticket_id;

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Function to close ticket
	//
	// Parameters:
	//
	//  ticket_id 	- ticket id integer
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function closeTicket($ticket_id, $user_id, $message)
	{
		$CI = &get_instance();

		$query = "UPDATE tickets SET status_id = '3', close_message = ".$CI->db->escape($message).", closing_id = ".$CI->db->escape($user_id)." WHERE id = ".$ticket_id;
		$result = $CI->db->query($query);

		if (!$CI->db->_error_message())
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to remove ticket
	//
	// Parameters:
	//
	//  ticket_id 	- ticket id integer
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function removeTicket($ticket_id)
	{
		$CI = &get_instance();

		$q2 = "DELETE FROM tickets WHERE id = ".$ticket_id;

		$r2 = $CI->db->query($q2);
		
		return 1;
	}

	// Function to remove ticket settings
	//
	// Parameters:
	//
	//  ticket_id 	- ticket setting id integer
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function removeTicketSetting($ticket_id)
	{
		$CI = &get_instance();

		$q2 = "DELETE FROM ticket_settings WHERE id = ".$ticket_id;

		$r2 = $CI->db->query($q2);
		
		return 1;
	}

	// Function to answer ticket
	//
	// Parameters:
	//
	//  id 				- ticket id integer
	//  respondent_id 	- id of person that answered
	//  message 		- answered message
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function answerTicket($id, $respondent_id, $message)
	{
		$CI = &get_instance();

		$query = "UPDATE tickets SET respondent_id = ".$CI->db->escape($respondent_id).", answer = ".$CI->db->escape($message).", status_id='2' WHERE id = ".$id;
		$result = $CI->db->query($query);

		if (!$CI->db->_error_message())
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to get first ticket date
	//
	// Parameters:
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function getFirstTicketDate()
	{
		$CI = &get_instance();

		$query = "SELECT t.added_on as first_date FROM tickets t LEFT JOIN ticket_settings ts ON t.settings_id = ts.id WHERE ts.active = 'yes' ORDER BY t.added_on ASC LIMIT 1";
		$result = $CI->db->query($query);
		
		return $result->row();
	}

// Ticket setting functions

	// Function to get all tickets for datatable
	//
	// Parameters:
	//
	// 	start_date 	-  start date range date
	// 	end_date 	-  end date range date
	// 	start 		-  start pagination index integer
	// 	offset 		-  offset pagination index integer
	// 	search 		-  search string varchar
	//
	// Returns:
	//
	//	2d array 	- in case of success
	//	0 			- in case of error

	function getAllTicketsSettings($start = "", $offset = "", $search = "", $sort_col = "", $sort_dir = "")
	{
		$CI = &get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("domain", "name", "active");

		$limit = $search_q = "";
		$sort_q = " ORDER BY name ASC ";

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
		}

		if (strlen($start) > 0 && strlen($offset))
		{
			$limit .= " LIMIT ".$start.",".$offset." ";
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(ts.app_url) LIKE '%".strtolower($search)."%' OR LOWER(u.first_name) LIKE '%".strtolower($search)."%' OR LOWER(u.last_name) LIKE '%".strtolower($search)."%') ";
		}

		$query = "SELECT ts.id, ts.app_url as domain, CONCAT(u.first_name, ' ', u.last_name) as name, ts.active FROM ticket_settings ts 
					LEFT JOIN user_profile u ON ts.client_id = u.user_id 
					WHERE 1 ".$search_q.$sort_q.$limit;

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	// Function to get ticket settings data
	//
	// Parameters:
	//
	//  id 			- settings id integer
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function getSettingInfo($id)
	{
		$CI = & get_instance();

		$query 	= "SELECT * FROM ticket_settings WHERE id = ".$id;
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Function to save edited settings
	//
	// Parameters:
	//
	//  id 			- settings id integer
	//  client_id 	- new client id integer
	//  app_url 	- application domain varchar
	//  noti_email 	- notified email addresses varchar
	//  active 		- active enum(yes, no)
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function saveSettingsEdit($id, $client_id, $client_key, $app_url, $noti_email, $text_col, $btn_col, $btn_text, $script, $active)
	{
		$CI = & get_instance();

		$query = "UPDATE ticket_settings SET client_id = ".$CI->db->escape($client_id).", client_key=".$CI->db->escape($client_key).", app_url=".$CI->db->escape($app_url).", notification_email=".$CI->db->escape($noti_email).", text_color=".$CI->db->escape($text_col).", button_color=".$CI->db->escape($btn_col).", button_text=".$CI->db->escape($btn_text).", script=".$CI->db->escape($script).", active=".$CI->db->escape($active)." WHERE id=".$id;
		$CI->db->query($query);

		if (!$CI->db->_error_message())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to save new settings
	//
	// Parameters:
	//
	//  client_id 	- new client id integer
	//  app_url 	- application domain varchar
	//  noti_email 	- notified email addresses varchar
	//  active 		- active enum(yes, no)
	//
	// Returns:
	//
	//	object 		- in case of success
	//	0 			- in case of error

	function saveSettingsAdd($client_id, $client_key, $app_url, $noti_email, $text_col, $btn_col, $btn_text, $script, $active)
	{
		$CI = & get_instance();

		$query = "INSERT INTO ticket_settings(client_id, client_key, app_url, notification_email, text_color, button_color, button_text, script, active) VALUES(".$CI->db->escape($client_id).", ".$CI->db->escape($client_key).", ".$CI->db->escape($app_url).", ".$CI->db->escape($noti_email).", ".$CI->db->escape($text_col).", ".$CI->db->escape($btn_col).", ".$CI->db->escape($btn_text).", ".$CI->db->escape($script).", ".$CI->db->escape($active).")";
		$CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
?>