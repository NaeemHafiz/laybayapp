<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notificationslib
{
	var $CI;

	function Notificationslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	function addNotification($user_id, $type_id, $object_id, $message)
	{
		$CI = & get_instance();

		$query = "INSERT INTO notifications(user_id, type_id, object_id, message, added) VALUES(".$CI->db->escape($user_id).", ".$CI->db->escape($type_id).", ".$CI->db->escape($object_id).", ".$CI->db->escape($message).", '".date("Y-m-d H:i:s")."')";
		$CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function readNotification($user_id, $notification_id)
	{
		$CI = & get_instance();

		$noti_q = "";
		
		if (strlen($notification_id) > 0)
		{
			$noti_q = " AND id = ".$CI->db->escape($notification_id);
		}

		$query = "UPDATE notifications SET viewed = 'yes' WHERE user_id = ".$CI->db->escape($user_id)." ".$noti_q;

		$CI->db->query($query);

		if (!$CI->db->_error_message())
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getNotificationTypeByName($name)
	{
		$CI = & get_instance();

		$query = "SELECT * FROM notification_types WHERE type = ".$CI->db->escape($name);

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	function getUserNotifications($id, $viewed = "no", $limit = "")
	{
		$CI = & get_instance();

		$viewed_q = "";

		if (strlen($limit) < 1)
		{
			$limit = "";
		}
		else
		{
			$limit = " LIMIT ".$limit;
		}

		if ($viewed == "yes")
		{
			$viewed_q = " AND n.viewed = 'no'";
		}

		$query = "SELECT n.id, n.type_id, n.user_id, n.object_id, n.message, n.added, n.viewed, nt.type, nt.type as title FROM notifications n LEFT JOIN notification_types nt ON n.type_id = nt.id WHERE n.user_id = ".$CI->db->escape($id).$viewed_q." ORDER BY n.added DESC ".$limit;
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to transform timestamp in string
	function timing($time)
	{
		$time = time() - $time; // to get the time since that moment
	    $tokens = array (
	        31536000 => 'year',
	        2592000 => 'month',
	        604800 => 'week',
	        86400 => 'day',
	        3600 => 'hour',
	        60 => 'minute',
	        1 => 'second'
	    );

	    foreach ($tokens as $unit => $text)
	    {
	        if ($time < $unit)
	        	continue;

	        $numberOfUnits = floor($time / $unit);
	        return $numberOfUnits.' '.$text.(($numberOfUnits > 1) ? 's' : '');
	    }
	}
}
?>