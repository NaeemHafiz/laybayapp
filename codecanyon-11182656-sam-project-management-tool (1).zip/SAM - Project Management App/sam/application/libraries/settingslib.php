<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settingslib
{
	var $CI;

	function Settingslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->helper('language');
		$CI->load->helper('cookie');
		$CI->load->library("session");

		$query = "SELECT * FROM ".$CI->db->dbprefix('settings')."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			$var_list = $result->result();

			foreach ($var_list as $var) 
			{
				$CI->config->set_item($var->var_name, $var->value);
			}
		}

		// Set default language
		if ($CI->input->cookie('language') == null)
		{
			$CI->input->set_cookie('language', 'en', time() + 60 * 60 * 24 * 365);
		}

		$language = $CI->input->cookie('language');

		// Language list
		switch ($language)
		{
			case 'en':
				$CI->lang->load('en', 'english');
				break;

			case 'ro':
				$CI->lang->load('ro', 'romanian');
				break;

			case 'es':
				$CI->lang->load('es', 'spanish');
				break;

			case 'hu':
				$CI->lang->load('hu', 'hungarian');
				break;

			case 'de':
				$CI->lang->load('de', 'german');
				break;

			case 'it':
				$CI->lang->load('it', 'italian');
				break;

			case 'tr':
				$CI->lang->load('tr', 'turkish');
				break;
			
			default:
				$CI->lang->load('en', 'english');
				break;
		}
	}

	function getSettings()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('settings');

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function editSettings($company, $contact_email, $accounting_email, $sender_name, $sender_email, $enable_tickets, $show_credits, $send_emails, $multi_language)
	{
		$CI = &get_instance();
		$parameters = array();
		$parameters[1] = $company;
		$parameters[2] = $contact_email;
		$parameters[3] = $accounting_email;
		$parameters[4] = $sender_name;
		$parameters[5] = $sender_email;
		$parameters[6] = $enable_tickets;
		$parameters[7] = $show_credits;
		$parameters[8] = $send_emails;
		$parameters[9] = $multi_language;

		for ($i = 1; $i <= 9; $i++)
		{ 
			$query = "UPDATE ".$CI->db->dbprefix('settings')." SET value = ".$CI->db->escape($parameters[$i])." WHERE id = '".$i."'";	
			$result = $CI->db->query($query);
		}

		return 1;
	}
}
?>