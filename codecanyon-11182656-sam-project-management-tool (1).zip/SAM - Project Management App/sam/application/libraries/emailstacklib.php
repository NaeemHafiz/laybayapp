<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emailstacklib
{
	var $CI;

	function Emailstacklib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	function addEmailInStack($sender, $receiver, $name, $subject, $message)
	{
		$CI = &get_instance();
		$query = "INSERT INTO ".$CI->db->dbprefix('emailq')." (`from`, `to`, `name`, `subject`, `message`, `added`, `sent`) VALUES (".$CI->db->escape($sender).", ".$CI->db->escape($receiver).", ".$CI->db->escape($name).", ".$CI->db->escape($subject).", ".$CI->db->escape($message).", '".date("Y-m-d H:i:s")."', 'no')";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}
}

?>