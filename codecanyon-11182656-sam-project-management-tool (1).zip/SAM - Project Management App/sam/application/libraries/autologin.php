<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Autologin
{
	var $CI;

	function Autologin()
	{
		$CI = & get_instance();
		$CI->load->database();
		$CI->load->helper('url');
		$CI->load->helper('language');
		$CI->load->helper('cookie');
		$CI->load->library("session");
		$CI->load->library('userslib');

		$first_uri_segment 	= $CI->uri->segment(1);

		$cookie_id 			= $CI->input->cookie('id');
		$cookie_key			= $CI->input->cookie('key');
		$session_id 		= $CI->session->userdata('user_id');
		$session_username 	= $CI->session->userdata('username');
		$session_password 	= $CI->session->userdata('password');
		$session_usertype 	= $CI->session->userdata('user_type');

		if ($cookie_id != "" && $cookie_key != "")
		{
			$CI->session->sess_destroy();
			$magicword  = "intelcoderrocks";
			$user_data  = $CI->userslib->getUserData($cookie_id);
			$password   = $user_data->password;
			$new_key 	= md5($cookie_id.$magicword.$password);
			if ($cookie_key == $new_key)
			{
				$CI->userslib->userLoginFromCookie($user_data->username, $user_data->password);
			}

		}
		else if (($session_id == "" || $session_username = "" || $session_password = "" || $session_usertype = "") && $first_uri_segment != "login" && $first_uri_segment != "" && $first_uri_segment != "recover" )
		{
			redirect(base_url().'login');
		}
	}
}
?>