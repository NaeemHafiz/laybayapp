<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Projectslib
{
	var $CI;

	function Projectslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	// Function to add project
	//
	// Parameters:
	//	name 			- name String
	//	description 	- project description Text
	//	create_date 	- project create date Datetime
	//	end_date 		- project end date Datetime
	//
	// Returns:
	//	currently added project id 	- in case of success
	//	0							- in case of fail

	function addProjects($name, $description, $create_date, $end_date)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('project')." (`name`, description, create_date, end_date) VALUES (".$CI->db->escape($name).", ".$CI->db->escape($description).", '".$create_date."', '".$end_date."')";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to edit project
	//
	// Parameters:
	//	project_id 				- project id of project to be edited
	//	project_name 			- new project Name String
	//	project_description 	- new project Description Text
	//	project_end_date 		- new project end date Datetime
	//
	// Returns:
	//	1	- in case of success
	//	0	- in case of fail

	function editProject($project_id, $project_name, $project_description, $project_end_date)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('project')." SET `name` = ".$CI->db->escape($project_name).", description = ".$CI->db->escape($description).", end_date = '".$project_end_date."' WHERE id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to edit project status
	//
	// Parameters:
	//	project_id 				- project id of project to be edited
	//
	// Returns:
	//	1	- in case of success
	//	0	- in case of fail

	function editProjectStatus($project_id)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('project')." SET status = 'Completed' WHERE id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete project
	//
	// Parameters:
	//	project_id 		- id of project to be deleted
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function deleteProject($project_id)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('project')." SET deleted = 'yes' WHERE id = '".$project_id."'";
		$query_task = "UPDATE ".$CI->db->dbprefix('task')." SET deleted = 'yes' WHERE project_id = '".$project_id."'";
		$result = $CI->db->query($query);
		$CI->db->query($query_task);
		
		return 1;
	}

	// Function to get data from project
	//
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object			- in case of success
	//	0				- in case of fail

	function getProjectData($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('project')." WHERE id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get pm for project
	//
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getProjectManagersForProjects($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.id, up.first_name, up.last_name, up.email, up.receive_email FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_pm')." pp ON up.id = pp.user_id WHERE pp.project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get clients for project
	//
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getClientsForProjects($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.id, up.first_name, up.last_name, up.email, up.receive_email, up.receive_notifications FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON up.id = pv.user_id WHERE pv.project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get pms for a project
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getPMAssignedList($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id, up.id, up.first_name, up.last_name, up.email, up.receive_email, up.receive_notifications FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_pm')." pm ON pm.user_id = up.user_id WHERE pm.project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get pms for a project
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getAssignedPMsId($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id as id FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_pm')." pm ON pm.user_id = up.user_id WHERE pm.project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get clients for a project
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getClientAssignedList($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.id, up.user_id, up.first_name, up.last_name, up.email, up.receive_email, up.comp_name, up.homepage, up.create_date as since, up.picture FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON pv.user_id = up.user_id WHERE pv.project_id = '".$project_id."'";

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get assigned clients id for a project
	// Parameters:
	//	project_id 		- id of project to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getAssignedClientsId($project_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.user_id as id FROM ".$CI->db->dbprefix('user_profile')." up LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON pv.user_id = up.user_id WHERE pv.project_id = '".$project_id."'";

		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get client projects
	//
	// Parameters:
	//	userId 			- user to be selected
	//
	// Returns:
	//	object array	- in case of success
	//	0				- in case of fail

	function getClientProjectData()
	{
		$query = "SELECT p.name, p.description, p.id, p.end_date FROM ".$CI->db->dbprefix('project_view')." pv LEFT JOIN ".$CI->db->dbprefix('project')." p ON pv.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('user')." u ON pv.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE p.deleted = 'no' AND ut.id = 4";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get developer projects
	//
	// Parameters:
	//	userId 			- user to be selected
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function getDeveloperProjectData()
	{
		$query = "SELECT p.name, p.description, p.id, p.end_date FROM ".$CI->db->dbprefix('project_view')." pv LEFT JOIN ".$CI->db->dbprefix('project')." p ON pv.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('user')." u ON pv.user_id = u.id LEFT JOIN ".$CI->db->dbprefix('user_type')." ut ON u.type_id = ut.id WHERE p.deleted = 'no' AND ut.id = 3";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get Admin projects
	//
	// Parameters:
	//	userId 			- user to be selected
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function getAdminProjectData($userId)
	{
		$query = "SELECT id, name, description, end_date FROM ".$CI->db->dbprefix('project')."";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to add task
	//
	// Parameters:
	//	project_id				- project id to add task to
	//	name 					- task name String
	//	description 			- task description Text
	//	create_date 			- task create date Datetime
	//	end_date 				- task end date Datetime
	//
	// Returns:
	//	currently added task id - in case of success
	//	0						- in case of fail

	function addTask($user_id, $project_id, $priority_id, $name, $description, $status)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('task')." (user_id, project_id, priority_id, `name`, description, create_date, status) VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($project_id).", ".$CI->db->escape($priority_id).", ".$CI->db->escape($name).", ".$CI->db->escape($description).", '".date("Y-m-d H-i-s")."', ".$CI->db->escape($status).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to add task
	//
	// Parameters:
	//	task_id			- task id to edit
	//	name 			- new task name String
	//	description 	- new task description Text
	//	end_date 		- new task end date Datetime
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail 
	//	
	// Note: 		
	//	Task can't be changed to add it to another project

	function editTask($task_id, $project_id, $name, $description)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task')." SET project_id = ".$CI->db->escape($project_id).", name = ".$CI->db->escape($name).", description = ".$CI->db->escape($description)." WHERE id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete task
	//
	// Parameters:
	//	task_id			- task id to delete
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function deleteTask($task_id)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task')." SET deleted = 'yes' WHERE id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete task
	//
	// Parameters:
	//	task_id			- task id to close
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function closeTask($task_id)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task')." SET status = 'completed' WHERE id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to update project
	//
	// Parameters:
	//	project_id		- project id to modify
	//	project_name	- new name
	//	project_desc	- new description
	//	project_end_date- new end date
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function modifyProject($project_id, $project_name, $project_desc, $project_end_date)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('project')." SET name = ".$CI->db->escape($project_name).", description = ".$CI->db->escape($project_desc).", end_date = ".$CI->db->escape($project_end_date)." WHERE id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->_error_message())
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	// Function to delete project manager from project
	//
	// Parameters:
	//	project_id		- project id to modify
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function deleteProjectPM($project_id)
	{
		$CI = &get_instance();

		$query_check = "SELECT * FROM ".$CI->db->dbprefix('project_pm')." WHERE project_id = '".$project_id."'";
		$result_check = $CI->db->query($query_check);

		if ($result_check->num_rows() > 0)
		{
			$query = "DELETE FROM ".$CI->db->dbprefix('project_pm')." WHERE project_id = '".$project_id."'";
			$result = $CI->db->query($query);

			if ($CI->db->affected_rows() > 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 1;
		}
	}

	// Function to insert new project manager for project
	//
	// Parameters:
	//	project_id		- project id to modify
	//	pm_id			- new assign
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function modifyProjectPM($project_id, $pm_id)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('project_pm')." (project_id, user_id) VALUES (".$CI->db->escape($project_id).", ".$CI->db->escape($pm_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete client from a project
	//
	// Parameters:
	//	project_id		- project id to modify
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function deleteProjectClient($project_id)
	{
		$CI = &get_instance();

		$query_check = "SELECT * FROM ".$CI->db->dbprefix('project_view')." WHERE project_id = '".$project_id."'";
		$result_check = $CI->db->query($query_check);

		if ($result_check->num_rows() > 0)
		{
			$query = "DELETE FROM ".$CI->db->dbprefix('project_view')." WHERE project_id = '".$project_id."'";
			$result = $CI->db->query($query);

			if ($CI->db->affected_rows() > 0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 1;
		}
	}

	// Function to update client assigns
	//
	// Parameters:
	//	project_id		- project id to modify
	//	client_id		- new assign
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function modifyProjectClient($project_id, $client_id)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('project_view')." (user_id, project_id) VALUES (".$CI->db->escape($client_id).", ".$CI->db->escape($project_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}


	// Function to get data from task
	//
	// Parameters:
	//	task_id 		- id of task to be selected
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function getTaskData($task_id)
	{
		$CI = &get_instance();

		$query = "SELECT t.id, t.project_id, t.name, t.description, t.complete_date, tv.type, tv.value, ta.user_id FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON t.id = ta.task_id LEFT JOIN ".$CI->db->dbprefix('task_value')." tv ON t.id = tv.task_id WHERE t.id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to delete task
	//
	// Parameters:
	//	task_id			- task id to open
	//
	// Returns:
	//	1				- in case of success
	//	0				- in case of fail

	function openTask($task_id)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task')." SET status = 'in_progress' WHERE id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to add comments
	//
	// Parameters:
	//	task_id 		- task id to insert comment to
	//	user_id		 	- user id to insert comment to
	//	text 			- comment text Text
	//	create_date 	- comment create date Datetime
	//
	// Returns:
	//	currently added comment id 	- in case of success
	//	0							- in case of fail

	function addTaskComments($task_id, $user_id, $text, $create_date)
	{
		$query = "INSERT INTO ".$CI->db->dbprefix('task_comments')." (task_id, user_id, `text`, create_date) VALUES (".$CI->db->escape($task_id).", ".$CI->db->escape($user_id).", ".$CI->db->escape($text).", '".$create_date."')";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $this->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to edit comment
	//
	// Parameters:
	//	id  			- comment id to edit
	//	text 		 	- new comment Text
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function editTaskComments($id,$text)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task_comments')." SET `text` = ".$CI->db->escape($text).", WHERE id = '".$id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete comment
	//
	// Parameters:
	//	id  			- comment id to delete
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function deleteTaskComments($id)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task_comments')." SET deleted = 'yes' WHERE id = '".$id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to add project view
	//
	// Parameters:
	//	user_id  				- user to assign the project to
	//	project_id  			- project to assign to user
	//
	// Returns:
	//	currently added view	- in case of success
	//	0						- in case of fail

	function addProjectView($user_id, $project_id)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('project_view')." (user_id, project_id) VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($project_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to add project_PM view
	//
	// Parameters:
	//	user_id  				- project manager to assign the project to
	//	project_id  			- project to assign to pm
	//
	// Returns:
	//	currently added view	- in case of success
	//	0						- in case of fail

	function addProjectPM($user_id, $project_id)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('project_pm')." (user_id, project_id) VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($project_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to delete project view
	//
	// Parameters:
	//	id  			- id of view to delete
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function deleteProjectView($id)
	{
		$query = "DELETE * FROM ".$CI->db->dbprefix('project_view')." WHERE id = '".$id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to delete project view 2
	//
	// Parameters:
	//	user_id  				- id of user to delete
	//  project_id  			- id of project to delete
	//
	// Returns:
	//	1 						- in case of success
	//	0						- in case of fail

	function deleteProjectViewUser($user_id, $project_id)
	{
		$query = "DELETE * FROM ".$CI->db->dbprefix('project_view')." WHERE user_id = '".$user_id."' AND project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to browse tasks
	//
	// Parameters:
	//	project_id 		- project id to display tasks from
	//
	// Returns:
	//	array of objects with tasks - in case of success
	//	0							- in case of fail

	function browseTask($project_id)
	{
		
		$query = "SELECT id, `name`, description, create_date, complete_date, status, deleted FROM ".$CI->db->dbprefix('task')." WHERE project_id = '".$project_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to assign task
	//
	// Parameters:
	//	task_id 		- task to assign to
	//	user_id 	 	- user to assign task to
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function assignTask($user_id, $task_id)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('task_assigned')." (user_id, task_id) VALUES (".$CI->db->escape($user_id).", ".$CI->db->escape($task_id).")";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to edit task assigned
	//
	// Parameters:
	//	task_id  		- task id to modify value of
	//	user_id  		- user id
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function editTaskAssigned($task_id, $user_id)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task_assigned')." SET user_id = ".$CI->db->escape($user_id)." WHERE task_id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to edit task value
	//
	// Parameters:
	//	task_id  		- task id to modify value of
	//	task_value  	- new task value
	//	task_type  		- new task type
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function editTaskValue($task_id, $task_value, $task_type)
	{
		$query = "UPDATE ".$CI->db->dbprefix('task_value')." SET value = ".$CI->db->escape($task_value).", type = ".$CI->db->escape($task_type)." WHERE task_id = '".$task_id."'";
		$result = $CI->db->query($query);
		
		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}	
	}

	// Function to get taskas by users
	//
	// Parameters:
	//
	// Returns:
	//	object_array	- in case of success
	//	0				- in case of fail

	function getUserTasks($id, $user_type, $user_id, $status, $pm_view_project_tasks)
	{
		$CI = &get_instance();

		$query1 = "SELECT id, name FROM ".$CI->db->dbprefix('user_type')." WHERE id='".$user_type."'";
		$result = $CI->db->query($query1);

		if ($result->num_rows() > 0)
		{
			$type_obj = $result->row();
		}
		else
		{
			return 0;
		}

		$status_where = "";
		$project_where = "";
		$order_by = "";

		// Check if there is a project id to sort by
		if (strlen($id) > 0)
		{
			$project_where = " and t.project_id='".$id."'";
		}

		// Check the status to sort by
		if (strlen($status) > 0)
		{
			if ($status == 'latest')
			{
				$status_where .= " and NOT (t.status = 'Completed') ";
				$order_by     = " ORDER BY t.priority_id DESC, t.create_date DESC";
			}
			else
			{ 
				if ($status == 'all')
				{
					$order_by     = " ORDER BY t.priority_id DESC, t.create_date DESC";
				}

				if ($status == 'In Progress')
				{
					$status_where .= " and t.status = 'In Progress'";
					$order_by     = " ORDER BY t.priority_id DESC, t.create_date DESC";
				}

				if ($status == "Assigned")
				{
					$status_where .= " and t.status = 'Assigned'";
					$order_by     = " ORDER BY t.priority_id DESC";
				}

				if ($status == "Completed")
				{
					$status_where .= " and t.status = 'Completed'";
					$order_by     = " ORDER BY t.due_date DESC";
				}
			}
		}

		switch ($type_obj->id)
		{
			case '3':
				$query = "SELECT t.id, t.user_id, tpt.name as priority, t.create_date, t.due_date, t.project_id, t.name, t.complete_date, t.status, p.name as pname FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('task_priority_type')." tpt ON t.priority_id = tpt.id WHERE ta.user_id = '".$user_id."' ".$status_where." and t.deleted = 'no' ".$project_where." ".$order_by;
				break;

			case '4':
				$query = "SELECT t.id, t.user_id, tpt.name as priority, t.create_date, t.due_date, t.project_id, t.name, t.complete_date, t.status, p.name as pname FROM ".$CI->db->dbprefix('project_view')." pv LEFT JOIN ".$CI->db->dbprefix('task')." t ON pv.project_id = t.project_id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('task_priority_type')." tpt ON t.priority_id = tpt.id WHERE pv.user_id = '".$user_id."' and t.deleted = 'no' ".$project_where." ".$status_where." ".$order_by;
				break;

			case '2':
				if ($pm_view_project_tasks == "yes")
				{
					$query = "SELECT up.first_name, up.last_name, t.id, t.user_id, tpt.name as priority, t.create_date, t.due_date, t.project_id, t.name, t.complete_date, t.status, p.name as pname FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON ta.user_id = up.user_id LEFT JOIN ".$CI->db->dbprefix('task_priority_type')." tpt ON t.priority_id = tpt.id WHERE t.deleted = 'no' ".$project_where." ".$status_where." GROUP BY t.id ".$order_by;
					break;
				}
				else
				{
					$query = "SELECT t.id, t.user_id, t.create_date, t.due_date, t.project_id, tpt.name as priority, t.name, t.complete_date, t.status, p.name as pname  FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('task_priority_type')." tpt ON t.priority_id = tpt.id WHERE ta.user_id = '".$user_id."' and t.deleted = 'no' ".$project_where." ".$status_where." GROUP BY t.id ".$order_by;
					break;
				}
				 
			default:
				$query = "SELECT t.id, t.user_id, t.create_date, t.due_date, t.project_id, tpt.name as priority, t.name, t.description, t.create_date, t.complete_date, t.status, t.deleted, p.name as pname, up.first_name, up.last_name FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON t.id = ta.task_id LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON ta.user_id = up.user_id LEFT JOIN ".$CI->db->dbprefix('task_priority_type')." tpt ON t.priority_id = tpt.id WHERE t.deleted = 'no' ".$project_where." ".$status_where." GROUP BY t.id ".$order_by;
				break;
		}


		$result2 = $CI->db->query($query);

		if ($result2->num_rows() > 0)
		{
			return $result2->result();
		}
		else
		{
			return 0;
		}

	}

	// Function to get projects by users
	//
	// Parameters:
	//
	// Returns:
	//	object_arrauccess
	//	0				- in case of fail

	function getUserProjects($user_type, $user_id, $completed)
	{
		$CI = &get_instance();

		$query1 = "SELECT id, name FROM ".$CI->db->dbprefix('user_type')." WHERE id = '".$user_type."'";
		$result = $CI->db->query($query1);

		$pm_str = "";

		if ($completed == "completed_no")
		{
			$pm_str .= "AND p.status = 'In Progress'";
		}

		$type_obj = $result->row();

		$order = "ORDER BY p.name ASC";

		switch ($type_obj->id)
		{
			case '3':
				$query = "SELECT p.id as projectid, p.name, p.create_date, p.end_date, p.status, p.deleted, pv.user_id, up.first_name, up.last_name FROM ".$CI->db->dbprefix('project')." p 
							LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON p.id = pv.project_id
							LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON pv.user_id = up.user_id
							LEFT JOIN ".$CI->db->dbprefix('task')." t ON t.project_id = p.id 
							LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON ta.task_id = t.id 
							WHERE ta.user_id = '".$user_id."' AND p.deleted = 'no' GROUP BY projectid ".$order."";
				break;

			case '4':
				$query = "SELECT DISTINCT p.id as projectid, p.name, p.create_date, p.end_date, p.status, p.deleted FROM ".$CI->db->dbprefix('project')." p
						LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON pv.project_id = p.id
						WHERE pv.user_id = '".$user_id."' AND p.deleted = 'no' ".$pm_str." ".$order."";
				break;

			case '2':
				$query = "SELECT p.id as projectid, p.name, p.create_date, p.end_date, p.status, p.deleted, pv.user_id, up.first_name, up.last_name FROM ".$CI->db->dbprefix('project')." p 
							LEFT JOIN ".$CI->db->dbprefix('project_pm')." pp ON pp.project_id = p.id 
							LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON p.id = pv.project_id
							LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON pv.user_id = up.user_id
							LEFT JOIN ".$CI->db->dbprefix('task')." t ON t.project_id = p.id 
							LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON ta.task_id = t.id 
							WHERE pp.user_id = '".$user_id."' AND p.deleted = 'no' ".$pm_str." GROUP BY projectid ".$order."";
				break;

			default:
				$query = "SELECT p.id as projectid, p.name, p.create_date, p.end_date, p.status, p.deleted, pv.user_id, up.first_name, up.last_name FROM ".$CI->db->dbprefix('project')." p 
							LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON p.id = pv.project_id
							LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON pv.user_id = up.user_id
							LEFT JOIN ".$CI->db->dbprefix('task')." t ON t.project_id = p.id 
							LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON ta.task_id = t.id
							WHERE p.deleted = 'no' GROUP BY projectid ".$order."";
				break;
		}

		$result2 = $CI->db->query($query);

		if ($result2->num_rows() > 0)
		{
			return $result2->result();
		}
		else
		{
			return 0;
		}

	}

	// Function to get all comments from a task
	//
	// Parameters:
	//	task_id  		- task id 
	//
	// Returns:
	//	object array		- in case of success
	//	0					- in case of fail

	function browseTaskComments($task_id)
	{
		$query = "SELECT c.`text`, c.create_date , up.first_name, up.last_name FROM ".$CI->db->dbprefix('task_comments')." c LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON c.user_id = up.user_id WHERE c.deleted = 'no' AND c.task_id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			$type_obj = $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			$type_obj = $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get task data
	//
	// Parameters:
	//	task_id  		- task id 
	//
	// Returns:
	//	object 			- in case of success
	//	0				- in case of fail
	function browseTaskData($task_id)
	{
		$CI = &get_instance();
		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE id = '".$task_id."' AND deleted = 'no'";

		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			return $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}	

	// Function to get project to project manager
	//
	// Parameters:
	//	user_id  		- user id 
	//
	// Returns:
	//	object 			- in case of success
	//	0				- in case of fail
	function getProjectPManager($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT project_id FROM ".$CI->db->dbprefix('project_pm')." WHERE user_id = '".$user_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			$type_obj = $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			$type_obj = $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get project to Client
	//
	// Parameters:
	//	user_id  		- user id 
	//
	// Returns:
	//	object 			- in case of success
	//	0				- in case of fail
	function getProjectClients($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT DISTINCT pv.user_id FROM ".$CI->db->dbprefix('project_pm')." pm LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON pm.project_id = pv.project_id WHERE pv.user_id IS NOT NULL AND pm.user_id = '".$user_id."'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->num_rows();
		}
		else
		{
			return 0;
		}
	}

	// Function to get project to Project mannager
	//
	// Parameters:
	//	user_id  		- user id 
	//
	// Returns:
	//	object 			- in case of success
	//	0				- in case of fail
	function getAssignedPMannagerTask($id, $user_id)
	{
		$project_where = "";

		if (strlen($id) > 0)
		{
			$project_where = "AND t.project_id = '".$id."'";
		}
		
		$query = "SELECT t.id, t.project_id, t.name, t.complete_date, p.name as pname FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id WHERE ta.user_id = '".$user_id."' ".$project_where." and t.deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() == 1)
		{
			$type_obj = $result->row();
		}
		elseif ($result->num_rows() > 1)
		{
			$type_obj = $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to generate project list
	//
	// Parameters:
	//
	// Returns:
	//	object_arr 			- in case of success
	//	0					- in case of fail
	function browseProjects()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('project')." WHERE deleted = 'no' ORDER BY name";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getAllProjects()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('project')." WHERE deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getAllTasks()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getCompletedTasksForClientByMonth($i, $client_id)
	{
		$CI = &get_instance();

		$query = "SELECT t.id, t.user_id, t.project_id, t.name, t.description, t.estimated_time, t.create_date, t.complete_date, t.status, t.deleted FROM ".$CI->db->dbprefix('task')." t 
			LEFT JOIN ".$CI->db->dbprefix('project')." p ON p.id = t.project_id 
			LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON pv.project_id = p.id 
			WHERE t.status = 'Completed' AND pv.user_id = ".$client_id." AND DATE_FORMAT(t.complete_date, '%m') = ".$i." AND DATE_FORMAT(t.complete_date, '%Y') = ".date("Y");
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getClientProjects($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT pv.user_id, pv.project_id, p.id, p.name, p.deleted FROM ".$CI->db->dbprefix('project_view')." pv LEFT JOIN ".$CI->db->dbprefix('project')." p ON pv.project_id = p.id WHERE pv.user_id = ".$user_id." AND p.deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->num_rows();
		}
		else
		{
			return 0;
		}
	}

	function checkUserProjectExist($user_id, $project_id, $user_type)
	{
		$CI = &get_instance();

		if ($user_type == "client")
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('project_view')." WHERE user_id = ".$user_id." AND project_id = ".$project_id."";
		}

		if ($user_type == "developer")
		{
			$query = "SELECT ta.user_id, p.id FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id WHERE ta.user_id = ".$user_id." AND p.id = ".$project_id."";
		}

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getBillableHours($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT ta.task_id, t.estimated_time, t.name FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id WHERE t.status = 'Completed' AND t.deleted = 'no' AND ta.user_id = ".$user_id."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getProjectTasks($user_id, $status)
	{
		$CI = &get_instance();

		$query = "SELECT pm.user_id, pm.project_id FROM ".$CI->db->dbprefix('project_pm')." pm LEFT JOIN ".$CI->db->dbprefix('task')." t ON pm.project_id = t.project_id WHERE pm.user_id = ".$user_id." AND t.deleted = 'no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->num_rows();
		}
		else
		{
			return 0;
		}
	}

	function getTasksByProject($project_id, $status)
	{
		$CI = &get_instance();
		$status_query = "";

		if (strlen($status) > 0)
		{
			$status_query = "AND status = ".$CI->db->escape($status)." AND deleted = 'no'";
		}

		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE project_id = ".$project_id." ".$status_query." ";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function checkTaskInProgress($project_id)
	{
		$CI = &get_instance();
		$status_query = "";

		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE project_id = ".$project_id." AND status <> 'Completed' AND deleted='no'";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getDeveloperProjects($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT p.id, p.name FROM ".$CI->db->dbprefix('project')." p LEFT JOIN ".$CI->db->dbprefix('task')." t ON p.id = t.project_id LEFT JOIN ".$CI->db->dbprefix('task_assigned')." ta ON t.id = ta.task_id LEFT JOIN ".$CI->db->dbprefix('user')." u ON ta.user_id = u.id WHERE u.id = ".$CI->db->escape($user_id)." AND p.deleted = 'no' GROUP BY p.id ORDER BY p.name";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Get project completion percentage
	function getProjectCompletion($project_id)
	{
		$CI = & get_instance();

		$query 					= "SELECT * FROM task WHERE project_id = ".$CI->db->escape($project_id)." AND deleted = 'no'";
		$result 				= $CI->db->query($query);

		$query_complete_tasks 	= "SELECT * FROM task WHERE project_id = ".$CI->db->escape($project_id)." AND status = 'Completed' AND deleted = 'no'";
		$result_ct 				= $CI->db->query($query_complete_tasks);

		if ($result->num_rows() > 0)
		{
			// All tasks are completed
			if ($result->num_rows() == $result_ct->num_rows())
			{
				return 100;
			}
			// Check percentage
			else if ($result_ct->num_rows() > 0) 
			{
				$total 	= count($result->result());
				$compl 	= count($result_ct->result());

				$result = ($compl*100)/$total;
				return number_format(round($result), '0');
			}
			// No completed tasks => project completion 0%
			else
			{
				return 0;
			}
		}
		// No task assigned to project
		else
		{
			return 0;
		}
	}
}
?>