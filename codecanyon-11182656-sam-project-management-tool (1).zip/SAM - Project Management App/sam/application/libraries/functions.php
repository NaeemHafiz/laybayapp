<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Functions
{
	var $CI;

	function Functions()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	function sendEmail($sender, $receiver, $name, $subject, $message)
	{
		$from = $name." <".$sender.">";

		$headers = "From: ".$from."\r\n";
		$headers .= "Reply-To: ".$sender."\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

		$text = "<html><body>";
		$text .= $message;
		$text .= "</body></html>";

		if (mail($receiver, $subject, $text, $headers))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getCountries()
	{
		$CI = &get_instance();

		$query  = "SELECT id, country FROM ".$CI->db->dbprefix('countries')." ORDER BY country";
		$result =  $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getAllLanguages()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('languages')." ORDER BY language"; 
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Format date: MM-DD-YYY
	public function dateFormatUS($date_variable)
	{
		return date("M-Y-d", strtotime($date_variable));
	}

	// Format date : YYYY
	public function dateFormatYear($date_variable)
	{
		return date("Y", strtotime($date_variable));
	}

	// Format date : YYYY-MM-DD
	public function dateFormat($date_variable)
	{
		return date("Y-m-d", strtotime($date_variable));
	}

	// Format date : YYYY-MM-DD HH:II
	public function datetimeFormatMin($date_variable)
	{
		return date("Y-m-d H:i", strtotime($date_variable));
	}

	// Format date : YYYY-MM-DD HH:II:SS
	public function datetimeFormat($date_variable)
	{
		return date("Y-m-d H:i:s", strtotime($date_variable));
	}

	function getAllTaskPriorities()
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('task_priority_type'); 
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to create a log entry
	// Paremeter:
	//  text = string, the log text
	//
	// Rreturn 
	//  1-success
	//  0-fail
	function writelog($text)
	{
		$CI = &get_instance();
		$query = "INSERT INTO ".$CI->db->dbprefix('log')."(operation_date, operation_message) VALUES('".date("Y-m-d H:i:s")."', ".$CI->db->escape($text).")"; 
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to get log data
	// Paremeter:
	//
	// Rreturn 
	//  object_array-success
	//  0-fail
	function readlog($start = "", $offset = "", $search = "", $sort_col = "", $sort_dir = "")
	{
		$CI = & get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("operation_date","operation_message");

		$limit = $search_q = $status_q = "";
		$sort_q = " ORDER BY operation_date DESC ";

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			$sort_q = " ORDER BY ".$sort[$sort_col]." ".$sort_dir." ";
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(operation_message) LIKE '%".strtolower($search)."%' OR operation_date LIKE '%".strtolower($search)."%')";
		}
		$query = "SELECT * FROM ".$CI->db->dbprefix('log')." WHERE 1 ".$search_q.$sort_q.$limit;
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get user type names by id
	// Paremeter:
	//  id = int, id of user type
	//
	// Rreturn 
	//  obj_row	-success
	//  0		-fail
	function getUserTypeName($id)
	{
		$CI = &get_instance();
		$query = "SELECT * FROM user_type WHERE id=".$CI->db->escape($id); 
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}
}
?>