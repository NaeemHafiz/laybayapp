<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Taskslib
{
	var $CI;

	function Taskslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	// Function to get one task informations
	//
	// Parameters:
	//
	// 	task_id 	-  task_id integer
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function getTaskInfo($task_id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE id = ".$CI->db->escape($task_id)."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	// Function to get task assigned data
	//
	// Parameters:
	//
	// 	task_id 	-  task_id integer
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function getAssignedTask($task_id)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('task_assigned')." WHERE task_id = ".$CI->db->escape($task_id)."";
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to modify tasks
	//
	// Parameters:
	//
	// task_id 			 - task_id integer
	// task_name 		 - task name string
	// task_description  - task_description string
	// task_due_date	 - task_due_date date
	// task_assigned_to  - task_assigned_to integer
	// task_type 		 - task_type string 
	// task_value 		 - task_value integer	 
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function modifyTasks($task_id, $task_project_id, $task_priority, $task_name, $task_description, $task_estimated_cost, $due_date, $status)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task')." SET project_id = ".$CI->db->escape($task_project_id).", priority_id = ".$task_priority.", name = ".$CI->db->escape($task_name).", description = ".$CI->db->escape($task_description).", estimated_time = ".$CI->db->escape($task_estimated_cost).", due_date = ".$CI->db->escape($due_date).", status = ".$CI->db->escape($status)." WHERE id = ".$CI->db->escape($task_id)." ";
		$result = $CI->db->query($query);

		if (!$CI->db->_error_message())
    	{
    		return 1;
    	}
    	else
    	{
    		return 0;
    	}
	}

	// Function to modify tasks assigned
	//
	// Parameters:
	//
	// task_id 			 - task_id integer
	// task_assigned_to  - task_assigned_to
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function modifyTasksAssigned($task_id, $task_assign_to)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task_assigned')." SET user_id = ".$CI->db->escape($task_assign_to)." WHERE task_id = ".$CI->db->escape($task_id)." ";
		$result = $CI->db->query($query);

		if (!$CI->db->_error_message())
    	{
    		return 1;
    	}
    	else
    	{
    		return 0;
    	}
	}

	// Function to get developer tasks(in progress and assigned)
	//
	// Parameters:
	// user_id 			- id of task to be deleted
	//
	// Returns:
	//	obj_array 		- in case of success
	//	0				- in case of fail

	function getDeveloperTasks($dev_id, $start = "", $offset = "", $search = "",  $sort_col = "", $sort_dir = "")
	{
		$CI = & get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("t.name", "project", "t.create_date", "t.due_date", "t.status");

		$limit = $search_q = "";
		$dev_q = " AND ta.user_id = (SELECT MAX(user_id) FROM task_assigned LIMIT 1) ";
		$sort_q = " ORDER BY t.create_date DESC ";

		// We return no results if id is not set
		if (strlen($dev_id) > 0)
		{
			$no_res = "";
		}
		else
		{
			$no_res = " AND 1 = 0 ";
		}

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			if ($sort_col != 0)
			{
				$sort_q = " ORDER BY ".$sort[$sort_col]." ".$sort_dir." ";
			}
			else
			{
				$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
			}
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(t.name) LIKE '%".strtolower($search)."%' OR LOWER(p.name) LIKE '%".strtolower($search)."%' OR LOWER(t.status) LIKE '%".strtolower($search)."%')";
		}

		// First time no dev is selected
		if (strlen($dev_id) > 0)
		{
			$dev_q = " AND ta.user_id = ".$CI->db->escape($dev_id)." "; 
		}

		$query = "SELECT t.name, p.name as project, t.create_date, t.due_date, t.status, t.id, t.user_id, t.priority_id, t.description, t.estimated_time, t.complete_date, t.deleted 
					FROM task t 
					LEFT JOIN project p ON t.project_id = p.id 
					LEFT JOIN task_assigned ta ON ta.task_id = t.id  
					WHERE (t.status = 'In Progress' OR t.status = 'Assigned') AND t.deleted='no'".$no_res.$dev_q.$search_q."
					GROUP BY t.id ".$sort_q.$limit;
		$result = $CI->db->query($query);

		if ($result->num_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	// Function to delete tasks
	//
	// Parameters:
	// task_id 			- id of task to be deleted
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function deleteTask($task_id)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task')." SET deleted = 'yes' WHERE id = '".$task_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to add tasks comments
	//
	// Parameters:
	// task_id 			- id of task
	// user_id 			- id of user
	// comment 			- task comment 
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function addTaskComments($task_id, $user_id, $comment)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('task_comments')." (task_id, user_id, comment, create_date, deleted) VALUES (".$CI->db->escape($task_id).", ".$CI->db->escape($user_id).", ".$CI->db->escape($comment).", '".date('Y-m-d H:i:s')."', 'no')";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	// Function to add attachments to tasks comments
	//
	// Parameters:
	// task_id 			- id of task
	// user_id 			- id of user
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function addCommentAttachments($comment_id, $attachments)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task_comments')." SET attachments = ".$CI->db->escape($attachments)." WHERE id = '".$comment_id."' ";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to add attachments to tasks
	//
	// Parameters:
	// task_id 			- id of task
	// user_id 			- id of user
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function addTaskAttachments($task_id, $attachments)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task')." SET attachments = ".$CI->db->escape($attachments)." WHERE id = '".$task_id."' ";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Function to get task comments
	//
	// Parameters:
	// task_id 			- id of task
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function getTaskComments($task_id)
	{
		$CI = &get_instance();

		$query = " SELECT tc.task_id, tc.user_id, tc.comment, tc.create_date, tc.attachments, up.first_name, up.last_name, up.picture FROM ".$CI->db->dbprefix('task_comments')." tc LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON tc.user_id = up.user_id WHERE tc.task_id = '".$task_id."' ";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	// Function to get assigned Developer 
	//
	// Parameters:
	// task_id 			- id of task
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	function getTaskAssignedDeveloper($task_id, $for)
	{
		$CI = & get_instance();

		// First query is to select all pms
		$sql_pm_ids = "";
		$query_pm = "SELECT pp.user_id FROM ".$CI->db->dbprefix('project_pm')." pp LEFT JOIN ".$CI->db->dbprefix('task')." t ON pp.project_id = t.project_id WHERE t.id = '".$task_id."'";

		$result_pm = $CI->db->query($query_pm);
		if ($CI->db->affected_rows() > 0)
		{
			// We check if the query is for email sending
			if ($for == 'email')
			{
				// We add a partial query to exclude the chance that, if a pm is also a developer on a task in the sam project, not to get notification email 2 times
				$pm_ids = $result_pm->result();
				if (count($pm_ids) > 0)
				{
					foreach ($pm_ids as $elem) {
						$sql_pm_ids .= " AND ta.user_id != ".$elem->user_id." ";
					}
				}
			}

			$query = "SELECT ta.user_id, ta.task_id, up.first_name, up.id, up.email, up.last_name, up.receive_email, t.create_date FROM ".$CI->db->dbprefix('task_assigned')." ta LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON ta.user_id = up.user_id LEFT JOIN ".$CI->db->dbprefix('task')." t ON ta.task_id = t.id WHERE ta.task_id = '".$task_id."' AND ta.user_id != 0 ".$sql_pm_ids;
			$result = $CI->db->query($query);

			if ($CI->db->affected_rows() > 0)
			{
				return $result->result();
			}
			else
			{
				return 0;
			}
		}
	}

	// Function to update task status and set priority to normal if status is completed
	//
	// Parameters:
	//
	// 	task_id 	-  task_id integer
	// Returns:
	//
	//	1 			- returns id of added user
	//	0 			- in case of error

	function updateTaskStatus($task_id, $status) 
	{
		$CI = &get_instance();
		if ($status == "Completed")
		{
			$query = "UPDATE ".$CI->db->dbprefix('task')." SET status = ".$CI->db->escape($status).", priority_id = '1'  WHERE id = '".$task_id."'";
		}
		else
		{
			$query = "UPDATE ".$CI->db->dbprefix('task')." SET status = ".$CI->db->escape($status)." WHERE id = '".$task_id."'";
		}
		$result = $CI->db->query($query);

		if ($CI->db->_error_message())
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	// Function to update task estimated time
	//
	// Parameters:
	// task_id 			- id of task
	// estimated_time 	- estimated time
	//
	// Returns:
	//	1 				- in case of success
	//	0				- in case of fail

	public function updateEstimatedTime($task_id, $time, $due_date)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task')." SET estimated_time = ".$CI->db->escape($time).", due_date = '".$due_date."' WHERE id = ".$CI->db->escape($task_id)."";
		$result = $CI->db->query($query);

		if ($CI->db->_error_message())
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	function updateTaskCompleteDate($id, $date)
	{
		$CI = &get_instance();

		$query = "UPDATE ".$CI->db->dbprefix('task')." SET complete_date = ".$CI->db->escape($date)." WHERE id = ".$CI->db->escape($id)."";
		$result = $CI->db->query($query);

		if ($CI->db->_error_message())
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	function checkUserTaskExist($user_id, $task_id, $user_type)
	{
		$CI = &get_instance();

		if ($user_type == "client")
		{
			$query = "SELECT t.id, pv.user_id FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('project')." p ON t.project_id = p.id LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON p.id = pv.project_id WHERE t.id = ".$task_id." AND pv.user_id = ".$user_id." ";
		}

		if ($user_type == "developer")
		{
			$query = "SELECT * FROM ".$CI->db->dbprefix('task_assigned')." ta WHERE user_id = ".$user_id." AND task_id = ".$task_id."";
		}

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getUserTasks($user_id)
	{
		$CI = &get_instance();

		$query = "SELECT t.id FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON t.project_id = pv.project_id WHERE pv.user_id = '".$user_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getShareByStatus($user_id, $status)
	{
		$CI = &get_instance();

		$query = "SELECT t.id FROM ".$CI->db->dbprefix('task')." t LEFT JOIN ".$CI->db->dbprefix('project_view')." pv ON t.project_id = pv.project_id WHERE status = ".$CI->db->escape($status)." AND pv.user_id = '".$user_id."'";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}

	function getUserTaskCountByStatus($user_id, $status, $start_date = "", $end_date = "")
	{
		$CI = & get_instance();

		$date_range = "";
		if (strlen($start_date) > 0 && strlen($end_date) > 0 && strpos($end_date, 'NaN') === false && strpos($start_date, 'NaN') === false)
		{
			$date_range = " AND t.complete_date <= '".$end_date."' AND t.complete_date >= '".$start_date."'";
		}

		$query = "SELECT count(t.id) as cnt FROM ".$CI->db->dbprefix('task')." t LEFT JOIN task_assigned ta ON t.id = ta.task_id WHERE t.status = ".$CI->db->escape($status)." AND ta.user_id = '".$user_id."' AND deleted='no'".$date_range;
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->row()->cnt;
		}
		else
		{
			return 0;
		}
	}

	function getTaskIdByTitle($title)
	{
		$CI = &get_instance();

		$query = "SELECT * FROM ".$CI->db->dbprefix('task')." WHERE name = ".$CI->db->escape($title);
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->row();
		}
		else
		{
			return 0;
		}
	}

	function deleteTaskAssignedWorkers($task_id)
	{
		$CI = &get_instance();

		$query = "DELETE FROM ".$CI->db->dbprefix('task_assigned')." WHERE task_id = ".$task_id."";
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	function getManagedTasks($user_id, $start = "", $offset = "", $search = "", $sort_col = "", $sort_dir = "", $user_type = "")
	{
		$CI = &get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("t.name","p.name","t.create_date","up.first_name","t.status");

		$search_q 	= $limit = $user_q = "";
		$sort_q 	= " ORDER BY tpt.id DESC, t.create_date DESC, t.id DESC ";

		// Sort query part
		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			if ($sort_col != 0)
			{
				$sort_q = " ORDER BY ".$sort[$sort_col]." ".$sort_dir." ";
			}
			else
			{
				$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
			}
		}

		// Check user
		if ($user_type != 1)
		{
			$user_q = " AND pm.user_id = ".$user_id." ";
		}

		// Limit query part
		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		// Search query part
		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(t.name) LIKE '%".strtolower($search)."%' OR LOWER(p.name) LIKE '%".strtolower($search)."%' OR LOWER(t.status) LIKE '%".strtolower($search)."%' OR LOWER(up.first_name) LIKE '%".strtolower($search)."%' OR LOWER(up.last_name) LIKE '%".strtolower($search)."%' OR CONCAT(LOWER(up.first_name),' ',LOWER(up.last_name)) LIKE '%".strtolower($search)."%')";
		}

		$query = "SELECT t.id, t.user_id, tpt.name as priority, t.create_date, t.due_date, t.project_id, t.name, t.complete_date, t.status, p.name AS pname, up.first_name, up.last_name FROM task t 
		LEFT JOIN task_assigned ta ON t.id = ta.task_id
		LEFT JOIN user_profile up ON t.id = ta.task_id AND ta.user_id = up.user_id 
		LEFT JOIN task_priority_type tpt ON t.priority_id = tpt.id 
		LEFT JOIN project p ON t.project_id = p.id 
		LEFT JOIN project_pm pm ON p.id = pm.project_id 
		WHERE 1 ".$user_q." AND t.deleted='no'".$search_q." GROUP BY t.id ".$sort_q.$limit;
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	function getTaskDevelopers($task_id)
	{
		$CI = &get_instance();

		$query = "SELECT up.first_name, up.last_name, up.id, up.user_id FROM user_profile up LEFT JOIN task_assigned ta ON up.user_id = ta.user_id WHERE ta.task_id = ".$CI->db->escape($task_id);
		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}
}
?>