<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Clientslib
{
	var $CI;

	function Clientslib()
	{
		$CI = &get_instance();
		$CI->load->database();
		$CI->load->library("session");
	}

	function addClient($client_uname, $client_cpword)
	{
		$CI = &get_instance();
		$md5variable = md5($client_cpword);

		$query = "INSERT INTO ".$CI->db->dbprefix('user')." (username, password, type_id, active, deleted) VALUES (".$CI->db->escape($client_uname).", ".$CI->db->escape($md5variable).", '4', 'yes', 'no')";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	function addClientProfile($client_id, $client_fname, $client_lname, $client_email, $client_phone, $client_cname, $home_page, $client_country, $client_city)
	{
		$CI = &get_instance();

		$query = "INSERT INTO ".$CI->db->dbprefix('user_profile')." (user_id, first_name, last_name, create_date, email, telephone, comp_name, homepage, id_country, city) VALUES (".$CI->db->escape($client_id).", ".$CI->db->escape($client_fname).", ".$CI->db->escape($client_lname).", '".date("Y-m-d")."', ".$CI->db->escape($client_email).", ".$CI->db->escape($client_phone).", ".$CI->db->escape($client_cname).", ".$CI->db->escape($home_page).", ".$CI->db->escape($client_country).", ".$CI->db->escape($client_city).")";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $CI->db->insert_id();
		}
		else
		{
			return 0;
		}
	}

	function getClients($status, $start = "", $offset = "", $search = "",  $sort_col = "", $sort_dir = "")
	{
		$CI = &get_instance();

		// Initialize the sort array with column names, to know the sort indexes. MANUALLY INSERTED
		$sort = array("up.first_name", "up.email", "up.comp_name");

		$limit = $search_q = $status_q = "";
		$sort_q = " ORDER BY up.first_name ";

		if (strlen($sort_col) > 0 && strlen($sort_dir) > 0)
		{
			$sort_q = " ORDER BY LOWER(".$sort[$sort_col].") ".$sort_dir." ";
		}

		if (strlen($start) > 0 && strlen($offset) > 0)
		{
			$limit = " LIMIT ".$start.", ".$offset;
		}

		if (strlen($search) > 0)
		{
			$search_q = " AND (LOWER(up.first_name) LIKE '%".strtolower($search)."%' OR LOWER(up.last_name) LIKE '%".strtolower($search)."%' OR LOWER(up.email) LIKE '%".strtolower($search)."%' OR LOWER(up.comp_name) LIKE '%".strtolower($search)."%') ";
		}

		// If we have a status
		if ($status != 'all')
		{
			$status_q = " AND u.active = ".$CI->db->escape($status)." "; 
		}

		$query = "SELECT u.id, u.type_id, up.first_name, up.last_name, up.email, up.comp_name, u.active FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON u.id = up.user_id WHERE u.type_id = '4' ".$status_q.$search_q.$sort_q.$limit;

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result_array();
		}
		else
		{
			return 0;
		}
	}

	function getLastsClients()
	{
		$CI = &get_instance();
		
		$query = "SELECT u.id, up.user_id, u.type_id, up.first_name, up.last_name, up.email, up.comp_name, up.picture, up.create_date FROM ".$CI->db->dbprefix('user')." u LEFT JOIN ".$CI->db->dbprefix('user_profile')." up ON u.id = up.user_id WHERE u.type_id = '4' and u.deleted = 'no' ORDER BY u.id DESC LIMIT 0, 5 ";

		$result = $CI->db->query($query);

		if ($CI->db->affected_rows() > 0)
		{
			return $result->result();
		}
		else
		{
			return 0;
		}
	}
}
?>