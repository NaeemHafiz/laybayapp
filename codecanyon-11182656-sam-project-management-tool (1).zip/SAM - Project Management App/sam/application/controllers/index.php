<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');

		$data['username'] = $this->session->userdata('username');

		$this->load->view('index', $data);
	}
}