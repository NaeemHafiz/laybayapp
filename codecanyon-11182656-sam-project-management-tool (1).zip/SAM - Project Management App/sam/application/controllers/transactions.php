<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Transactions extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library("transactionlib");
		$this->load->library("userslib");
		$this->load->library("taskslib");

		$user_id = $this->session->userdata("user_id");
		
		$transactions = $this->transactionlib->getUserTransactions($user_id);

		$i = 0;

		if (is_array($transactions))
		{
			foreach ($transactions as $elem) 
			{
				$task_info = $this->taskslib->getTaskIdByTitle($elem->title);
				
				if (is_object($task_info))
				{
					$transactions[$i]->task_id = $task_info->id; 
				}
				else
				{
					$transactions[$i]->task_id = 0;
				}
				
				$i++;
			}
		}

		$data["transactions"]   = $transactions;
		$data["profile_info"] 	= $this->userslib->getUserProfile($user_id);

		$this->load->view('transactions', $data);
	}


	public function cashout()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library("transactionlib");
		$this->load->library('functions');

		$cashout 		= $this->input->post("cashout");
		$user_id 		= $this->session->userdata("user_id");
		$title 	 		= $this->config->item("company")." Cashout";
		$check	        = $this->userslib->getUserProfile($user_id);
		
		$result = 0;
		
		if (($cashout <= $check->balance) && ($cashout != 0))
		{
			// Modify balance in user_profile 
			$this->userslib->modifyUserProfileBalance($user_id, "minus", $cashout);

			// Get user profile info
			$profile_info 	= $this->userslib->getUserProfile($user_id);
			$result 		= $this->transactionlib->CashOutTransaction($user_id, $title, $cashout, $profile_info->balance);

			// Send email to owner
			$sender = $this->config->item('sender_email');
			$receiver = $this->config->item('accounting_email');
			$name = $this->config->item('sender_name');
			$subject = $profile_info->first_name." ".$profile_info->last_name.' has cashout '.$cashout.' hours';
			$message = 'Hi there,<br><br>
					Please note that '.$profile_info->first_name." ".$profile_info->last_name.' has cashout '.$cashout.' hours from his balance.<br>
					Payment should be sent to this PayPal account: '.$profile_info->paypal_account.'<br><br>

					Thanks,<br>
					'.$this->config->item('sender_name');

			$this->functions->sendEmail($sender, $receiver, $name, $subject, $message);

			// Create a log entry for the cashout
			$text = $profile_info->first_name." ".$profile_info->last_name." has cashed out ".$cashout." hours";
			$this->functions->writelog($text);
		}
		
		$operation = array();

		if ($result == 1)
		{
			$operation["success"] = 1;
		}
		else
		{
			$operation["success"] = 0;
		}

		echo json_encode($operation);
	}

	public function addBonus()
	{
		$this->load->library('transactionlib');
		$this->load->library('functions');
		$this->load->library('userslib');
		$this->load->library('session');
		$this->load->library('projectslib');

		$user_id 	= $this->input->post('bonus_developer');
		$amount 	= $this->input->post('bonus_amount');
		$project_id = $this->input->post('bonus_project');
		$message 	= $this->input->post('bonus_message');
		$pm_id 		= $this->session->userdata('user_id');

		$operation 	= array();

		$user_info 	= $this->userslib->getUserProfile($user_id);
		$pm_info 	= $this->userslib->getUserProfile($pm_id);
		$project 	= $this->projectslib->getProjectData($project_id);
		$result 	= $this->transactionlib->addBonusToDeveloper($user_id, $amount);

		if ($result == 1)
		{
			$sender = $this->config->item('sender_email');
			$receiver = $user_info->email;
			$name = $this->config->item('sender_name');
			$subject = 'Bonus Received';
			$message = 'Hi '.$user_info->first_name.',
			<br /><br />
			You have received a '.$amount.' hour(s) bonus from '.$pm_info->first_name.' '.$pm_info->last_name.' for '.$project->name.' project.
			<br /><br />
			Message:
			<br />
			'.$message.'
			<br /><br />
			Thanks,<br />
			'.$this->config->item('sender_name');

			$this->functions->sendEmail($sender, $receiver, $name, $subject, $message);

			// Log the action
			$text = "Developer ".$user_info->first_name." ".$user_info->last_name." has received ".$amount." hour(s) bonus from ".$pm_info->first_name." ".$pm_info->last_name." for ".$project->name." project";
			$this->functions->writelog($text);

			$operation["success"] = 1;
		}
		else
		{
			$operation['success'] = 0;
		}

		echo json_encode($operation);
	}

}