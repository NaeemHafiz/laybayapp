<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library("settingslib");
		$this->load->library("userslib");

		$settings = $this->settingslib->getSettings();

		$data["settings"] = $settings;
		$data["user_types"] = $this->userslib->getUserTypes("no");

		$this->load->view('settings', $data);
	}

	public function edit_settings()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library("settingslib");
		$this->load->library("userslib");

		$company 			= $this->input->post("company");
		$contact_email 		= $this->input->post("contact_email");
		$accounting_email 	= $this->input->post("accounting_email");
		$sender_name 		= $this->input->post("sender_name");
		$sender_email 		= $this->input->post("sender_email");
		$show_credits 		= $this->input->post("show_credits");
		$send_emails 		= $this->input->post("send_emails");
		$multi_language 	= $this->input->post("multi_language");
		$enable_tickets 	= $this->input->post("enable_tickets");

		if (strlen($show_credits) > 0)
		{
			$show_credits = "yes";
		}
		else
		{
			$show_credits = "no";
		}

		if (strlen($send_emails) > 0)
		{
			$send_emails = "yes";
		}
		else
		{
			$send_emails = "no";
		}

		if (strlen($multi_language) > 0)
		{
			$multi_language = "yes";
		}
		else
		{
			$multi_language = "no";
		}

		if (strlen($enable_tickets) > 0)
		{
			$enable_tickets = "yes";
		}
		else
		{
			$enable_tickets = "no";
		}

		$result = 0;	
		$result = $this->settingslib->editSettings($company, $contact_email, $accounting_email, $sender_name, $sender_email, $enable_tickets, $show_credits, $send_emails, $multi_language);

		$operation = array();
		
		if ($result == 1)
		{
			$operation["success"] = 1;
		}
		else
		{
			$operation["success"] = 3;
		}

		echo json_encode($operation);
	}

	public function edit_user_types()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library("settingslib");
		$this->load->library("userslib");

		$user_types_nr = $this->input->post("user_types_nr");

		for ($i=0; $i <= $user_types_nr; $i++) 
		{ 
			$new_user_type = $this->input->post("user_type_nr_".$i);
			$db_id = $i+1;
			$res = $this->userslib->updateUserTypes($db_id, $new_user_type);
		}

		$operation = array();

		if ($res == 1)
		{
			$operation["success"] = 1;
		}
		else
		{
			$operation["success"] = 0;
		}

		echo json_encode($operation);
	}

	public function generateClientKey()
	{
		$this->load->library('userslib');

		$random_key = $this->userslib->rand_string(30);

		echo $random_key;
	}

}