<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->helper('cookie');
		$this->load->library('session');

		$this->load->library('userslib');
		
		$cookie_id 	= $this->input->cookie('id');
		$cookie_key = $this->input->cookie('key');

		if (isset($cookie_id) && $cookie_id != 0)
		{
			$user_data 		= $this->userslib->getUserData($cookie_id);
			$magicword 		= "intelcoderrocks";
			$my_password 	= $user_data->password;
			$my_key 		= md5($cookie_id.$magicword.$my_password);

			if ($my_key == $cookie_key)
			{
				$login = $this->userslib->userLoginFromCookie($user_data->username, $user_data->password);

				if ($login == 1)
				{
					redirect(base_url().'dashboard');
				}
			}
		}

		$this->load->view('login');
	}

	public function doLogin()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->helper('cookie');

		$this->load->library('userslib');
		$this->load->library('session');

		$username 		= $this->input->post('username');
		$password 		= $this->input->post('password');
		$user_info 		= $this->userslib->getUserByUsername($username);

		if (is_object($user_info))
		{
			$user_id 	= $user_info->id;
		}
		else
		{
			$user_id = 0;
		}

		$output			= array();

		$login 			= $this->userslib->userLogin($username, $password);
		$remember_me 	= $this->input->post('remember');

		if ((isset($remember_me)) && ($user_id > 0))
		{
			$magicword = "intelcoderrocks";
			$codedPassword = md5($password);
			$cookiestring = md5($user_id.$magicword.$codedPassword);
			$this->input->set_cookie("key", $cookiestring, time() + 60*60*24*30);
			$this->input->set_cookie("id", $user_id, time() + 60*60*24*30);
		}

		if ($login == 0)
		{
			$output["success"] = 0;
		}
		else
		{
			$output["success"] = 1;
		}

		$result = json_encode($output);
		echo $result;
	}

	public function doLogout()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->helper('cookie');

		$this->load->library('userslib');
		$this->load->library('session');

		$this->userslib->userLogout();

		if (isset($_COOKIE['id']))
		{
			$this->input->set_cookie("key", '', time() - 3600);
			$this->input->set_cookie("id", '', time() - 3600);
		}

		redirect(base_url());
	}
}