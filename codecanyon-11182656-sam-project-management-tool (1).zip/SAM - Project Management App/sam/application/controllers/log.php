<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Log extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('functions');

		$log = $this->functions->readlog();

		if (is_array($log))
		{
			$data['log'] = $log;
		}
		else
		{
			$data['log'] = "";
		}

		$this->load->view('log', $data);
	}

	public function getLogs()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('functions');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$status 		= $this->input->get('status');

		if (strlen($status) < 1)
		{
			$status = "yes";
		}

		if (strlen($search) > 0)
		{
			$logs 				= $this->functions->readlog($start, $offset, $search, $sort_col, $sort_dir);
			$logs_pagination 	= $this->functions->readlog("", "", $search, $sort_col, $sort_dir);
		}
		else
		{
			$logs 				= $this->functions->readlog($start, $offset, "", $sort_col, $sort_dir);
			$logs_pagination 	= $this->functions->readlog("", "", "", $sort_col, $sort_dir);
		}

		$logs_data = array();

		if (is_array($logs))
		{
			for ($j=0; $j < count($logs); $j++) 
			{ 
				$logs_data[$j][] = $logs[$j]->operation_date;
				$logs_data[$j][] = $logs[$j]->operation_message;
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($logs_pagination),
			"iTotalDisplayRecords" => count($logs_pagination),
			"aaData" => $logs_data
		);

		echo json_encode($output);
	}
}