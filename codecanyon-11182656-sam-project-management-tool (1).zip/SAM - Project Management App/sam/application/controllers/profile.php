<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller {

	// Index function, which loads the profile page
	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('functions');

		$data['username'] 	= $this->session->userdata('username');
		$user_id 			= $this->session->userdata('user_id');
		$data['user_info']	= $this->userslib->getMemberInfo($user_id);
		$data['countries'] 	= $this->functions->getCountries();
		$data['languages'] 	= $this->functions->getAllLanguages();

		$user_type = $this->session->userdata('user_type');

		$this->load->view('profile', $data);
	}

	// Function to save profile modifications
	public function editProfile_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');

		// Return array for the ajax request
		$result = array();

		// Getting the actual session variables to check for duplicates
		$user_id_session 	= $this->session->userdata('user_id');
		$password_session 	= $this->session->userdata('password');
		$account_type 		= $this->session->userdata('user_type');

		// Getting the input values
		$password_new 	= $this->input->post('conf_pw');
		$password_old 	= $this->input->post('curr_pw');
		$user_fname 	= $this->input->post('fname');
		$user_lname 	= $this->input->post('lname');
		$user_email 	= $this->input->post('email');
		$paypal_account = $this->input->post('paypal_email');
		$user_phone 	= $this->input->post('phone');
		$comp_name 		= $this->input->post('comp_name');
		$country		= $this->input->post('profile_country');
		$city			= $this->input->post('city');
		$rcv_email 		= $this->input->post('send_email');
		$rcv_notif 		= $this->input->post('onsite_notification');

		$check_email = $this->userslib->checkEmailExists($user_email, $user_id_session);  
		$home_page = $this->input->post('profile_home_page');
		
		// Check if session old pass matches the old pass input field, save accordingly
		$result = 0;

		if (strlen($password_old) > 0)
		{
			if (md5($password_old) == $password_session)
			{
				$this->userslib->modifyUser($user_id_session, $password_new, $account_type, 'yes');
				
				if ($check_email == 0)
				{
					$result = $this->userslib->modifyUserProfile($user_id_session, $user_fname, $user_lname, $user_email, $paypal_account, $user_phone, $comp_name, $home_page, $country, $city, $rcv_email, $rcv_notif);
				}
			}
		}
		else
		{
			$this->userslib->modifyUser($user_id_session, $password_new, $account_type, 'yes');

			if ($check_email == 0)
			{
				$result = $this->userslib->modifyUserProfile($user_id_session, $user_fname, $user_lname, $user_email, $paypal_account, $user_phone, $comp_name, $home_page, $country, $city, $rcv_email, $rcv_notif);
			}
		}
		
		$operation = array();

		if ($result == 1)
		{
			if ($check_email == 1)
			{
				$operation['success'] = 2;
			}
			else
			{
				$operation['success'] = 1;
			}
		}
		else
		{
			if ($check_email == 1)
			{
				$operation['success'] = 2;
			}
			else
			{
				$operation['success'] = 0;
			}
		}

		echo json_encode($operation);
	}

	// Function to show add user window
	public function addUser_show()
	{
		$this->load->helper('url');
		$this->load->helper('language');

		$this->load->view('useradd_view');
	}

	// Function to add user to database
	public function addUser_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');

		// Return array for the ajax request
		$result = array();

		// User ID from session
		$user_id = $this->session->userdata('user_id');

		// Getting the input values
		$username = $this->input->post('user_profile_username');
		$password = $this->input->post('user_profile_password');
		$user_type = $this->input->post('user_type');
		$user_fname = $this->input->post('user_profile_fname');
		$user_lname = $this->input->post('user_profile_lname');
		$user_email = $this->input->post('user_profile_email');
		$user_phone = $this->input->post('user_profile_phone');
		$user_hrate = $this->input->post('user_profile_hrate');

		// Check if username already exists. If it does, return error message
		$operation = checkUsernameExists($username);

		if ($operation == 1)
		{
			$result['error'] = 1;
			$result['message'] = "Username already exists!";

			echo json_encode($result);
			return;
		}

		$result_user = $this->userslib->addUser($username, md5($password), $user_type);
		$result_profile = $this->userslib->addUserProfile($user_id_session, $user_fname, $user_lname, $user_email, $user_phone, $user_hrate);

		if ($result_user != 0 && $result_profile != 0)
		{
			$result['error'] = 0;
			$result['message'] = "User added successfully!";
		}
		else
		{
			$result['error'] = 1;
			$result['message'] = "User cannot be added!";
		}

		echo json_encode($result);
	}

	public function logOut()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->helper('cookie');
		$this->load->library('userslib');
		$id_cookie = $this->input->cookie('id');

		$this->userslib->userLogout();

		if (isset($id_cookie))
		{
			$this->input->set_cookie('id', '', time() - 3600);
			$this->input->set_cookie('key', '', time() - 3600);
		}

		$result["error"] = 0;
		$result["error_message"] = "Logout";

		echo json_encode($result);
	}

	public function uploadAvatar()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');

		$user_id = $this->session->userdata('user_id');

		$operation = array();
		
		$config['upload_path'] = './uploads/avatars';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '2048';

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload())
		{
			redirect(base_url()."profile?message=".$this->upload->display_errors());
		}
		else
		{
			$upload_data = $this->upload->data();
			$path = $upload_data["file_name"];
			$this->userslib->updateAvatar($user_id, $path);
			redirect(base_url()."profile");
		}
	}

	public function add_todo()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('functions');

		$user_id 	= $this->input->post('user_id');
		$task 		= $this->input->post('todo_task');
		$due_date 	= $this->input->post('todo_due_date');

		$result = $this->userslib->addTodo($user_id, $task, $due_date);

		if ($result == 0)
		{
			$return['success'] = 0;
		}
		else
		{
			$return['success'] 	= 1;
			$return['todo_id'] 	= $result;
			$return['due_date'] = $this->functions->dateFormat($due_date);
		}

		echo json_encode($return);
	}

	public function delete_todo()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');

		$todo_id = $this->input->post('todo_id');

		$result = $this->userslib->deleteTodo($todo_id);

		if ($result == 1)
		{
			$return['success'] = 1;
		}
		else
		{
			$return['success'] = 0;
		}

		echo json_encode($return);
	}

	// Function to get all the projects for a developer
	public function getDeveloperProjects()
	{
		$this->load->library('projectslib');

		$user_id = $this->input->post('user_id');

		// The return string
		$str = "";

		$result = $this->projectslib->getDeveloperProjects($user_id);

		if (is_array($result))
		{
			foreach ($result as $elem) {
				$str .= "<option value='".$elem->id."'>".$elem->name."</option>";
			}
		}

		echo $str;
	}

}