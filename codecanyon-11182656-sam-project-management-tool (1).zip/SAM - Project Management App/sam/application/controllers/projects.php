<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Projects extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');

		$user_id 	= $this->session->userdata('user_id');
		$user_type 	= $this->session->userdata('user_type');

		$data['username']			= $this->session->userdata('username');
		$data['user_type']  		= $this->session->userdata('user_type');
		$data['projects']			= $this->projectslib->getUserProjects($user_type, $user_id, "completed_yes");
		$data['user_types'] 		= $this->userslib->getUserTypes("");

		$this->load->view('projects', $data);
	}

	public function edit($slug)
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');

		$project_id = $slug;
		$array_c = $array_p = array();

		// Get array with clients id and pm id
		$assigned_clients = $this->projectslib->getAssignedClientsId($project_id);
		if (is_array($assigned_clients))
		{
			foreach ($assigned_clients as $elem) {
				array_push($array_c, $elem->id);
			}
		}

		$assigned_pms = $this->projectslib->getAssignedPMsId($project_id);
		if (is_array($assigned_pms))
		{
			foreach ($assigned_pms as $elem) {
				array_push($array_p, $elem->id);
			}
		}

		$data['username'] 			= $this->session->userdata('username');
		$data['project'] 			= $this->projectslib->getProjectData($project_id);
		$data['pm_names'] 			= $this->userslib->getProjectManagerNames();
		$data['client_names'] 		= $this->userslib->getClientNames();
		$data['assigned_pm'] 		= $array_p;
		$data['assigned_client'] 	= $array_c;
		$data['user_types'] 		= $this->userslib->getUserTypes("");

		$user_type = $this->session->userdata('user_type');

		if ($user_type > 2)
		{
			redirect(base_url());
		}

		$this->load->view('project_edit', $data);
	}

	public function project_edit_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('functions');

		$project_id = $this->input->post('project_id');
		$project_name = $this->input->post('pname');
		$project_description = $this->input->post('pdesc');
		$project_due_date = $this->functions->datetimeFormat($this->input->post('pddate'));
		$query_result = $this->projectslib->modifyProject($project_id, $project_name, $project_description, $project_due_date);

		$result = array();
		$error = 0;

		// Project manager assignments
		$assigned_pms = $this->input->post('pms');
		$assigned_pms = explode(',', $assigned_pms);
		$count_pms = count($assigned_pms);

		// Client assignments
		$assigned_clients = $this->input->post('clients');

		if ($assigned_clients != "" && $assigned_clients != null && $assigned_clients != 0)
		{
			$assigned_clients = explode(',', $assigned_clients);
			$count_clients = count($assigned_clients);
		}
		else
		{
			$count_clients = 0;
		}

		$clear_client = $this->projectslib->deleteProjectClient($project_id);
		$clear_pms = $this->projectslib->deleteProjectPM($project_id);

		if ($clear_pms != 0 && $clear_client != 0)
		{
			for ($i = 0; $i < $count_pms; $i++)
			{
				$operation = $this->projectslib->modifyProjectPM($project_id, $assigned_pms[$i]);

				if ($operation == 0)
				{
					$error = 1;
					break;
				}
			}

			for ($i = 0; $i < $count_clients; $i++)
			{
				$operation = $this->projectslib->modifyProjectClient($project_id, $assigned_clients[$i]);

				if ($operation == 0)
				{
					$error = 1;
					break;
				}
			}

			if ($error == 1)
			{
				$result['success'] = 0;
			}
			else
			{
				$result['success'] = 1;
			}
		}
		else
		{
			$result["success"] = 0;
		}

		echo json_encode($result);

	}

	public function add()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');

		$data['username']	  = $this->session->userdata('username');
		$data['user_type']    = $this->session->userdata('user_type');
		$data['pm_names'] 	  = $this->userslib->getProjectManagerNames();
		$data['client_names'] = $this->userslib->getClientNames();
		$data['user_types']   = $this->userslib->getUserTypes("");

		$user_type = $this->session->userdata('user_type');

		if ($user_type > 2)
		{
			redirect(base_url());
		}

		$this->load->view('project_add', $data);
	}

	public function project_add_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('emailstacklib');
		$this->load->library('session');
		$this->load->library('functions');
		$this->load->library('notificationslib');

		// Get user id
		$user_id = $this->session->userdata('user_id');
		$sender_details = $this->userslib->getUserProfile($user_id);

		// Return array for the ajax request
		$result = array();

		// Array with ids for notification
		$pm_id_array 		= array();
		$client_id_array 	= array();

		// Getting the input values
		$project_name = $this->input->post('pname');
		$project_description = $this->input->post('pdesc');
		$project_due_date = $this->input->post('pddate');

		$project_id = $this->projectslib->addProjects($project_name, $project_description, date("Y-m-d"), date("Y-m-d",strtotime($project_due_date)));

		if ($project_id != 0)
		{
			// Set mail variables
			$sender 	= $this->config->item("sender_email");
			$name 		= $this->config->item("sender_name");
			$subject 	= "New Project";
			$message 	= "";

			$assigned_pm = explode(',', $this->input->post('pms'));
			$i = 0;

			if (is_array($assigned_pm))
			{
				$count_pm = count($assigned_pm);

				for ($i = 0; $i < $count_pm; $i++) 
				{
					array_push($pm_id_array, $assigned_pm[$i]);
					$operation = $this->projectslib->addProjectPM($assigned_pm[$i], $project_id);

					if ($operation == 0)
					{
						$result["success"] = 0;
					}
					else
					{
						$user_info = $this->userslib->getUserNames($assigned_pm[$i]);
						$message   = "Hi ".$user_info->first_name.",<br /><br />
						A new project <b>".$project_name."</b> has been assigned to you by <b>".$sender_details->first_name." ".$sender_details->last_name."</b>!<br /><br />
						Please <a href='".base_url()."projects/view/".$project_id."'>login</a> to your account to view the project.<br /><br />
						Thanks,<br />
						".$name."";

						if (($this->config->item("send_emails") == "yes") && ($user_info->user_id != $user_id))
						{
							$receiver = $user_info->email;
							if ($user_info->receive_email == 'yes')
							{
								$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
							}
						}

						$result["success"] = 1;
					}
				}

				$log_text = "Project ".$project_name." was added by ".$sender_details->first_name." ".$sender_details->last_name;

				$this->functions->writelog($log_text);
			}

			$messsage = "";

			$assigned_user = explode(',', $this->input->post('clients'));
			$i = 0;
			if (is_array($assigned_user) && ($this->input->post('clients') != ""))
			{
				$count_user = count($assigned_user);

				for ($i = 0; $i < $count_user; $i++) 
				{
					array_push($client_id_array, $assigned_user[$i]);
					$operation2 = $this->projectslib->addProjectView($assigned_user[$i], $project_id);

					if($operation2 == 0)
					{
						$result["success"] = 0;
					}
					else
					{
						$client_info = $this->userslib->getUserNames($assigned_user[$i]);
						$message   = "Hi ".$client_info->first_name.",<br /><br />
						A new project <b>".$project_name."</b> has been assigned to you by <b>".$sender_details->first_name." ".$sender_details->last_name."</b>!<br /><br />
						Please <a href='".base_url()."projects/view/".$project_id."'>login</a> to your account to view the project.<br /><br />
						Thanks,<br />
						".$name."";

						if (($this->config->item("send_emails") == "yes") && ($client_info->user_id != $user_id))
						{
							$receiver = $client_info->email;
							if ($client_info->receive_email == 'yes')
							{
								$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
							}
						}
						$result["success"] = 1;
					}
				}
			}

			// Insert necessary notifications
			$noti_ids 	= array_merge($pm_id_array, $client_id_array);
			$noti_ids 	= array_values(array_unique($noti_ids));
			for ($i=0; $i < count($noti_ids); $i++) 
			{ 
				$user_info = $this->userslib->getUserProfile($noti_ids[$i]);
				if ($user_info->receive_notifications == 'yes')
				{
					$type_id 	= $this->notificationslib->getNotificationTypeByName("New Project Added")->id;
					$this->notificationslib->addNotification($noti_ids[$i], $type_id, $project_id, $message);
				}
			}

		}
		else
		{
			$result["success"] = 0;
		}

		echo json_encode($result);
	}

	public function view($slug)
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');

		$user_id 	= $this->session->userdata('user_id');
		$user_type 	= $this->session->userdata('user_type');
		$project_id = $slug;

		// check if the project has any active tasks
		$data['check_task_in_progress'] = $this->projectslib->checkTaskInProgress($project_id);

		if ($user_type == 4)
		{
			$check = $this->projectslib->checkUserProjectExist($user_id, $project_id, 'client');

			if ($check == 0)
			{
				redirect(base_url()."projects");
			}
		}

		if ($user_type == 3)
		{
			$check = $this->projectslib->checkUserProjectExist($user_id, $project_id, 'developer');

			if ($check == 0)
			{
				redirect(base_url()."projects");
			}
		}

		$data["clients"]    	  		= $this->projectslib->getClientAssignedList($project_id);
		$data['username']		  		= $this->session->userdata('username');
		$data['user_type'] 		  		= $this->session->userdata('user_type');
		$data['project_managers_info'] 	= $this->projectslib->getProjectManagersForProjects($project_id);
		$data['project'] 		  		= $this->projectslib->getProjectData($project_id);
		$data['user_types'] 			= $this->userslib->getUserTypes("");
		$data['uncompleted_tasks'] 		= $this->projectslib->getProjectCompletion($project_id);

		$this->load->view('project', $data);
	}

	public function close_project()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('projectslib');

		$project_id = $this->input->post('project_id');

		$result = $this->projectslib->editProjectStatus($project_id);
	
		$operation = array();

		if ($result == 1)
		{
			$operation["success"] = 1;
		}
		else
		{
			$operation["success"] = 0;
		}

		echo json_encode($operation);
	}

	public function project_delete()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('projectslib');
		$project_id = $this->input->post("pro_id");
		
		$operation = array();
		$result = $this->projectslib->deleteProject($project_id);

		if ($result == 1)
		{
			$operation['success'] = 1;
		}
		else
		{
			$operation['success'] = 0;
		}

		echo json_encode($operation);
	}

}