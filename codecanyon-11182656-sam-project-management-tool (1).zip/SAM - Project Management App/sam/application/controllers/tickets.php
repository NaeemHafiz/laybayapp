<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tickets extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');

		$this->load->view('tickets');
	}

	// Tickets functions
	// Get tasks per developer report for pms via ajax for datatable
	public function getTickets()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('ticketslib');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$start_range	= $this->input->get('start_range');
		$end_range 		= $this->input->get('end_range');

		if (strlen($search) > 0)
		{
			$tickets 				= $this->ticketslib->getAllTickets($start_range, $end_range, $start, $offset, $search, $sort_col, $sort_dir);
			$tickets_pagination 	= $this->ticketslib->getAllTickets($start_range, $end_range, "", "", $search);
		}
		else
		{
			$tickets 				= $this->ticketslib->getAllTickets($start_range, $end_range, $start, $offset, "", $sort_col, $sort_dir);
			$tickets_pagination 	= $this->ticketslib->getAllTickets($start_range, $end_range);
		}

		$tickets_data = array();

		if (is_array($tickets))
		{
			for ($j = 0; $j < count($tickets); $j++)
			{ 
				$tickets_data[$j][] = "#".$tickets[$j]['id'];
				$tickets_data[$j][] = $tickets[$j]['subject'];
				$tickets_data[$j][] = $tickets[$j]['added_by'];
				$tickets_data[$j][] = $tickets[$j]['added_on'];

				if ($tickets[$j]['status'] == "Pending")
				{
					$tickets_data[$j][] = "<span class='label label-default'>".lang('status_pending')."</span>";
				}
				elseif ($tickets[$j]['status'] == "Open")
				{
					$tickets_data[$j][] = "<span class='label label-warning'>".lang('status_open')."</span>";
				}
				else
				{
					$tickets_data[$j][] = "<span class='label label-success'>".lang('status_closed')."</span>";
				}

				$tickets_data[$j][] = "<a class=\"btn btn-success\" href=\"".base_url()."tickets/view/".$tickets[$j]['id']."\" title=\"".lang('btn_view')."\"><i class=\"fa fa-eye\"></i></a>&nbsp;<a class=\"btn btn-danger\" href=\"#\" onclick=\"showDialog.call(this, event, 'delete_ticket_dialog', ".$tickets[$j]['id'].", 'ticket_id', '#".$tickets[$j]['id']." - ".$tickets[$j]['subject']."');\" title=\"".lang("btn_delete")."\"><i class=\"fa fa-trash-o\"></i></a>";
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($tickets_pagination),
			"iTotalDisplayRecords" => count($tickets_pagination),
			"aaData" => $tickets_data
		);

		echo json_encode($output);
	}

	public function view($slug)
	{
		$this->load->helper('language');
		$this->load->library('ticketslib');
		$data['tickets'] = $this->ticketslib->getTicketInfo($slug);
		if (strlen($data['tickets']->respondent_id) > 0 && $data['tickets']->respondent_id != 0 && strlen($data['tickets']->answer) > 0) 
		{
			$data['respondent_info'] = $this->userslib->getUserProfile($data['tickets']->respondent_id);
		}
		else
		{
			$data['respondent_info'] = "";
		}
		if (strlen($data['tickets']->closing_id) > 0 && $data['tickets']->closing_id != 0 && strlen($data['tickets']->close_message) > 0)
		{
			$data['closer_info'] = $this->userslib->getUserProfile($data['tickets']->closing_id);
		}
		else
		{
			$data['closer_info'] = "";
		}

		$this->load->view('ticket', $data);
	}

	public function deleteTicket()
	{
		$this->load->library('ticketslib');
		$id = $this->input->post('ticket_id');
		$result = $this->ticketslib->removeTicket($id);
		echo json_encode($result);
	}

	public function closeTicket()
	{
		$this->load->library('ticketslib');
		$this->load->library('session');
		$user_id 	= $this->session->userdata('user_id');
		$id 		= $this->input->post('ticket_id');
		$message 	= $this->input->post('message');
		$result 	= $this->ticketslib->closeTicket($id, $user_id, $message);
		echo json_encode($result);
	}

	public function getFirstTicketDate()
	{
		$this->load->library('ticketslib');
		$result = $this->ticketslib->getFirstTicketDate();
		echo json_encode($result);
	}

	public function answerTicket()
	{
		$this->load->library('ticketslib');
		$this->load->library('emailstacklib');
		$this->load->library('userslib');
		$this->load->library('session');

		$sender 	= $this->session->userdata('user_id');
		$s_email 	= $this->userslib->getUserProfile($sender)->email;
		$s_name 	= $this->userslib->getUserProfile($sender);
		$id 		= $this->input->post('ticket_id');
		$subject 	= $this->input->post('subject');
		$message 	= $this->input->post('message');

		$result = $success = 1;
		$operation 	= array();

		$ticket_info = $this->ticketslib->getTicketInfo($id);

		// Save the answer and answerer to db
		$this->ticketslib->answerTicket($id, $sender, $message);

		if (strlen($ticket_info->email) > 0)
		{
			$result = $this->emailstacklib->addEmailInStack($s_email, $ticket_info->email, $s_name->first_name." ".$s_name->last_name, $subject, $message);
			
			if ($result == 0)
			{
				$success = 0;
			}
		}
		
		$output['success'] = $success;

		echo json_encode($output);
	}

	// Ticket settings functions
	// Function to show settings tables
	public function settings()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');

		$this->load->view('ticket_settings');
	}

	// Function to get settings for datatable
	public function getSettingsTickets()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('ticketslib');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get("iSortCol_0");
		$sort_dir 		= $this->input->get("sSortDir_0");

		if (strlen($search) > 0)
		{
			$settings 				= $this->ticketslib->getAllTicketsSettings($start, $offset, $search, $sort_col, $sort_dir);
			$settings_pagination 	= $this->ticketslib->getAllTicketsSettings("", "", $search);
		}
		else
		{
			$settings 				= $this->ticketslib->getAllTicketsSettings($start, $offset, "", $sort_col, $sort_dir);
			$settings_pagination 	= $this->ticketslib->getAllTicketsSettings();
		}

		$settings_data = array();

		if (is_array($settings))
		{
			for ($j = 0; $j < count($settings); $j++)
			{ 
				$settings_data[$j][] = $settings[$j]['domain'];
				$settings_data[$j][] = $settings[$j]['name'];

				if (ucfirst($settings[$j]['active']) == "Yes")
				{
					$settings_data[$j][] = "<span class='label label-success'>".lang('label_active')."</span>";
				}
				else
				{
					$settings_data[$j][] = "<span class='label label-default'>".lang('label_inactive')."</span>";
				}
				
				$settings_data[$j][] = "<a class=\"btn btn-info\" href=\"".base_url()."tickets/edit/".$settings[$j]['id']."\" title=\"".lang('btn_edit')."\"><i class=\"fa fa-pencil\"></i></a>&nbsp;<a class=\"btn btn-danger\" href=\"#\" title=\"".lang('btn_delete')."\" onclick=\"showDialog.call(this, event, 'delete_setting_dialog', ".$settings[$j]['id'].", 'setting_id', '".$settings[$j]['id']." - ".$settings[$j]['name']."');\"><i class=\"fa fa-trash-o\"></i></a>";
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($settings_pagination),
			"iTotalDisplayRecords" => count($settings_pagination),
			"aaData" => $settings_data
		);

		echo json_encode($output);
	}

	// Add new ticket setting
	public function add()
	{
		$this->load->library('clientslib');

		$data['clients'] = $this->clientslib->getClients("all");

		$this->load->view('ticket_settings_add', $data);
	}

	// Edit ticket setting
	public function edit($slug)
	{
		$this->load->library('ticketslib');
		$this->load->library('clientslib');

		$data['settings_info'] 	= $this->ticketslib->getSettingInfo($slug);
		$data['clients'] 		= $this->clientslib->getClients("all");

		$this->load->view('ticket_settings_edit', $data);
	}

	// Delete ticket setting
	public function deleteTicketSettings()
	{
		$this->load->library('ticketslib');
		$id = $this->input->post('setting_id');
		$result = $this->ticketslib->removeTicketSetting($id);
		echo json_encode($result);
	}

	// Save edited settings
	public function saveSettings()
	{
		$this->load->library('ticketslib');

		$operation 	= array();

		$id 		= $this->input->post('settings_id');
		$client 	= $this->input->post('client');
		$client_key = $this->input->post('client_key');
		$app_url 	= $this->input->post('app_url');
		$noti_email = $this->input->post('notified_emails');
		$text_col	= $this->input->post('text_col');
		$btn_col 	= $this->input->post('btn_col');
		$btn_text 	= $this->input->post('btn_text');
		$script 	= $this->input->post('script');
		$active 	= $this->input->post('active');

		if (strlen($id) > 0 && $id != 0)
		{
			$result 	= $this->ticketslib->saveSettingsEdit($id, $client, $client_key, $app_url, $noti_email, $text_col, $btn_col, $btn_text, $script, $active);
		}
		else
		{
			$result 	= $this->ticketslib->saveSettingsAdd($client, $client_key, $app_url, $noti_email, $text_col, $btn_col, $btn_text, $script, $active);
		}

		if ($result != 0)
		{
			$operation['success'] = 1;
		}
		else
		{
			$operation['success'] = 0;
		}

		echo json_encode($operation);
	}

	public function getFirstRegistrationDate()
	{
		$this->load->library('userslib');
		$result = $this->userslib->getFirstRegistration();
		echo json_encode($result);
	}
}