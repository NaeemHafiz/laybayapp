<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notifications extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		redirect(base_url()."notifications/all");
	}

	public function all()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('notificationslib');

		$id 				= $this->session->userdata('user_id');
		$data['noti_info'] 	= $this->notificationslib->getUserNotifications($id);

		$this->load->view('online_notifications', $data);
	}

	public function readNotification()
	{
		$this->load->library('notificationslib');

		$user_id 	= $this->input->post('user_id');
		$noti_id 	= $this->input->post('notification_id');

		$this->notificationslib->readNotification($user_id, $noti_id);
	}
}