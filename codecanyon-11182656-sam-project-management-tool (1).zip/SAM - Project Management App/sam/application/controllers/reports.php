<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reports extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');

		// $array = array();

		// $developers = $this->userslib->getAllDevelopers();

		// if (is_array($developers))
		// {
		// 	for ($i = 0; $i < count($developers); $i++)
		// 	{
		// 		$array[$i]->developer 	= $developers[$i]->first_name." ".$developers[$i]->last_name;
		// 		$array[$i]->balance   	= $developers[$i]->balance;

		// 		$comp = $this->taskslib->getUserTaskCountByStatus($developers[$i]->id, 'Completed');
		// 		$in_p = $this->taskslib->getUserTaskCountByStatus($developers[$i]->id, 'In Progress');
		// 		$asgn = $this->taskslib->getUserTaskCountByStatus($developers[$i]->id, 'Assigned');

		// 		$array[$i]->completed 	= $comp;
		// 		$array[$i]->in_progress	= $in_p;
		// 		$array[$i]->assigned 	= $asgn;
		// 	}
		// }

		// $data['tasks_per_developer'] = $array;

		$this->load->view('reports');
	}

	// Get # of tasks per developer
	public function getTasksPerDeveloper()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');

		$start 		= $this->input->get('iDisplayStart');
		$offset		= $this->input->get('iDisplayLength');
		$search		= $this->input->get('sSearch');

		$sort_col 	= $this->input->get('iSortCol_0');
		$sort_dir 	= $this->input->get('sSortDir_0');

		$start_range	= $this->input->get('start_range');
		$end_range 		= $this->input->get('end_range');

		if (strlen($search) > 0)
		{
			$developers 			= $this->userslib->getAllDevelopers($start, $offset, $search, $start_range, $end_range, $sort_col, $sort_dir);
			$developers_pagination 	= $this->userslib->getAllDevelopers("", "", $search, $start_range, $end_range);
		}
		else
		{
			$developers 			= $this->userslib->getAllDevelopers($start, $offset, "", $start_range, $end_range, $sort_col, $sort_dir);
			$developers_pagination 	= $this->userslib->getAllDevelopers("", "", "", $start_range, $end_range);
		}

		$dev_data = array();

		if (is_array($developers))
		{
			for ($j = 0; $j < count($developers); $j++)
			{ 
				// Check if hours is null, replace it with 0
				if ($developers[$j]['hours'] == null)
				{
					$developers[$j]['hours'] = 0;
				}

				$dev_data[$j][] = $developers[$j]["first_name"]." ".$developers[$j]["last_name"];
				$dev_data[$j][] = $developers[$j]['assigned'];
				$dev_data[$j][] = $developers[$j]['in_progress'];
				$dev_data[$j][] = $developers[$j]['completed'];
				$dev_data[$j][] = number_format($developers[$j]['hours'], 2);
				$dev_data[$j][] = number_format($developers[$j]["balance"], 2);
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($developers_pagination),
			"iTotalDisplayRecords" => count($developers_pagination),
			"aaData" => $dev_data
		);

		echo json_encode($output);
	}

	// Get all assigned or in progress tasks per developer
	function getTasksForDrevelopers()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$developer_id 	= $this->input->get('id');

		if (strlen($search) > 0)
		{
			$tasks 				= $this->taskslib->getDeveloperTasks($developer_id, $start, $offset, $search, $sort_col, $sort_dir);
			$tasks_pagination 	= $this->taskslib->getDeveloperTasks($developer_id, "", "", $search);
		}
		else
		{
			$tasks 				= $this->taskslib->getDeveloperTasks($developer_id, $start, $offset, "", $sort_col, $sort_dir);
			$tasks_pagination 	= $this->taskslib->getDeveloperTasks($developer_id, "", "", "");
		}

		$tasks_data = array();

		if (is_array($tasks))
		{
			for ($j = 0; $j < count($tasks); $j++) 
			{ 
				// Englobe status message in colored container
				$status = "";
				
				if ($tasks[$j]['status'] == "Assigned") 
				{
					$status = '<span class="label label-warning">'.lang("status_assigned").'</span>';
				}
				else 
				{
					$status = '<span class="label label-info">'.lang("status_in_progress").'</span>';
				}

				// Check if due date is set
				if ($tasks[$j]['due_date'] == '0000-00-00')
				{
					$ddate 	= lang('status_not_set');
				}
				else
				{
					$ddate 	= $tasks[$j]['due_date'];
				}

				$action = "<a class='btn btn-success' href=".base_url()."tasks/view/".$tasks[$j]["id"]." title=".lang("btn_view")."><i class='fa fa-eye'></i></a>&nbsp;";

				$tasks_data[$j][] = $tasks[$j]["name"];
				$tasks_data[$j][] = $tasks[$j]['project'];
				$tasks_data[$j][] = $this->functions->dateFormat($tasks[$j]['create_date']);
				$tasks_data[$j][] = $ddate;
				$tasks_data[$j][] = $status;
				$tasks_data[$j][] = $action;
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($tasks_pagination),
			"iTotalDisplayRecords" => count($tasks_pagination),
			"aaData" => $tasks_data
		);

		echo json_encode($output);
	}

	public function getAllDevelopers()
	{
		$this->load->library('userslib');
		$developers = $this->userslib->getAllDevelopers();
		echo json_encode($developers);
	}

	public function getFirstRegistrationDate()
	{
		$this->load->library('userslib');
		$result = $this->userslib->getFirstRegistration();
		echo json_encode($result);
	}
}