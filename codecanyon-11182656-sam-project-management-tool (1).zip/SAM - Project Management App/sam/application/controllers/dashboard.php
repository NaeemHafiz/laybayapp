<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('projectslib');

		$user_type 	= $this->session->userdata('user_type');
		$user_id 	= $this->session->userdata('user_id');

		if ($user_id == "" || $user_id == 0 || $user_id == NULL)
		{
			redirect(base_url().'login');
		}

		$completed_tasks = array();
		$max = 0;

		for ($i = 1; $i < 13; $i++)
		{
			$completed_tasks[$i] = $this->projectslib->getCompletedTasksForClientByMonth($i, $user_id);

			if (count($completed_tasks[$i]) > $max)
				$max = count($completed_tasks[$i]);
		}

		$data['task_info'] 		= $completed_tasks;
		$data['max'] 			= $max;
		$data['clients_no'] 	= count($this->userslib->getAllClients());
		$data['projects_no'] 	= count($this->projectslib->getAllProjects());
		$data['tasks_no'] 		= count($this->projectslib->getAllTasks());
		$data['username'] 		= $this->session->userdata('username');
		$data['todo_list'] 		= $this->userslib->getUserTodoList($user_id);

		if ($user_type == 4)
		{
			// Calculate Client Projects nr, in progress tasks nr, completed tasks nr
			$data['client_projects_no'] 	= $this->projectslib->getClientProjects($user_id);
			$client_in_progress_tasks_no 	= $this->projectslib->getUserTasks("", $user_type, $user_id, "In Progress", "no");

			if ($client_in_progress_tasks_no == 0)
			{
				$data["client_in_progress_tasks_no"] = 0;
			}
			else
			{
				$data["client_in_progress_tasks_no"] = count($client_in_progress_tasks_no);
			}

			$client_completed_tasks_no = $this->projectslib->getUserTasks("", $user_type, $user_id, "Completed", "no");

			if ($client_completed_tasks_no == 0)
			{
				$data["client_completed_tasks_no"] = 0;
			}
			else
			{
				$data["client_completed_tasks_no"] = count($client_completed_tasks_no);
			}
		}

		if ($user_type == 3)
		{
			// Calculate Developer Projects nr, in progress tasks nr, completed tasks nr
			$developer_projects_no = $this->projectslib->getUserProjects($user_type, $user_id, "");

			if ($developer_projects_no == 0)
			{
				$data["developer_projects_no"] = 0;
			}
			else
			{
				$data["developer_projects_no"] = count($developer_projects_no);
			}

			$developer_assigned_tasks_no 	= $this->projectslib->getUserTasks("", $user_type, $user_id, "Assigned", "no");

			if ($developer_assigned_tasks_no == 0)
			{
				$data["developer_assigned_tasks_no"] = 0;
			}
			else
			{
				$data["developer_assigned_tasks_no"] = count($developer_assigned_tasks_no);
			}

			$developer_progress_tasks_no = $this->projectslib->getUserTasks("", $user_type, $user_id, "In Progress", "no");

			if ($developer_progress_tasks_no == 0)
			{
				$data["developer_progress_tasks_no"] = 0;
			}
			else
			{
				$data["developer_progress_tasks_no"] = count($developer_progress_tasks_no);
			}

			$data["profile_info"] = $this->userslib->getUserProfile($user_id);

			// Calculate Developer Tasks by project and status
			$developer_tasks_by_project = array();
			$i = 0;

			if (is_array($developer_projects_no))
			{
				foreach ($developer_projects_no as $elem) 
				{
					$developer_tasks_by_project[$i] = new stdClass();
					
					$developer_tasks_by_project[$i]->project_name 	= $elem->name;
					$developer_tasks_by_project[$i]->project_id 	= $elem->projectid;

					$assigned_tasks = $this->projectslib->getUserTasks($elem->projectid, $user_type, $user_id, "Assigned", "no");

					if ($assigned_tasks == 0)
					{
						$assigned_tasks_number = 0;
					}
					else
					{
						$assigned_tasks_number = count($assigned_tasks);
					}

					$developer_tasks_by_project[$i]->assigned = $assigned_tasks_number;
					$in_progress_tasks = $this->projectslib->getUserTasks($elem->projectid, $user_type, $user_id, "In Progress", "no");

					if ($in_progress_tasks == 0)
					{
						$in_progress_tasks_number = 0;
					}
					else
					{
						$in_progress_tasks_number = count($in_progress_tasks);
					}

					$developer_tasks_by_project[$i]->in_progress = $in_progress_tasks_number;
					$completed_tasks = $this->projectslib->getUserTasks($elem->projectid, $user_type, $user_id, "Completed", "no");

					if ($completed_tasks == 0)
					{
						$completed_tasks_number = 0;
					}
					else
					{
						$completed_tasks_number = count($completed_tasks);
					}

					$developer_tasks_by_project[$i]->completed = $completed_tasks_number;

					$i++;
				}
			}

			$data["developer_tasks_by_project"] = $developer_tasks_by_project;
		}

		if ($user_type == 2)
		{
			// Get all developers

			$data['developers'] = $this->userslib->getDeveloperNames("yes");

			// Calculate Project Manager Projects nr, in progress tasks nr, clients nr
			$project_manager_projects_no = $this->projectslib->getUserProjects($user_type, $user_id, "");

			if ($project_manager_projects_no == 0)
			{
				$data["project_manager_projects_no"] = 0;
			}
			else
			{
				$data["project_manager_projects_no"] = count($project_manager_projects_no);
			}

			$data["project_manager_tasks_no"] = $this->projectslib->getProjectTasks($user_id,'');
			$data["project_manager_clients"] = $this->projectslib->getProjectClients($user_id);
			
			// Calculate Project Manager Tasks by project and status
			$project_manager_tasks_by_project = array();
			$i = 0;

			if (is_array($project_manager_projects_no))
			{
				foreach($project_manager_projects_no as $elem)
				{
					$project_manager_tasks_by_project[$i]['project_name'] 	= $elem->name;

					$not_assigned_number = $this->projectslib->getTasksByProject($elem->projectid, 'Not Assigned');

					if ($not_assigned_number == 0)
					{
						$not_assigned_final_number = 0;
					}
					else
					{
						$not_assigned_final_number = count($not_assigned_number);
					}

					$project_manager_tasks_by_project[$i]['not_assigned'] = $not_assigned_final_number;

					$assigned_number = $this->projectslib->getTasksByProject($elem->projectid, 'Assigned');

					if ($assigned_number == 0)
					{
						$assigned_final_number = 0;
					}
					else
					{
						$assigned_final_number = count($assigned_number);
					}

					$project_manager_tasks_by_project[$i]['assigned'] = $assigned_final_number;

					$in_progress_number = $this->projectslib->getTasksByProject($elem->projectid, 'In Progress');

					if ($in_progress_number == 0)
					{
						$in_progress_final_number = 0;
					}
					else
					{
						$in_progress_final_number = count($in_progress_number);
					}

					$project_manager_tasks_by_project[$i]['in_progress'] = $in_progress_final_number;

					$completed_number = $this->projectslib->getTasksByProject($elem->projectid, 'Completed');

					if ($completed_number == 0)
					{
						$completed_final_number = 0;
					}
					else
					{
						$completed_final_number = count($completed_number);
					}

					$project_manager_tasks_by_project[$i]['completed'] = $completed_final_number;
					$i++;
				}
			}

			$data['pm_tasks_by_project'] = $project_manager_tasks_by_project;
		}

		if ($user_type == 1)
		{
			// Get all developers

			$data['developers'] = $this->userslib->getDeveloperNames("yes");
			
			// Calculate Admin Projects nr, tasks nr, clients nr
			$admin_projects_no 	= $this->projectslib->getAllProjects();

			if ($admin_projects_no == 0)
			{
				$data["admin_projects_no"] = 0;
			}
			else
			{
				$data["admin_projects_no"] = count($admin_projects_no);
			}

			$admin_tasks_no = $this->projectslib->getAllTasks();

			if ($admin_tasks_no == 0)
			{
				$data["admin_tasks_no"] = 0;
			}
			else
			{
				$data["admin_tasks_no"] = count($admin_tasks_no);
			}

			$admin_clients_no = $this->userslib->getAllClients();
			if ($admin_clients_no == 0)
			{
				$data["admin_clients_no"] = 0;
			}
			else
			{
				$data["admin_clients_no"] = count($admin_clients_no);
			}

			// Admin dashboard table
			$i = 0;
			$admin_tasks_by_project = array();
			$admin_projects = $this->projectslib->getUserProjects($user_type, $user_id, "");

			if (is_array($admin_projects))
			{
				foreach ($admin_projects as $elem) 
				{
					$admin_tasks_by_project[$i]['project_name'] = $elem->name;

					$not_assigned_number = $this->projectslib->getTasksByProject($elem->projectid, 'Not Assigned');

					if ($not_assigned_number == 0)
					{
						$not_assigned_final_number = 0;
					}
					else
					{
						$not_assigned_final_number = count($not_assigned_number);
					}

					$admin_tasks_by_project[$i]['not_assigned'] = $not_assigned_final_number;
					$assigned_number = $this->projectslib->getTasksByProject($elem->projectid, 'Assigned');

					if ($assigned_number == 0)
					{
						$assigned_final_number = 0;
					}
					else
					{
						$assigned_final_number = count($assigned_number);
					}

					$admin_tasks_by_project[$i]['assigned'] = $assigned_final_number;

					$in_progress_number = $this->projectslib->getTasksByProject($elem->projectid, 'In Progress');

					if ($in_progress_number == 0)
					{
						$in_progress_final_number = 0;
					}
					else
					{
						$in_progress_final_number = count($in_progress_number);
					}

					$admin_tasks_by_project[$i]['in_progress'] = $in_progress_final_number;

					$completed_number = $this->projectslib->getTasksByProject($elem->projectid, 'Completed');

					if ($completed_number == 0)
					{
						$completed_final_number = 0;
					}
					else
					{
						$completed_final_number = count($completed_number);
					}

					$admin_tasks_by_project[$i]['completed'] = $completed_final_number;

					$i++;
				}
			}

			$data['admin_tasks_by_project'] = $admin_tasks_by_project;
		}

		$this->load->view('index', $data);
	}

}