<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tasks extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('taskslib');

		$user_id 		= $this->session->userdata('user_id');
		$user_type 		= $this->session->userdata('user_type');
		$status_in_p 	= 'latest';
		$status_comp 	= 'Completed';

		$data['username']		= $this->session->userdata('username');
		$data['user_type']  	= $this->session->userdata('user_type');
		$data['tasks_latest']	= $this->projectslib->getUserTasks("", $user_type, $user_id, $status_in_p, "no");
		$data['tasks_all']		= $this->projectslib->getUserTasks("", $user_type, $user_id, $status_comp, "no");
		$data['managed_tasks']  = $this->taskslib->getManagedTasks($user_id);
		$data['user_types']     = $this->userslib->getUserTypes("");

		$this->load->view('tasks_my', $data);
	}

	public function edit($slug)
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$user_id 					= $this->session->userdata('user_id');
		$data['hourly_rate'] 		= $this->userslib->getUserProfile($user_id)->hourly_rate;

		$task_id 					= $slug;

		$data['task_info'] 			= $this->taskslib->getTaskInfo($task_id);
		$project_id 				= $data['task_info']->project_id;
	 	$data['username'] 			= $this->session->userdata('username');
		$data['projects'] 			= $this->projectslib->browseProjects();
		$data['user_types']     	= $this->userslib->getUserTypes("");

		$task_assigned 				= $this->taskslib->getAssignedTask($data['task_info']->id);

		$i = 0;
		$assigned_array = array();

		if (is_array($task_assigned))
		{
			foreach ($task_assigned as $elem) 
			{
				$assigned_array[$i] = $elem->user_id;
				$i++;
			}
		}

		$data['task_assigned']		= $assigned_array;
		$data['workers'] 			= $this->userslib->getDevelopersPMs();
		
		// Get all task priority types
		$data['task_priority']  = $this->functions->getAllTaskPriorities();

		$this->load->view('task_edit', $data);
	}

	public function task_edit_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('functions');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('taskslib');
		$this->load->library('emailstacklib');

		$task_id 				= $this->input->post('task_id');
		$task_project_id 		= $this->input->post('tedit_projid');
		$task_name 				= $this->input->post('tedit_name');
		$task_description 		= $this->input->post('tedit_desc');
		$task_estimated_cost 	= $this->input->post('tedit_estimated_cost');
		$task_due_date 			= $this->input->post('tedit_due_date');
		$assigned_devs 			= $this->input->post('tedit_asgnto');
		$task_priority			= $this->input->post('tedit_priority');

		if (strlen($assigned_devs) > 0)
			$task_assign_to = explode(',', $assigned_devs);
		else
			$task_assign_to = 0;

		$user_id = $this->session->userdata('user_id');
		$task_info = $this->taskslib->getTaskInfo($task_id);

		if ($task_info->status == "Not Assigned")
		{
			$status = "Assigned";
		}
		else
		{
			$status = $task_info->status;
		}

		if ($task_assign_to == 0)
		{
			$status = "Not Assigned";
		}

		// Modify task details
		$status1 = $this->taskslib->modifyTasks($task_id, $task_project_id, $task_priority, $task_name, $task_description, $task_estimated_cost, $task_due_date, $status);
		
		// Get old developers per task
		$assigned_devs = $this->taskslib->getAssignedTask($task_id);
		$old_developers = array();

		$i = 0;

		if (is_array($assigned_devs))
		{
			foreach ($assigned_devs as $elem) 
			{
				$old_developers[$i] = $elem->user_id;
				$i++;
			}
		}

		// Delete all assigned person to task
		$this->taskslib->deleteTaskAssignedWorkers($task_id);

		if (is_array($task_assign_to))
		{
			$count_tasgnto = count($task_assign_to);

			for ($i = 0; $i < $count_tasgnto; $i++)
			{
				// Add new person to task
				$status2 = $this->projectslib->assignTask($task_assign_to[$i], $task_id);
				
				// Send email to developer when task is assigned by PM.
				// Send email only to new developers.
				if ((!in_array($task_assign_to[$i], $old_developers))  && ($status == "Assigned") && ($this->config->item("send_emails") == "yes"))
				{
					$sender_info	= $this->userslib->getMemberInfo($user_id);
					$receiver_info 	= $this->userslib->getMemberInfo($task_assign_to[$i]); 

					$sender  	= $this->config->item("sender_email");
					$receiver 	= $receiver_info->email;
					$name 		= $this->config->item("sender_name");
					$subject 	= "New Task Assigned";
					$message 	= "Hi ".$receiver_info->first_name.",<br /><br />
								A new task <b>".$task_name."</b> has been assigned to you!<br />
								Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
			
								Thanks,<br />
								".$name."";
					if ($receiver_info->receive_email == 'yes')
					{
						$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
					}
				}
			}
		}
		else
		{
			$this->projectslib->assignTask(0, $task_id);

			$result['success'] = 1;
			echo json_encode($result);
			return;
		}

		if (($status1 == 1) && ($status2 == 1))
		{
			$result['success'] = 1;
		}
		else
		{
			$result['success'] = 0;
		}

		echo json_encode($result);
	}

	public function add()
	{
		$this->load->helper('url');
		$this->load->helper('language'); 
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$user_id 				= $this->session->userdata('user_id');
		$user_type				= $this->session->userdata('user_type');
		$data['hourly_rate']	= $this->userslib->getUserProfile($user_id)->hourly_rate;
		$data['client_project'] = $this->projectslib->getUserProjects($user_type, $user_id, "completed_no");
		$data['projects'] 		= $this->projectslib->getUserProjects($user_type, $user_id, "completed_no");
		$data['user_types']   	= $this->userslib->getUserTypes("");

		$data['workers'] 		= $this->userslib->getDevelopersPMs();
		$data['username'] 		= $this->session->userdata('username');
		// Get all task priority types
		$data['task_priority']  = $this->functions->getAllTaskPriorities();

		$this->load->view('task_add', $data);
	}

	public function task_add_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('session');
		$this->load->library('functions');
		$this->load->library('emailstacklib');
		$this->load->library('notificationslib');

		// Return array for the ajax request
		$result = array();

		// Getting the input values
		$tname 			= $this->input->post('tname');
		$tdesc 			= $this->input->post('tdesc');
		$tprojid 		= $this->input->post('tprojid');
		$assigned_devs 	= $this->input->post('tasgnto');
		$tpriority 		= $this->input->post('tpriority');

		// Check if we have assigned developers
		if (strlen($assigned_devs) > 0)
			$tasgnto 	= explode(',', $assigned_devs);
		else
			$tasgnto 	= 0;

		$user_id 		= $this->session->userdata('user_id');
		$user_type 		= $this->session->userdata('user_type');
		$user_name 		= $this->userslib->getUserNames($user_id);
		$author  		= $user_name->first_name." ".$user_name->last_name;
		$status  		= "Assigned";

		if ($tasgnto == 0)
		{
			$status = "Not Assigned";
		}

		if ($user_type == 4)
		{
			$status = "Not Assigned";
		}

		$task_id = $this->projectslib->addTask($user_id, $tprojid, $tpriority, $tname, $tdesc, $status);

		// Get project managers
		$project_managers = $this->projectslib->getProjectManagersForProjects($tprojid);
		$pmanagerids = array();

		// Set the message variable for multiple use
		$message = "";

		// Get project info
		$project_info 	  = $this->projectslib->getProjectData($tprojid);

		if (($task_id != 0) && ($user_type == 4) && ($this->config->item("send_emails") == "yes"))
		{
			$status = "Not Assigned";
			
			// Send email to PM

			foreach ($project_managers as $elem) 
			{
				$sender  	= $this->config->item("sender_email");
				$receiver 	= $elem->email;
				$name 		= $this->config->item("sender_name");
				$subject 	= "New Task for ".$project_info->name."";
				$message 	= "Hi ".$elem->first_name.",<br /><br />
							A new task has been added to <b>".$project_info->name."</b> project by <b>".$author."</b>!<br /><br />
							Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review and assign the task.<br /><br />
							Thanks,<br />
							".$name."";

				if ($elem->receive_email == 'yes')
				{
					$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
				}
			}
		}

		// Notifications are always sent
		if (is_array($project_managers) && count($project_managers) > 0)
		{
			foreach ($project_managers as $elem) 
			{
				$sender  	= $this->config->item("sender_email");
				$receiver 	= $elem->email;
				$name 		= $this->config->item("sender_name");
				$subject 	= "New Task for ".$project_info->name."";
				$message 	= "Hi ".$elem->first_name.",<br /><br />
							A new task has been added to <b>".$project_info->name."</b> project by <b>".$author."</b>!<br /><br />
							Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review and assign the task.<br /><br />
							Thanks,<br />
							".$name."";

				// Add a notification to project manager
				$user_info = $this->userslib->getUserProfile($elem->id);

				if ($user_info->receive_notifications == 'yes')
				{
					$type_id = $this->notificationslib->getNotificationTypeByName("New Task Added")->id;
					$this->notificationslib->addNotification($elem->id, $type_id, $task_id, $message);
				}

				array_push($pmanagerids, $elem->id);
			}
		}

		if ($task_id != 0)
		{
			$clients 		= $this->projectslib->getClientsForProjects($tprojid);

			// Init message again
			$message = "";

			$project_info 	= $this->projectslib->getProjectData($tprojid);

			if ($this->config->item("send_emails") == "yes")
			{
				// Send email to clients if emails are enabled

				if (is_array($clients) && count($clients) > 0)
				{
					foreach ($clients as $elem) 
					{
						$sender  	= $this->config->item("sender_email");
						$receiver 	= $elem->email;
						$name 		= $this->config->item("sender_name");
						$subject 	= "New Task for ".$project_info->name."";
						$message 	= "Hi ".$elem->first_name.",<br /><br />
									A new task has been added to <b>".$project_info->name."</b> project by <b>".$author."</b>!<br /><br />
									Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review and assign the task.<br /><br />
									Thanks,<br />
									".$name."";
						if ($elem->receive_email == 'yes')
						{
							$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
						}
					}
				}
			}

			// Notifications are always sent
			if (is_array($clients) && count($clients) > 0)
			{
				foreach ($clients as $elem) 
				{
					$sender  	= $this->config->item("sender_email");
					$receiver 	= $elem->email;
					$name 		= $this->config->item("sender_name");
					$subject 	= "New Task for ".$project_info->name."";
					$message 	= "Hi ".$elem->first_name.",<br /><br />
								A new task has been added to <b>".$project_info->name."</b> project by <b>".$author."</b>!<br /><br />
								Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review and assign the task.<br /><br />
								Thanks,<br />
								".$name."";
								
					// Add a notification to clients
					$user_info = $this->userslib->getUserProfile($elem->id);
					if ($user_info->receive_notifications == 'yes')
					{
						$type_id = $this->notificationslib->getNotificationTypeByName("New Task Added")->id;
						$this->notificationslib->addNotification($elem->id, $type_id, $task_id, $message);
					}
				}
			}

			if (is_array($tasgnto))
			{
				$count_tasgnto = count($tasgnto);

				$unique_developers 	= array_diff($tasgnto, $pmanagerids);
				$unique_developers 	= array_values($unique_developers);
				$project_info 		= $this->projectslib->getProjectData($tprojid);
				
				// And again...
				$message = "";

				for ($i = 0; $i < $count_tasgnto; $i++) 
				{
					$sender_info	= $this->userslib->getMemberInfo($user_id);
					$receiver_info 	= $this->userslib->getMemberInfo($tasgnto[$i]); 
					$project_info 	= $this->projectslib->getProjectData($tprojid);

					$sender  	= $sender_info->email;
					$receiver 	= $receiver_info->email;
					$name 		= $sender_info->first_name." ".$sender_info->last_name;
					$subject 	= "New Task Assigned";
					$message 	= "Hi ".$receiver_info->first_name.",<br /><br />
								A new task <b>".$tname."</b> has been assigned to you on <b>".$project_info->name."</b> project!<br />
								Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
								Thanks,<br />
								".$name."";

					// Send email to developer when task is added by PM
					if (($user_type <= 2) && ($tasgnto[$i] != "None") && ($this->config->item("send_emails") == "yes"))
					{
						if ($receiver_info->receive_email)
						{
							$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
						}
					}

					// Add notifications to devs/pms assigned to task
					$user_info = $this->userslib->getUserProfile($tasgnto[$i]);
					if ($user_info->receive_notifications == 'yes')
					{
						$type_id = $this->notificationslib->getNotificationTypeByName("Task Assigned")->id;
						$this->notificationslib->addNotification($tasgnto[$i], $type_id, $task_id, $message);
					}

					$check = $this->projectslib->assignTask($tasgnto[$i], $task_id);

					if ($check == 1)
					{
						$result["success"] = 1;
						$result["task_id"] = $task_id;
					}
					else
					{
						$result["success"] = 0;
					}
				}
			}
			else
			{
				// parameter is 0, because developer is not selected
				$this->projectslib->assignTask(0, $task_id);

				$result["success"] = 1;
				$result["task_id"] = $task_id;
			}
		}
		else
		{
			$result["success"] = 0;
		}

		echo json_encode($result);
	}

	public function deleteTask()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('taskslib');

		$task_id = $this->input->post('task_id');
		$result = $this->taskslib->deleteTask($task_id);
		$operation = array();
		
		if ($result == 1)
		{
			$operation['success'] = 1;
		}
		else
		{
			$operation['success'] = 0;
		}

		echo json_encode($operation);
	}

	public function task_actions()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('projectslib');
		$this->load->library('functions');
		$this->load->library('transactionlib');
		$this->load->library('emailstacklib');
		$this->load->library('notificationslib');

		$task_id 	= $this->input->post('task_id');
		$client_id  = $this->input->post('client_id');
		$comment 	= $this->input->post('comment');
		$hours 		= $this->input->post('hours');
		$due_date 	= $this->input->post('due_date');
		$action 	= $this->input->post('action');

		$user_id 	= $this->session->userdata('user_id');
		$user_type  = $this->session->userdata('user_type');
		$return = array();
		
		// Check which action is it
		switch ($action)
		{
			// If the task had been started
			case 'start':
				// Update database and set the operation type int a variable
				$check = $this->taskslib->updateTaskStatus($task_id, 'In Progress');
				$operation = "start";

				break;
				
			// If the task had been completed
			case 'complete':
				// Set the same variables as above
				$operation = "complete";
				$check = $this->taskslib->updateTaskStatus($task_id, 'Completed');
				$this->taskslib->updateTaskCompleteDate($task_id, date('Y-m-d H-i-s'));

				// Get estimated hours for task
				$task_info = $this->taskslib->getTaskInfo($task_id);
				$estimated_hours = $task_info->estimated_time;

				// Update balance when task is completed
				$this->userslib->modifyUserProfileBalance($user_id, 'add', $estimated_hours);
				$user_profile = $this->userslib->getUserProfile($user_id);

				// Add new transaction
				$this->transactionlib->addTransaction($user_id, $task_info->name, $task_info->estimated_time, $user_profile->balance);
				
				$task_info 	 	= $this->taskslib->getTaskInfo($task_id);
				$project_info	= $this->projectslib->getProjectData($task_info->project_id);
				$pms_info 		= $this->projectslib->getPMAssignedList($task_info->project_id);

				// Send email to assigned PM when task is completed
				if ($this->config->item("send_emails") == "yes")
				{
					foreach ($pms_info as $elem) 
					{
						$sender  	= $this->config->item("sender_email");
						$receiver 	= $elem->email;
						$name 		= $this->config->item("sender_name");
						$subject 	= "Task Completed";
						$message 	= "Hi ".$elem->first_name.",<br /><br />
							Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been completed!<br /><br />
							Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
							Thanks,<br />
							".$name."";
						if ($elem->receive_email == 'yes')
						{
							$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
						}
					}

					// If client is assigned to task, send email to client
					$client_info = $this->projectslib->getClientsForProjects($task_info->project_id);

					if (is_array($client_info))
					{	
						foreach ($client_info as $elem) 
						{

							$receiver  = $elem->email;
							$message   = "Hi ".$elem->first_name.",<br /><br />
							Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been completed!<br /><br />
							Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
							Thanks,<br />
							".$name."";

							if ($elem->receive_email == 'yes')
							{
								$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
							}
						}
					}
				}

				// Notifications are always sent
				foreach ($pms_info as $elem) 
				{
					$sender  	= $this->config->item("sender_email");
					$receiver 	= $elem->email;
					$name 		= $this->config->item("sender_name");
					$subject 	= "Task Completed";
					$message 	= "Hi ".$elem->first_name.",<br /><br />
						Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been completed!<br /><br />
						Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
						Thanks,<br />
						".$name."";

					// If user has notifications enabled, add a notification to him
					if ($elem->receive_notifications == 'yes')
					{
						$type_id = $this->notificationslib->getNotificationTypeByName("Task Completed")->id;
						$this->notificationslib->addNotification($elem->id, $type_id, $task_id, $message);
					}
				}

				// If client is assigned to task, send email to client
				$client_info = $this->projectslib->getClientsForProjects($task_info->project_id);

				if (is_array($client_info))
				{
					foreach ($client_info as $elem)
					{
						$receiver  = $elem->email;
						$message   = "Hi ".$elem->first_name.",<br /><br />
						Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been completed!<br /><br />
						Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
						Thanks,<br />
						".$name."";

						// If user has notifications enabled, add a notification to him
						if ($elem->receive_notifications == 'yes')
						{
							$type_id = $this->notificationslib->getNotificationTypeByName("Task Completed")->id;
							$this->notificationslib->addNotification($elem->id, $type_id, $task_id, $message);
						}
					}
				}

				break;

			default:
				break;
		}

		if ($check == 1)
		{
			if (strlen($comment) > 0)
			{
				$this->taskslib->addTaskComments($task_id, $user_id, $comment);
			} 
			
			if (is_numeric($hours))
			{
				if ($operation == "start")
				{
					$check_hour = $this->taskslib->updateEstimatedTime($task_id, $hours, $due_date);

					$task_info 	 	= $this->taskslib->getTaskInfo($task_id);
					$project_info	= $this->projectslib->getProjectData($task_info->project_id);
					$pms_info 		= $this->projectslib->getPMAssignedList($task_info->project_id);

					// Send email to pms when task has been quoted
					if ($this->config->item("send_emails") == "yes")
					{
						foreach ($pms_info as $elem) 
						{
							$sender  	= $this->config->item("sender_email");
							$receiver 	= $elem->email;
							$name 		= $this->config->item("sender_name");
							$subject 	= "Task Quoted";
							$message 	= "Hi ".$elem->first_name.",<br /><br />
								Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been quoted with ".$hours." hour(s)!<br /><br />
								Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
								Thanks,<br />
								".$name."";

							if ($elem->receive_email == 'yes')
							{
								$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
							}
						}
					}

					// Notifications are always sent
					foreach ($pms_info as $elem) 
					{
						$sender  	= $this->config->item("sender_email");
						$receiver 	= $elem->email;
						$name 		= $this->config->item("sender_name");
						$subject 	= "Task Quoted";
						$message 	= "Hi ".$elem->first_name.",<br /><br />
							Task <b>".$task_info->name."</b> for project <b>".$project_info->name."</b> has been quoted with ".$hours." hour(s)!<br /><br />
							Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to review the task.<br /><br />
							Thanks,<br />
							".$name."";

						// If user has notifications enabled, add a notification to him/her
						if ($elem->receive_notifications == 'yes')
						{
							$type_id 	= $this->notificationslib->getNotificationTypeByName("Task Quoted")->id;
							$this->notificationslib->addNotification($elem->id, $type_id, $task_id, $message);
						}
					}
				}

				if ($check_hour == 1)
				{
					$return['success'] = 1;
				}
				else
				{
					$return['success'] = 0;
				}
			}
			else
			{
				$return['success'] = 1;
			}
		}
		else
		{
			$return['success'] = 0;
		}

		echo json_encode($return);
	}

	public function project_tasks($slug)
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('userslib');
		$this->load->library('taskslib');

		$project_id = $slug;

		$user_id 	= $this->session->userdata('user_id');
		$user_type 	= $this->session->userdata('user_type');

		$data['username']	= $this->session->userdata('username');
		$data['user_type']  = $this->session->userdata('user_type');
		$data['tasks']		= $this->projectslib->getUserTasks($project_id, $user_type, $user_id, "all", "yes");
		$data['user_types'] = $this->userslib->getUserTypes("");

		$i = 0;

		if (is_array($data['tasks']))
		{
			foreach ($data['tasks'] as $elem) 
			{
				$assigned_devs = $this->taskslib->getAssignedTask($elem->id); // elem_id = task_id

				$developer_names = "";

				if (is_array($assigned_devs))
				{
					$numItems = count($assigned_devs);
					$j = 0;

					foreach ($assigned_devs as $elem) 
					{
						$dev_info = $this->userslib->getUserProfile($elem->user_id);

						if (is_object($dev_info))
						{
							if (++$j === $numItems)
							{
								$developer_names .= $dev_info->first_name." ".$dev_info->last_name;
							}
							else
							{
								$developer_names .= $dev_info->first_name." ".$dev_info->last_name.", ";
							}
						}
						else
						{
							$developer_names = "None";
						}
					}
				}
				else
				{
					$developer_names = "None";
				}

				$data['tasks'][$i]->developers =  $developer_names;
				$i++;
			}

		}

		$data["project_name"] = $this->projectslib->getProjectData($project_id);
		$data['user_types']   = $this->userslib->getUserTypes("");

		$this->load->view('tasks', $data);
	}

	public function view($slug)
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('projectslib');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('memberslib');

		$task_id 	= $slug;
		$user_id 	= $this->session->userdata("user_id");
		$user_type	= $this->session->userdata("user_type");

		if ($user_type == 4)
		{
			$check = $this->taskslib->checkUserTaskExist($user_id, $task_id, 'client');

			if ($check == 0)
			{
				redirect(base_url()."tasks");
			}
		}

		if ($user_type == 3)
		{
			$check = $this->taskslib->checkUserTaskExist($user_id, $task_id, 'developer');

			if ($check == 0)
			{
				redirect(base_url()."tasks");
			}
		}

		$data['username']				= $this->session->userdata('username');
		$data['task'] 					= $this->projectslib->browseTaskData($task_id);
		$data['task_comments'] 			= $this->taskslib->getTaskComments($task_id);
		$data['task_assigned']  		= $this->taskslib->getTaskAssignedDeveloper($task_id, 'info');

		if (is_array($data['task_assigned']))
		{
			$i = 0;
			$developer_info = array();

			foreach ($data['task_assigned']  as $elem) 
			{
				$developer_info[$i] 	= $this->userslib->getUserProfile($elem->user_id);
				$i++;
			}

			$data['developer_info'] 	= $developer_info;
		}
		else
		{
			$data['developer_info'] 	= 0;
		}

		$project_id 					= $data['task']->project_id;
		$data["author_info"] 			= $this->userslib->getMemberInfo($data['task']->user_id);
		$data['project_managers_info'] 	= $this->projectslib->getProjectManagersForProjects($project_id);
 		$data['user_avatar']    		= $this->userslib->getMemberInfo($user_id);
 		$data['user_types']     		= $this->userslib->getUserTypes("");
		$data['task_id'] 				= $task_id;

		$this->load->view('task', $data);
	}

	public function addTaskComments()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('projectslib');
		$this->load->library('functions');
		$this->load->library('emailstacklib');
		$this->load->library('notificationslib');

		$user_id 	= $this->session->userdata("user_id");
		$user_type 	= $this->session->userdata("user_type"); 

		$task_id = $this->input->post("task_id");
		$comment = $this->input->post("comment");
		
		// Add new task comment
		$result = $this->taskslib->addTaskComments($task_id, $user_id, $comment);

		$user_info = $this->userslib->getUserNames($user_id);
		$task_info = $this->taskslib->getTaskInfo($task_id);

		$pms_info 		= $this->projectslib->getPMAssignedList($task_info->project_id);
		$client_info 	= $this->projectslib->getClientAssignedList($task_info->project_id);
		$developer_info = $this->taskslib->getTaskAssignedDeveloper($task_info->id, 'email');

		// Send email variables
		$sender 	= $this->config->item("sender_email");
		$name 		= $this->config->item("sender_name");
		$subject 	= "New Message";
		$message 	= "Hi,<br /><br />
					A message has been added for <b>".$task_info->name."</b> task by <b>".$user_info->first_name." ".$user_info->last_name."</b>!<br /><br />
					Please <a href='".base_url()."tasks/view/".$task_id."'>login</a> to your account to view the message.<br /><br />
					Thanks,<br />
					".$name."";

		$user_id_array = array();

		// Send email to persons who is assigned to task, when add a comment to task
		if ($this->config->item("send_emails") == "yes")
		{
			// We get all users who must receive an email into one big'o'array
			$users_array = array();
			$i = 0;

			if (is_array($pms_info)) foreach ($pms_info as $elem) 
			{
				$users_array[$i]['user_id'] 		= $elem->user_id;
				$users_array[$i]['user_type'] 		= 'pm';
				$users_array[$i]['id'] 				= $elem->id;
				$users_array[$i]['email'] 			= $elem->email;
				$users_array[$i]['receive_email'] 	= $elem->receive_email;
				$i++;
			}

			if (is_array($client_info)) foreach ($client_info as $elem) 
			{
				$users_array[$i]['user_id'] 		= $elem->user_id;
				$users_array[$i]['user_type'] 		= 'client';
				$users_array[$i]['id'] 				= $elem->id;
				$users_array[$i]['email'] 			= $elem->email;
				$users_array[$i]['receive_email'] 	= $elem->receive_email;
				$i++;
			}

			if (is_array($developer_info)) foreach ($developer_info as $elem) 
			{
				$users_array[$i]['user_id'] 		= $elem->user_id;
				$users_array[$i]['user_type'] 		= 'developer';
				$users_array[$i]['id'] 				= $elem->id;
				$users_array[$i]['email'] 			= $elem->email;
				$users_array[$i]['receive_email'] 	= $elem->receive_email;
				$i++;
			}

			$count = count($users_array);

			// We get through the huge array and send the emails
			for ($i = 0; $i < $count; $i++)
			{
				array_push($user_id_array, $users_array[$i]['user_id']);

				if ($user_id != $users_array[$i]['user_id'])
				{
					$receiver = $users_array[$i]['email'];
					
					if ($users_array[$i]['receive_email'] == 'yes')
					{
						$this->emailstacklib->addEmailInStack($sender, $receiver, $name, $subject, $message);
					}
				}
			}
		}

		// Add notification to users
		$user_id_array = array_values(array_unique($user_id_array));

		for ($i = 0; $i < count($user_id_array); $i++) 
		{ 
			$user_info = $this->userslib->getUserProfile($user_id_array[$i]);

			if ($user_info->receive_notifications == 'yes')
			{
				$type_id = $this->notificationslib->getNotificationTypeByName("New Comment")->id;
				$this->notificationslib->addNotification($user_id_array[$i], $type_id, $task_id, $message);
			}
		}

		$operation = array();

		if ($result != 0)
		{
			$operation["success"] 		= 1;
			$operation["comment_id"] 	= $result;
		}
		else
		{
			$operation["success"] = 0;
			$operation["message"] = "Comment could not be added!";
		}

		echo json_encode($operation);
	}

	public function uploadCommentAttachment()
	{
		$this->load->helper('url');
		$this->load->helper('text');
		$this->load->library('taskslib');

		$comment_id = $this->input->post("comment_id");

		$to_add = '_'.date("Y_m_d_H_i_s");
		$string = $_FILES['file']['name'][0];
		
		$attachments = "";

		$path = FCPATH.'/uploads/';

		if (!empty($_FILES))
		{
			$cnt = count($_FILES['file']['tmp_name']);

			for ($i = 0; $i < $cnt; $i++)
			{
				$filename 		= $_FILES['file']['name'][$i];
				$filename 		= convert_accented_characters(str_replace(" ", "-", $filename));
				$dot_position 	= strrpos($filename, '.');
				$new_filename 	= substr_replace($filename, $to_add.'.', $dot_position , 1);

				$tmp_file = $_FILES['file']['tmp_name'][$i];
				$targetFile = $path.$new_filename;
				move_uploaded_file($tmp_file,$targetFile);
				$attachments .= $new_filename.',';
			}
		}

		if ($attachments != "")
		{
			$this->taskslib->addCommentAttachments($comment_id, $attachments);
		}
	}

	public function uploadTaskAttachment()
	{
		$this->load->helper('url');
		$this->load->helper('text');
		$this->load->library('taskslib');

		$task_id = $this->input->post("task_id");
		$from 	 = $this->input->post("from");

		$to_add = '_'.date("Y_m_d_H_i_s");
		$string = $_FILES['file']['name'][0];
		
		$attachments = "";

		$path = FCPATH.'/uploads/';

		if (!empty($_FILES))
		{
			$cnt = count($_FILES['file']['tmp_name']);

			for ($i = 0; $i < $cnt; $i++)
			{
				$filename 		= $_FILES['file']['name'][$i];
				$filename 		= convert_accented_characters(str_replace(" ", "-", $filename));
				$dot_position 	= strrpos($filename, '.');
				$new_filename 	= substr_replace($filename, $to_add.'.', $dot_position , 1);

				$tmp_file = $_FILES['file']['tmp_name'][$i];
				$targetFile = $path.$new_filename;
				move_uploaded_file($tmp_file,$targetFile);
				$attachments .= $new_filename.',';
			}
		}

		if ($attachments != "")
		{
			if ($from == 'edit')
			{
				$curr_att = $this->taskslib->getTaskInfo($task_id)->attachments;
				$attachments = $curr_att.$attachments;
			}

			$this->taskslib->addTaskAttachments($task_id, $attachments);
		}
	}

	public function removeTaskAttachment()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('taskslib');

		$task_id  	= $this->input->post('task_id');
		$filename 	= $this->input->post('filename');

		$path 		= FCPATH.'/uploads/';
		$output 	= array();
		$result 	= 0;

		if (unlink($path.$filename))
		{
			$curr_att 	= $this->taskslib->getTaskInfo($task_id)->attachments;
			$new_att  	= str_replace($filename.',', '', $curr_att);
			$result   	= $this->taskslib->addTaskAttachments($task_id, $new_att);
		}

		if ($result == 1)
		{
			$output['success'] = 1;
		}
		else
		{
			$output['success'] = 0;
		}

		echo json_encode($output);

	}

	public function downloadAttachment($slug)
	{
		$this->load->helper('url');
		$this->load->helper('download');

		$path 		= FCPATH.'uploads/';
		$filename 	= urldecode($slug);
		
		$data = file_get_contents($path.$filename);
		force_download($filename, $data);
	}

	public function getTaskShares()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('projectslib');

		$user_id = $this->session->userdata("user_id");

		$not_assigned 	= $this->taskslib->getShareByStatus($user_id, 'Not Assigned');
		$assigned 		= $this->taskslib->getShareByStatus($user_id, 'Assigned');
		$in_progress 	= $this->taskslib->getShareByStatus($user_id, 'In Progress');
		$completed 		= $this->taskslib->getShareByStatus($user_id, 'Completed');

		if (is_array($not_assigned))
			$not_assigned = count($not_assigned);
		else
			$not_assigned = 0;

		if (is_array($assigned))
			$assigned = count($assigned);
		else
			$assigned = 0;

		if (is_array($in_progress))
			$in_progress = count($in_progress);
		else
			$in_progress = 0;

		if (is_array($completed))
			$completed = count($completed);
		else
			$completed = 0;

		$all = $this->taskslib->getUserTasks($user_id);
		$all = count($all);

		if ($not_assigned != 0)
			$not_assigned = round($not_assigned / $all * 100);

		if ($assigned != 0)
			$assigned = round($assigned / $all * 100);

		if ($in_progress != 0)
			$in_progress = round($in_progress / $all * 100);

		if ($completed != 0)
			$completed = round($completed / $all * 100);

		$operation = array();
		
		$operation['not_assigned'] 	= $not_assigned;
		$operation['assigned'] 		= $assigned;
		$operation['in_progress'] 	= $in_progress;
		$operation['completed'] 	= $completed;

		echo json_encode($operation);
	}

	// Ajax calls to load datatables
	public function getManagedTasks()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('taskslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$user_id 		= $this->session->userdata('user_id');
		$user_type 		= $this->session->userdata('user_type');
		$priority       = "";

		if (strlen($search) > 0)
		{
			$tasks 				= $this->taskslib->getManagedTasks($user_id, $start, $offset, $search, $sort_col, $sort_dir, $user_type);
			$tasks_pagination 	= $this->taskslib->getManagedTasks($user_id, "", "", $search, $sort_col, $sort_dir, $user_type);
		}
		else
		{
			$tasks 				= $this->taskslib->getManagedTasks($user_id, $start, $offset, "", $sort_col, $sort_dir, $user_type);
			$tasks_pagination 	= $this->taskslib->getManagedTasks($user_id, "", "", "", $sort_col, $sort_dir, $user_type);
		}

		$tasks_data = array();

		if (is_array($tasks))
		{
			for ($j = 0; $j < count($tasks); $j++) 
			{ 
				// Englobe status message in colored container
				$status = "";

				if ($tasks[$j]['status'] == "Assigned") 
				{
					$status = '<span class="label label-warning">'.lang("status_assigned").'</span>';
				}
				else if ($tasks[$j]['status'] == "In Progress")
				{
					$status = '<span class="label label-info">'.lang("status_in_progress").'</span>';
				}
				else if ($tasks[$j]['status'] == "Not Assigned")
				{
					$status = "<span class='label'>".lang("status_not_assigned")."</span>";
				}
				else
				{
					$status = "<span class='label label-success'>".lang("status_completed")."</span>";
				}

				// Check if due date is set
				if ($tasks[$j]['create_date'] == '0000-00-00')
				{
					$ddate 	= lang('status_not_set');
				}
				else
				{
					$ddate 	= $tasks[$j]['create_date'];
				}

				$action = "<a class='btn btn-success' href=".base_url()."tasks/view/".$tasks[$j]["id"]." title=".lang("btn_view")."><i class='fa fa-eye'></i></a>&nbsp;";

				if ($user_type <= 2)
				{
					$action .= "<a class='btn btn-info' href=".base_url()."tasks/edit/".$tasks[$j]["id"]." title=".lang("btn_edit")."><i class='fa fa-pencil'></i></a>&nbsp;<a class='btn btn-danger' href='#' onclick='showDialog.call(this, event, \"delete_task_dialog\", \"".$tasks[$j]['id']."\", \"task_id\", \"".$tasks[$j]["name"]."\")' title=\"".lang("btn_delete")."\"><i class='fa fa-trash-o'></i></a>";
				}

				$priority = "";

				if (strtolower($tasks[$j]["priority"]) == 'urgent' )
				{
					$priority = '<i class="fa fa-exclamation-triangle red" title="'.lang("tooltip_urgent").'"></i>';
				}
				else if (strtolower($tasks[$j]["priority"]) == 'high')
				{
					$priority = '<i class="fa fa-exclamation-triangle lightOrange" title="'.lang("tooltip_high").'"></i>';
				}

				$tasks_data[$j][] = $priority." ".$tasks[$j]["name"];
				$tasks_data[$j][] = $tasks[$j]['pname'];
				$tasks_data[$j][] = $this->functions->dateFormat($tasks[$j]['create_date']);
				$tasks_data[$j][] = strlen($tasks[$j]['first_name']) > 0 ? $tasks[$j]['first_name'].' '.$tasks[$j]['last_name'] : 'None';
				$tasks_data[$j][] = $status;
				$tasks_data[$j][] = $action;
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($tasks_pagination),
			"iTotalDisplayRecords" => count($tasks_pagination),
			"aaData" => $tasks_data
		);

		echo json_encode($output);
	}
}