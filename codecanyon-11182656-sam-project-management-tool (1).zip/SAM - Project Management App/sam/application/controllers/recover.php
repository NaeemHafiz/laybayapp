<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Recover extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->view('recover');
	}

	public function recoverPassword()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('email');
		$this->load->library('userslib');
		$this->load->library('functions');

		$return = array();
		$email = $this->input->post('recover_email');
		$check = $this->userslib->checkEmail($email);

		if (is_object($check))
		{
			$rand_string = $this->userslib->rand_string(8);
			$result = $this->userslib->updatePassword($check->user_id, $rand_string);

			if ($result == 1)
			{
				$res = 0;
				if ($this->config->item("send_emails") == "yes")
				{
					$user_info 	= $this->userslib->getUserData($check->user_id);
					$sender  	= $this->config->item("sender_email");
					$receiver 	= $email;
					$name 		= $this->config->item("sender_name");
					$subject 	= "Recover Password";
					$message 	= "Hi ".$check->first_name.",<br /><br />
								You requested to change your password!<br />
								Here are your new login details:<br /><br />
								<b>Username</b>: ".$user_info->username."<br />
								<b>Password</b>: ".$rand_string."<br /><br />
								Regards,<br />
								".$name."";

					$res = $this->functions->sendEmail($sender, $receiver, $name, $subject, $message);
				}

				if ($res == 1)
				{
					$return['success'] = 1;
				}
				else
				{
					$return['success'] = 0;
					$return['message_type'] = 0;
				}
			}
			else
			{
				$return['success'] = 0;
				$return['message_type'] = 1;
			}
		}
		else
		{
			$return['success'] = 0;
			$return['message_type'] = 2;
		}

		echo json_encode($return);
	}

}