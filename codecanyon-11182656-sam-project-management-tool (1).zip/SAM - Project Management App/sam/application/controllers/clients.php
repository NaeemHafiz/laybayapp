<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Clients extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('clientslib');

		$data['username'] 		= $this->session->userdata('username');
		
		$this->load->view('clients', $data);
	}

	public function add()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('functions');
		$this->load->library('clientslib');

		$data['last_clients']	= $this->clientslib->getLastsClients();
		$data["countries"] 		= $this->functions->getCountries();

		$this->load->view('client_add', $data);
	}

	public function client_add_save()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('clientslib');
		$this->load->library('functions');

		$client_uname 		= $this->input->post('client_uname');
		$client_fname 		= $this->input->post('client_fname');
		$client_lname 		= $this->input->post('client_lname');
		$client_email 		= $this->input->post('client_email');
		$client_phone 		= $this->input->post('client_phone');
		$client_pword 		= $this->input->post('client_pword');
		$client_cpword 		= $this->input->post('client_cpword');
		$client_cname 		= $this->input->post('client_cname');
		$home_page			= $this->input->post('home_page');
		$client_country 	= $this->input->post('client_country');
		$client_city 		= $this->input->post('client_city');
		$client_send_email 	= $this->input->post('client_send_email');

		$check 		 = $this->userslib->checkUsernameExists($client_uname, 0);
		$check_email = $this->userslib->checkEmailExists($client_email, 0);  

		$result = 0;

		if (($check == 0) && ($check_email == 0))
		{
			$client_id 	= $this->clientslib->addClient($client_uname, $client_cpword);
			$result 	= $this->clientslib->addClientProfile($client_id, $client_fname, $client_lname, $client_email, $client_phone, $client_cname, $home_page, $client_country, $client_city);
		}

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Log message
		$text =  "Client ".$client_fname." ".$client_lname." was added by ".$user_info->first_name." ".$user_info->last_name;

		// Remove last / from base_url()
		$cururl = substr(base_url(), 0, -1);

		// Configuring email parameters (for new clients)
		$sender = $this->config->item('sender_email');
		$receiver = $client_email;
		$name = $this->config->item('sender_name');
		$subject = 'Welcome to SAM';
		$message = 'Hi '.$client_fname.',
		<br /><br />
		<b>Welcome to SAM!</b> We’re glad to have you as a customer.
		<br /><br />
		SAM is our online app which is designated to manage tasks allocation within the company, with the possibility to interact with customer and for projects that are developed for an external use.
		<br /><br />
		You can access your account any time by going to:
		<br /><br />
		<a href="'.$cururl.'" target="_blank">'.$cururl.'</a>
		<br /><br />
		<b>Username</b>: '.$client_uname.'<br />
		<b>Password</b>: '.$client_pword.'
		<br /><br />
		If you have any feedback, please let us know at <a href="mailto:'.$this->config->item('contact_email').'">'.$this->config->item('contact_email').'</a>.
		<br /><br />
		Thanks,<br />
		'.$this->config->item('sender_name');
	
		$operation = array();

		if ($result != 0)
		{
			if ($client_send_email == "on")
			{
				$this->functions->sendEmail($sender, $receiver, $name, $subject, $message);
			}
			$this->functions->writelog($text);
			
			$operation["success"] = 1;
		}
		else
		{
			if ($check == 1)
			{
				$operation["message"] = 2;
			}

			if ($check_email == 1)
			{
				$operation["message"] = 3;
			}

			if (($check == 1) && ($check_email == 1))
			{
				$operation["message"] = 4;
			}

			$operation["success"] = 0;
		}

		echo json_encode($operation);
	}

	public function edit($slug)
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('functions');

		$data['types'] = $this->userslib->getUserTypes("yes");
		$data['username'] = $this->session->userdata('username');
		$data['client_info'] = $this->userslib->getUserProfile($slug);
		$data['countries'] = $this->functions->getCountries();

		$this->load->view('client_edit', $data);
	}

	public function client_edit_save()
	{
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('userslib');

		$client_fname 	= $this->input->post('client_fname');
		$client_lname 	= $this->input->post('client_lname');
		$client_email 	= $this->input->post('client_email');
		$client_phone 	= $this->input->post('client_phone');
		$client_pword 	= $this->input->post('client_pword');
		$client_cpword 	= $this->input->post('client_cpword');
		$client_cname 	= $this->input->post('client_cname');
		$edit_home_page = $this->input->post('edit_home_page');
		$client_country = $this->input->post('client_country');
		$client_city 	= $this->input->post('client_city');
		$client_id 		= $this->input->post('client_id');
		$status_active 	= ($this->input->post('status_active') == "on" ? "yes" : "no");

		$result = 0;
		$verif = 0;

		if (($client_pword == $client_cpword) && ($client_pword != "") && ($client_cpword != ""))
		{	
			$verif = 1;
		}

		$check_email = $this->userslib->checkEmailExists($client_email, $client_id);  

		if ($check_email == 0)
		{
			$result  = $this->userslib->modifyUserProfile($client_id, $client_fname, $client_lname, $client_email, $client_phone, $client_cname, $edit_home_page, $client_country, $client_city, 'no', 'no');
		}
		
		$result2 = $this->userslib->modifyUser($client_id, $client_cpword, 4, $status_active);

		$operation = array();

		if (($result == 1) && ($result2 == 1))
		{
			$operation['success'] = 1;
		}
		else
		{
			if ($check_email == 1)
			{
				$operation['success'] = 2;
			}
			else
			{
				$operation['success'] = 0;
			}
		}

		echo json_encode($operation);
	}

	public function client_delete()
	{
		$this->load->library('memberslib');
		$this->load->library('session');
		$this->load->library('functions');

		$id = $this->input->post('client_id');

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Deleted user info
		$del_user	= $this->userslib->getUserProfile($id);

		// Log message
		$text = $user_info->first_name." ".$user_info->last_name." has disabled the client ".$del_user->first_name." ".$del_user->last_name."/".$del_user->comp_name;

		$result = $this->memberslib->deleteMember($id);

		if ($result == 1)
		{
			$this->functions->writelog($text);
			$return['success'] = 1;
			$return['message'] = 'Sucessfully deleted!';
		}
		else
		{
			$return['success'] = 0;
			$return['message'] = 'Could not delete!';
		}
		
		echo json_encode($return);
	}

	public function client_delete_definitely()
	{
		$this->load->library('memberslib');
		$this->load->library('session');
		$this->load->library('functions');

		$id = $this->input->post('client_id');

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Deleted user info
		$del_user	= $this->userslib->getUserProfile($id);

		// Log message
		$text = $user_info->first_name." ".$user_info->last_name." has deleted the client ".$del_user->first_name." ".$del_user->last_name."/".$del_user->comp_name;

		$result = $this->memberslib->deleteMemberFromDatabase($id);

		if ($result == 1)
		{
			$this->functions->writelog($text);
			$return['success'] = 1;
			$return['message'] = 'Sucessfully deleted!';
		}
		else
		{
			$return['success'] = 0;
			$return['message'] = 'Could not delete!';
		}
		
		echo json_encode($return);
	}

	function getClients()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('clientslib');
		$this->load->library('userslib');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$status 		= $this->input->get('status');

		if (strlen($status) < 1)
		{
			$status = "yes";
		}

		if (strlen($search) > 0)
		{
			$clients 				= $this->clientslib->getClients($status, $start, $offset, $search, $sort_col, $sort_dir);
			$clients_pagination 	= $this->clientslib->getClients($status, "", "", $search);
		}
		else
		{
			$clients 				= $this->clientslib->getClients($status, $start, $offset, "", $sort_col, $sort_dir);
			$clients_pagination 	= $this->clientslib->getClients($status);
		}

		$clients_data = array();

		if (is_array($clients))
		{
			for ($j=0; $j < count($clients); $j++) 
			{ 
				$status = "";
				switch ($clients[$j]["active"]) {
					case 'yes':
						$status = '<span class="label label-success">'.lang('label_active').'</span>';
						break;
					case 'no':
						$status = '<span class="label">'.lang('label_inactive').'</span>';
						break;
					default:
						$status = '<span class="label">'.lang('label_inactive').'</span>';
						break;
				}

				$clients_data[$j][] = $clients[$j]["first_name"].' '.$clients[$j]["last_name"];
				$clients_data[$j][] = $clients[$j]["email"];
				$clients_data[$j][] = $clients[$j]["comp_name"];
				$clients_data[$j][] = $status;
				$clients_data[$j][] = "	<a class=\"btn btn-info\" href=\"".base_url()."clients/edit/".$clients[$j]["id"]."\" title=\"".lang("btn_edit")."\">
												<i class=\"fa fa-pencil\"></i>
										</a>
										<a class=\"btn btn-warning\" href=\"#\" onclick=\"showDialog.call(this, event, 'delete_client_dialog', ".$clients[$j]["id"].", 'client_id', '".$clients[$j]["first_name"]." ".$clients[$j]["last_name"]."');\" title=\"".lang("btn_disable")."\">
											<i class=\"fa fa-ban\"></i>
										</a>
										<a class=\"btn btn-danger\" href=\"#\" onclick=\"showDialog.call(this, event, 'delete_client_definitely_dialog', ".$clients[$j]["id"].", 'def_client_id', '".$clients[$j]["first_name"]." ".$clients[$j]["last_name"]."');\" title=\"".lang("btn_delete")."\">
											<i class=\"fa fa-trash-o\"></i>
										</a>
										<input type=\"hidden\" id=\"client_id\" name=\"client_id\" value=\"".$clients[$j]["id"]."\" />";
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($clients_pagination),
			"iTotalDisplayRecords" => count($clients_pagination),
			"aaData" => $clients_data
		);

		echo json_encode($output);
	}

}