<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Members extends CI_Controller {

	public function index()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('memberslib');

		$data['username'] = $this->session->userdata('username');

		$this->load->view('members', $data);
	}

	public function add()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('functions');

		$data['types'] = $this->userslib->getUserTypesWithoutClient();
		$data['username'] = $this->session->userdata('username');
		$data['countries'] = $this->functions->getCountries();

		$this->load->view('member_add', $data);
	}

	public function member_add_save()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('memberslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$return = array();

		$uname 		= $this->input->post('new_uname');
		$password 	= $this->input->post('new_pword');
		$utype 		= $this->input->post('new_utype');
		$fname 		= $this->input->post('new_fname');
		$lname 		= $this->input->post('new_lname');
		$email 		= $this->input->post('new_email');
		$avatar 	= $this->input->post('new_avatar');
		$phone 		= $this->input->post('new_phone');
		$hrate 		= $this->input->post('new_hrate');
		$cname 		= $this->input->post('new_cname');
		$homepage	= $this->input->post('home_page');
		$country 	= $this->input->post('new_country');
		$city 		= $this->input->post('new_city');

		$check 			= $this->userslib->checkUsernameExists($uname, 0);
		$check_email 	= $this->userslib->checkEmailExists($email, 0);

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Log message
		$text = "Member ".$fname." ".$lname." was added by ".$user_info->first_name." ".$user_info->last_name;

		// Remove last / from base_url()
		$cururl = substr(base_url(), 0, -1);

		// Configuring email parameters (for new member)
		$sender = $this->config->item('sender_email');
		$receiver = $email;
		$name = $this->config->item('sender_name');
		$subject = 'Welcome to SAM';
		$message = 'Hi '.$fname.',
		<br /><br />
		<b>Welcome to SAM!</b> We’re glad to have you as a team member.
		<br /><br />
		SAM is our online app which is designated to manage tasks allocation within the company, with the possibility to interact with customer and for projects that are developed for an external use.
		<br /><br />
		You can access your account any time by going to:
		<br /><br />
		<a href="'.$cururl.'" target="_blank">'.$cururl.'</a>
		<br /><br />
		<b>Username</b>: '.$uname.'<br />
		<b>Password</b>: '.$password.'
		<br /><br />
		Thanks,<br />
		'.$this->config->item('sender_name');

		$result = 0;

		if (($check == 0) && ($check_email == 0))
		{
			$result = $this->memberslib->addMember($uname, $password, $utype, $fname, $lname, $email, $avatar, $phone, $hrate, $cname, $homepage, $country, $city);
		}

		if ($result == 1)
		{
			$this->functions->sendEmail($sender, $receiver, $name, $subject, $message);
			$this->functions->writelog($text);
			$return['success'] = 1;
		}
		else
		{
			if ($check == 1)
			{
				$return['message'] = 2;
			}

			if ($check_email == 1)
			{
				$return["message"] = 3;
			}

			if (($check == 1) && ($check_email == 1))
			{
				$return["message"] = 4;
			}
			
			$return["success"] = 0;
		}

		echo json_encode($return);

	}

	public function edit($slug)
	{	
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('userslib');
		$this->load->library('functions');

		$data['types'] = $this->userslib->getUserTypes("yes");
		$data['username'] = $this->session->userdata('username');
		$data['member_info'] = $this->userslib->getUserProfile($slug);
		$data['countries'] = $this->functions->getCountries();

		$this->load->view('member_edit', $data);
	}


	public function member_delete()
	{
		$this->load->library('memberslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$id = $this->input->post('member_id');

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Deleted user info
		$del_user	= $this->userslib->getUserProfile($id);

		// Log message
		$text = $user_info->first_name." ".$user_info->last_name." has disabled the member ".$del_user->first_name." ".$del_user->last_name."/".$del_user->comp_name;

		$result = $this->memberslib->deleteMember($id);

		if ($result == 1)
		{
			$this->functions->writelog($text);
			$return['success'] = 1;
			$return['message'] = 'Sucessfully deleted!';
		}
		else
		{
			$return['success'] = 0;
			$return['message'] = 'Could not delete!';
		}

		echo json_encode($return);
	}

	public function member_delete_definitely()
	{
		$this->load->library('memberslib');
		$this->load->library('userslib');
		$this->load->library('functions');

		$id = $this->input->post('member_id');

		// Get session user information for log
		$user_id 	= $this->session->userdata('user_id');
		$user_info 	= $this->userslib->getUserProfile($user_id);

		// Deleted user info
		$del_user	= $this->userslib->getUserProfile($id);

		// Log message
		$text = $user_info->first_name." ".$user_info->last_name." has deleted the member ".$del_user->first_name." ".$del_user->last_name."/".$del_user->comp_name;

		$result = $this->memberslib->deleteMemberFromDatabase($id);

		if ($result == 1)
		{
			$this->functions->writelog($text);
			$return['success'] = 1;
			$return['message'] = 'Sucessfully deleted!';
		}
		else
		{
			$return['success'] = 0;
			$return['message'] = 'Could not delete!';
		}

		echo json_encode($return);
	}

	public function member_edit_save()

	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');

		$this->load->library('userslib');

		$username 		= $this->input->post("edit_uname");
		$pword 			= $this->input->post("edit_pword");
		$cpword 		= $this->input->post("edit_cpword");
		$user_type 		= $this->input->post("edit_utype");
		$fname 			= $this->input->post("edit_fname");
		$lname 			= $this->input->post("edit_lname");
		$email 			= $this->input->post("edit_email");
		$phone 			= $this->input->post("edit_phone");
		$hrate 			= $this->input->post("edit_hrate");
		$cname 			= $this->input->post("edit_cname");
		$homepage   	= $this->input->post("edit_home_page");
		$country 		= $this->input->post("edit_country");
		$city 			= $this->input->post("edit_city");
		$member_id		= $this->input->post("member_id");
		$status_active 	= ($this->input->post('status_active') == "on" ? "yes" : "no");

		$check 		 = $this->userslib->checkUsernameExists($username, $member_id);
		$check_email = $this->userslib->checkEmailExists($email, $member_id);  

		$result 	= 0;
		$result2 	= 0;
		$verif 		= 0;

		if (($pword == $cpword) && ($pword != "") && ($cpword != ""))
		{	
			$verif = 1;
		}

		if (($check == 0) && ($check_email == 0))
		{
			$result  = $this->userslib->modifyStaffProfile($member_id, $fname, $lname, $email, $phone, $hrate, $cname, $homepage, $country, $city);
			$result2 = $this->userslib->modifyStaff($member_id, $verif, $username, $cpword, $user_type, $status_active);
		}

		$operation = array();

		if (($result == 1) && ($result2 == 1))
		{
			$operation['success'] = 1;
		}
		else
		{
			if ($check == 1)
			{
				$operation["message"] = 2;
			}

			if ($check_email == 1)
			{
				$operation["message"] = 3;
			}
			
			if (($check == 1) && ($check_email == 1))
			{
				$operation["message"] = 4;
			}

			$operation["success"] = 0;
		}

		echo json_encode($operation);
	}

	// Get members for datatable
	function getMembers()
	{
		$this->load->helper('url');
		$this->load->helper('language');
		$this->load->library('session');
		$this->load->library('memberslib');
		$this->load->library('userslib');

		$start 			= $this->input->get('iDisplayStart');
		$offset			= $this->input->get('iDisplayLength');
		$search			= $this->input->get('sSearch');

		$sort_col 		= $this->input->get('iSortCol_0');
		$sort_dir 		= $this->input->get('sSortDir_0');

		$status 		= $this->input->get('status');

		if (strlen($status) < 1)
		{
			$status = "yes";
		}

		if (strlen($search) > 0)
		{
			$members 				= $this->memberslib->getMembers($status, $start, $offset, $search, $sort_col, $sort_dir);
			$members_pagination 	= $this->memberslib->getMembers($status, "", "", $search);
		}
		else
		{
			$members 				= $this->memberslib->getMembers($status, $start, $offset, "", $sort_col, $sort_dir);
			$members_pagination 	= $this->memberslib->getMembers($status);
		}

		$members_data = array();

		if (is_array($members))
		{
			for ($j=0; $j < count($members); $j++) 
			{ 
				$status = "";
				switch ($members[$j]["active"]) {
					case 'yes':
						$status = '<span class="label label-success">'.lang('label_active').'</span>';
						break;
					case 'no':
						$status = '<span class="label">'.lang('label_inactive').'</span>';
						break;
					default:
						$status = '<span class="label">'.lang('label_inactive').'</span>';
						break;
				}

				$members_data[$j][] = $members[$j]["first_name"].' '.$members[$j]["last_name"];
				$members_data[$j][] = $members[$j]["email"];
				$members_data[$j][] = $members[$j]["name"];
				$members_data[$j][] = $status;
				$members_data[$j][] = "	<a class=\"btn btn-info\" href=\"".base_url()."members/edit/".$members[$j]["id"]."\" title=\"".lang("btn_edit")."\">
												<i class=\"fa fa-pencil\"></i>
										</a>
										<a class=\"btn btn-warning\" href=\"#\" onclick=\"showDialog.call(this, event, 'delete_member_dialog', ".$members[$j]["id"].", 'member_id', '".$members[$j]["first_name"]." ".$members[$j]["last_name"]."');\" title=\"".lang("btn_disable")."\">
											<i class=\"fa fa-ban\"></i>
										</a>
										<a class=\"btn btn-danger\" href=\"#\" onclick=\"showDialog.call(this, event, 'delete_member_definitely_dialog', ".$members[$j]["id"].", 'def_member_id', '".$members[$j]["first_name"]." ".$members[$j]["last_name"]."');\" title=\"".lang("btn_delete")."\">
											<i class=\"fa fa-trash-o\"></i>
										</a>
										<input type=\"hidden\" id=\"member_id\" name=\"member_id\" value=\"".$members[$j]["id"]."\" />";
			}
		}

		$output = array(
			"sEcho" => intval($this->input->get('sEcho')),
			"iTotalRecords" => count($members_pagination),
			"iTotalDisplayRecords" => count($members_pagination),
			"aaData" => $members_data
		);

		echo json_encode($output);
	}
}