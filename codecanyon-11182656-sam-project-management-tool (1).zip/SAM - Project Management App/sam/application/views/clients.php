<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">

	<!-- Dialog box to disable client --> 
	<div class="modal fade in hide" id="delete_client_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_client_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_disable_client");?></h2>
					</div>
				</div>
				<input type="hidden" id="client_id" name="client_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="delete_client.call(this, event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>

	<!-- Dialog box to delete client from database -->
	<div class="modal fade in hide" id="delete_client_definitely_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_client_definitely_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_delete_client");?></h2>
					</div>
				</div>
				<input type="hidden" id="def_client_id" name="client_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="delete_client_definitely.call(this, event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>

	<!-- Page content -->
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-user"></i><span class="break"></span><?=lang("title_clients");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>

				<? if ($user_type == 1) { ?>
					<a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>clients/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_client");?></a>
				<? } ?>
			</div>
			
			<div class="box-content">
				<form class="form-horizontal" name="clients_form" id="clients_form">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered" id="clients-table">
								<thead>
									<tr role="row">
										<th><?=lang("thead_name");?></th>
										<th><?=lang("thead_email");?></th>
										<th><?=lang("thead_company");?></th>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>

					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? /* $odd_even = 0; if (is_array($clients)) { foreach ($clients as $elem) { ?>
						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center"><?=$elem->first_name." ".$elem->last_name;?></td>
										<td class="center"><?=$elem->email;?></td>
										<td class="center"><?=$elem->comp_name;?></td>
										<td class="center">
											<a class="btn btn-info" href="<?=base_url();?>clients/edit/<?=$elem->id;?>" title="<?=lang("btn_edit");?>">
												<i class="fa fa-pencil"></i>
											</a>
											<? $fulname = $elem->first_name." ".$elem->last_name; ?>
											<a class="btn btn-warning" href="#" onclick="showDialog.call(this, event, 'delete_client_dialog', <?=$elem->id;?>, 'client_id', '<?=$fulname;?>');" title="<?=lang("btn_disable");?>">
												<i class="fa fa-ban"></i>
											</a>
											<a class="btn btn-danger" href="#" onclick="showDialog.call(this, event, 'delete_client_definitely_dialog', <?=$elem->id;?>, 'def_client_id', '<?=$fulname;?>');" title="<?=lang("btn_delete");?>">
												<i class="fa fa-trash-o"></i>
											</a>
										</td>
										<input type="hidden" id="client_id" name="client_id" value="<?=$elem->id;?>" />
									</tr>
									<? $odd_even++;	} } */ ?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>