<div class="box-header">
	<h2><i class="fa fa-hand-o-up"></i><?=lang("title_shortcuts");?></h2>
	<div class="box-icon">
		<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
		<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	</div>
</div>

<div class="box-content">
	<a href="<?=base_url();?>projects/add" class="quick-button-small span3">
		<i class="fa fa-list-alt"></i>
		<p><?=lang("btn_new_project");?></p>
	</a>

	<a href="<?=base_url();?>tasks/add" class="quick-button-small span3">
		<i class="fa fa-tasks"></i>
		<p><?=lang("btn_new_task");?></p>
	</a>

	<a href="<?=base_url();?>tickets" class="quick-button-small span3">
		<i class="fa fa-tags"></i>
		<p><?=lang("menu_tickets");?></p>
	</a>

	<a class="quick-button-small span3" onclick="showDialog.call(this, event, 'add_bonus_dialog', '', '', '');">
		<i class="fa fa-gift"></i>
		<p><?=lang("label_bonus");?></p>
	</a>

	<div class="clear"></div>
</div>