<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification buttons view -->
	<? require_once('notifications.php'); ?>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-list-alt"></i><span class="break"></span><?=lang("title_edit_member");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="member_edit_form" id="member_edit_form">
					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_first_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="edit_fname" name="edit_fname" value="<?=$member_info->first_name;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_last_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="edit_lname" name="edit_lname" value="<?=$member_info->last_name;?>" type="text" />
							</div>
						</div>
					</div>


					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_username");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-tag"></i></span>
								<input class="input-xlarge focused" id="edit_uname" name="edit_uname" value="<?=$member_info->username;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_email");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-envelope"></i></span>
								<input class="input-xlarge focused" id="edit_email" name="edit_email" value="<?=$member_info->email;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_phone");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-phone"></i></span>
								<input class="input-xlarge focused" id="edit_phone" name="edit_phone" value="<?=$member_info->telephone;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="edit_pword" name="edit_pword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_confirm_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="edit_cpword" name="edit_cpword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_group");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-group"></i></span>
								<select id="edit_utype" name="edit_utype">
									<? foreach ($types as $elem) { if ($elem->id == $member_info->type_id) { ?>
										<option value="<?=$elem->id;?>" selected><?=$elem->name;?></option>
									<? } else { ?>
										<option value="<?=$elem->id;?>"><?=$elem->name;?></option>
									<? } } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_company");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-globe"></i></span>
								<input class="input-xlarge focused" id="edit_cname" name="edit_cname" value="<?=$member_info->comp_name;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_url");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-link"></i></span>
								<input class="input-xlarge focused" id="edit_home_page" name="edit_home_page" value="<?=$member_info->homepage;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_country");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-flag"></i></span>
								<select id="edit_country" name="edit_country" class="select select-xlarge">
									<? if (is_array($countries)) { foreach ($countries as $elem) { if ($member_info->id_country == $elem->id) { ?>
 										<option value="<?=$elem->id;?>" selected><?=$elem->country;?></option>
 									<? } else { ?> 
 										<option value="<?=$elem->id;?>"><?=$elem->country;?></option>
 									<? } } } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_city");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-map-marker"></i></span>
								<input class="input-xlarge focused" id="edit_city" name="edit_city" value="<?=$member_info->city;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="developers">
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_hourly_rate");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-clock-o"></i></span>
									<input class="input-small focused" id="edit_hrate" name="edit_hrate" value="<?=$member_info->hourly_rate;?>" type="text" />
									<span class="add-on"><?=lang("label_per_hour");?></span>
								</div>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_active");?></label>
						<div class="controls">
							<label class="switch switch-primary">
								<input type="checkbox" id="status_active" name="status_active" class="switch-input" <?=($member_info->active == "yes" ? "checked" : "");?> />
								<span class="switch-label" data-on="On" data-off="Off"></span>
								<span class="switch-handle"></span>
							</label>
						</div>
					</div>

					<input type="hidden" id="member_id" name="member_id" value="<?=$member_info->user_id;?>" />

					<div class="control-group text-right margin-top40">
						<span class="float-left"><a href="<?=base_url();?>members"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

						<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
						<button type="button" id="save_edit_member" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
						<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>