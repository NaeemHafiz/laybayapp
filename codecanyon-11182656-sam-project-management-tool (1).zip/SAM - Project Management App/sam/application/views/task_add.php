<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

if (($user_type > 2) && ($user_type != 4))
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification messages view -->
	<? require_once('notifications.php'); ?>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_new_task");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="task_add_form" id="task_add_form">
					<fieldset>	
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_title");?></label>
							<div class="controls">
								<input class="input-xlarge focused" id="tname" name="tname" type="text" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label"><?=lang("label_project");?></label>
							<div class="controls">
								<? if ($user_type == 4) { ?>
									<select id="task_projects" class="selectpicker form-control" name="tprojid">
										<option value=""><?=lang('label_select');?></option>
										<? if (is_array($client_project)) { foreach ($client_project as $elem) { ?>
											<option value="<?=$elem->projectid;?>"><?=$elem->name;?></option>
										<? } } ?>
									</select>
								<? } else { ?>
									<select id="task_projects" class="selectpicker form-control" name="tprojid">
										<option value=""><?=lang('label_select');?></option>
										<? if (is_array($projects)) { foreach ($projects as $elem) { ?>
											<option value="<?=$elem->projectid;?>"><?=$elem->name;?></option>
										<? } } ?>
									</select>
								<? } ?>
							</div> 
						</div>

						<div class="control-group">
							<label class="control-label"><?=lang('label_priority');?></label>
							<div class="controls">
								<select id="task_priority">
									<? if (is_array($task_priority)) { foreach ($task_priority as $elem) { ?>
										<option value="<?=$elem->id;?>" <? if ($elem->id == 1) echo "selected";?>><?=$elem->name;?></option>
									<? } } ?>
								</select>
							</div>
						</div>

						<? if ($user_type != 4) { ?>
							<div class="control-group">
								<label class="control-label"><?=$user_types[2]->name;?></label>
								<div class="controls">
									<select id="assigned_to" class="margin-left multiselect" multiple="multiple">
										<? if (is_array($workers)) { foreach ($workers as $elem) { ?>
											<option value="<?=$elem->id;?>"><?=$elem->first_name." ".$elem->last_name;?></option>
										<? } } ?>
									</select>
								</div>
							</div>
						<? } ?>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_desc");?></label>
							<div class="controls">
								<textarea class="common_ckeditor tdesc" id="textarea2" name="tdesc" rows="3"></textarea>
							</div>
						</div>
					</fieldset>
				</form>

				<div class="form-horizontal">
					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_attachment");?></label>
						<div class="controls">
							<form action="<?=base_url();?>tasks/uploadTaskAttachment" id="upload_task_picture_form" class="dropzone span8">
								<div class="fallback">
									<input name="file" type="file" multiple="" />
								</div>
								<input type="hidden" name="task_id" id="task_id" value />
								<input type="hidden" name="from" id="from" value="add" />
							</form>
							<div class="span9" style="margin: -15px 0px 0px 0px;"><?=lang("label_allowed_file_types");?></div>
						</div>
					</div>
				</div>
				
				<div class="control-group text-right margin-top40">
					<span class="float-left"><a href="<?=base_url();?>tasks"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>
					
					<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
					<button type="button" id="save_task" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
					<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>