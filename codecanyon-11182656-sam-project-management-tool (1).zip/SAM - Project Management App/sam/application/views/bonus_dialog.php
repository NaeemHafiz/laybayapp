<div class="modal fade in hide" id="add_bonus_dialog">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
		<h3><?=lang("label_bonus");?></h3>
	</div>

	<div class="modal-body">
		<div class="box-content">
			<div class="span6">
				<div class="control-group">
					<div class="controls">
						<select id="bonus_developer" name="bonus_developer" class="select-large" onchange="getDeveloperProjects.call(this);">
							<option value=""><?=$CI->functions->getUserTypeName(3)->name;?></option>
							<? if (is_array($developers)) foreach ($developers as $elem) { ?>
								<option value="<?=$elem->user_id;?>"><?=$elem->first_name." ".$elem->last_name;?></option>
							<? } ?>
						</select>
					</div>
				</div>
			</div>

			<div class="span6 right_text">
				<div class="control-group">
					<div class="controls">
						<select id="bonus_project" name="bonus_project" class="select-large">
							<option value=""><?=lang('label_project');?></option>
						</select>
					</div>
				</div>
			</div>

			<div class="span12 noMarginLeft">
				<div class="control-group">
					<label class="control-label" for="focusedInput"><?=lang("label_comment");?></label>
					<div class="controls">
						<textarea id="bonus_message" name="bonus_message" class="textarea_popup"></textarea>
					</div>
				</div>
			</div>

			<div class="span12 noMarginLeft">
				<div class="control-group">
					<label class="control-label control-label-popup float-left" for="focusedInput"><?=lang("label_bonus");?></label>
					<div class="controls">
						<div class="input-prepend float-left">
							<span class="add-on"><i class="fa fa-clock-o"></i></span>
							<input class="input-small focused" id="bonus_amount" name="bonus_amount" type="text" value="" onkeydown="check_if_number(event);" palceholder="0" />
						</div>
					</div>
					<label class="control-label-popup">&nbsp;&nbsp;<?=lang("label_hours");?></label>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal-footer">
		<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
		<a href="#" class="btn btn-primary" onclick="addBonus.call(this);"><?=lang("btn_save_changes");?></a>
		<a href="#" class="btn" data-dismiss="modal" id="balance_close_dialog"><?=lang("btn_cancel");?></a>
	</div>
</div>