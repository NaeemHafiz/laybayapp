<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification buttons -->
	<? require_once('notifications.php'); ?>

	<div class="row-fluid">
		<div class="span4">
			<div class="box span12 noMarginLeft">
				<div class="box-header">
					<h2><i class="fa fa-picture-o"></i><?=lang("title_profile_picture");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>

				<div class="box-content">
					<br />
					<div class="control-group text-center">
						<? if ((isset($user_info)) && ($user_info->picture != "")) { ?>
							<img src="<?=base_url();?>uploads/avatars/<?=$user_info->picture;?>" alt="avatar" class="avatar_fixed_height" />
						<? } else { ?>
							<img src="<?=base_url();?>img/no_avatar.png" alt="avatar" />
						<? } ?>
					</div>
					<br />
					
					<form action="<?=base_url();?>profile/uploadAvatar" method="POST" enctype="multipart/form-data" class="text-center">
						<input type="file" class="input-file uniform_on" name="userfile" size="25" />
						<input type="submit" class="btn btn-small btn-primary" value="<?=lang("btn_upload");?>" />
					</form>

					<? $redirect = $CI->input->get('message'); if (isset($redirect)) { ?>
						<div class="server_error return_message_error display_upload_message text-center"><?=$redirect;?></div>
					<? } ?>
				</div>
			</div>

			<div class="box span12 noMarginLeft">
				<div class="box-header">
					<h2><i class="fa fa-cog"></i><?=lang("title_personal_settings");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>

				<div class="box-content">
					<br />
					<form class="form-horizontal" id="edit_profile_email_form">
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_email_notifications");?></label>
							<div class="controls">
								<label class="switch switch-primary">
									<input type="checkbox" class="switch-input" <? if ($user_info->receive_email == 'yes') echo 'checked';?> onclick="if (this.checked) document.getElementById('send_email').value = 'yes'; else document.getElementById('send_email').value = 'no';"/>
									<input type="hidden" id="send_email" name="send_email" value="yes">
									<span class="switch-label" data-on="On" data-off="Off"></span>
									<span class="switch-handle"></span>
								</label>

								<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_receive_email_notifications");?>">
									<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
								</a>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_online_notifications");?></label>
							<div class="controls">
								<label class="switch switch-primary">
									<input type="checkbox" class="switch-input" <? if ($user_info->receive_notifications == 'yes') echo 'checked';?> onclick="if (this.checked) document.getElementById('onsite_notification').value = 'yes'; else document.getElementById('onsite_notification').value = 'no';"/>
									<input type="hidden" id="onsite_notification" name="onsite_notification" value="yes">
									<span class="switch-label" data-on="On" data-off="Off"></span>
									<span class="switch-handle"></span>
								</label>

								<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_receive_online_notifications");?>">
									<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
								</a>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="box span8 noMargin">
			<div class="box-header">
				<h2><i class="fa fa-user"></i><?=lang("title_edit_profile");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="edit_profile_form" id="edit_profile_form">
					<h5><?=lang("subtitle_personal_details");?></h5>
					<div class="tooltip-demo well">
						<fieldset>
							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_first_name");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-user"></i></span>
										<input class="input-xlarge focused" id="fname" name="fname" type="text" value="<?=$user_info->first_name;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_last_name");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-user"></i></span>
										<input class="input-xlarge focused" id="lname" name="lname" type="text" value="<?=$user_info->last_name;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_email");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-envelope"></i></span>
										<input class="input-xlarge focused" id="email" name="email" type="text" value="<?=$user_info->email;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_paypal_email");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-paypal"></i></span>
										<input class="input-xlarge focused" id="paypal_email" name="paypal_email" type="text" value="<?=$user_info->paypal_account;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_phone");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-phone"></i></span>
										<input class="input-xlarge focused" id="phone" name="phone" type="text" value="<?=$user_info->telephone;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_company");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-globe"></i></span>
										<input class="input-xlarge focused" id="comp_name" name="comp_name" type="text" value="<?=$user_info->comp_name;?>" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_url");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-link"></i></span>
										<input class="input-xlarge focused" id="profile_home_page" name="profile_home_page" type="text" value="<?=$user_info->homepage;?>" />
									</div>
								</div>
							</div>


							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_country");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-flag"></i></span>
										<select id="profile_country" name="profile_country" class="select select-xlarge">
											<? if (is_array($countries)) { foreach ($countries as $elem) { if ($user_info->id_country == $elem->id) { ?>
												<option value="<?=$elem->id;?>" selected><?=$elem->country;?></option>
		 									<? } else { ?> 
		 										<option value="<?=$elem->id;?>"><?=$elem->country;?></option>
		 									<? } } } ?>
										</select>
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_city");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-map-marker"></i></span>
										<input class="input-xlarge focused" id="city" name="city" type="text" value="<?=$user_info->city;?>" />
									</div>
								</div>
							</div>

							<? if ($this->config->item("multi_language") == "yes") { ?>
								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_language");?></label>
									<div class="controls">
										<div class="input-prepend">
											<span class="add-on"><i class="fa fa-flag"></i></span>
											<select id="settings_language" name="language" class="select select-xlarge">
												<? if (is_array($languages)) { foreach ($languages as $elem) { ?>
													<option value="<?=$elem->lang_abbreviation;?>" <? if ($this->input->cookie("language") == $elem->lang_abbreviation) { echo "selected"; } ?>><?=$elem->language;?></option>
												<? } } ?>
			 								</select>
										</div>
									</div>
								</div>
							<? } ?>

						</fieldset>
					</div>

					<h5><?=lang("subtitle_change_password");?></h5>
					<div class="tooltip-demo well">
						<fieldset>
							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_current_pass");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-lock"></i></span>
										<input class="input-xlarge focused" id="curr_pw" name="curr_pw" type="password" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_new_pass");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-lock"></i></span>
										<input class="input-xlarge focused" id="new_pw" name="new_pw" type="password" />
									</div>
								</div>
							</div>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_confirm_pass");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on"><i class="fa fa-lock"></i></span>
										<input class="input-xlarge focused" id="conf_pw" name="conf_pw" type="password" />
									</div>
								</div>
							</div>
						</fieldset>
					</div>
				
					<div class="control-group text-right margin-top40">
						<span class="float-left"><a href="<?=base_url();?>dashboard"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>
						<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
						<button type="button" id="save_profile_changes" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
						<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>