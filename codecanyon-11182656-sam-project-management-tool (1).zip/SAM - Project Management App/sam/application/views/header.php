<?
$CI = &get_instance();
$CI->load->library('session');
$CI->load->helper('cookie');
$language = $CI->input->cookie('language');
$user_id = $CI->session->userdata('user_id');
?>

<!DOCTYPE html>
<html lang="<?=$language;?>">
<head>
	<!-- start: Meta -->
	<meta charset="utf-8" />
	<title>SAM - System Apps Management</title>
	<meta name="description" content="SAM is an online app which is designated to manage tasks allocation within a company with the possibility to interact with customer, for projects that are developed for an external use. SAM helps you to have control over your current workload, helps you manage the communication with your customers, gives you a history of your projects and help make a better use of your time. Projects and tasks have the ability to be assigned with specific deadlines (for a project or a task). This way you will always know how to use the time and how to share it between projects, in order to deliver them on time and keep your team and customers updated on each project." />
	<meta name="keyword" content="manager, managment, projects, tasks, clients, tool, stats, responsive, fluid, design, retina" />
	<meta name="author" content="IntelCoder, www.intelcoder.com" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- end: Mobile Specific -->
	
	<!-- start: Favicon -->
	<link rel="shortcut icon" href="<?=base_url();?>img/favicon.ico" />
	<!-- end: Favicon -->

	<!-- start: CSS -->
	<link rel="stylesheet" href="<?=base_url();?>css/styles.css" />

	<link rel="stylesheet" href="<?=base_url();?>css/switch.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/bootstrap.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/bootstrap-responsive.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/style.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/style-responsive.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/retina.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/uniform.default.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/font-awesome.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/jquery-ui-1.10.3.custom.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/bootstrap-multiselect.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/datepicker.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/bootstrap-select.min.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/bootstrap-select.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/jqx.base.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/dropzone.css" />

	<link rel="stylesheet" href="<?=base_url();?>css/prettify.css" />
	<link rel="stylesheet" href="<?=base_url();?>css/chosen.css" />

	<!-- DateSelector -->
	<link rel="stylesheet" href="<?=base_url();?>css/dateselector.css" />

	<!--[if IE 9]>
		<link rel="stylesheet" href="css/ie9.css" id="ie9style" />
	<![endif]-->
	<!-- end: CSS -->

	<!-- start: Includes -->
	<?
	require_once("includes/global_vars.php");
	require_once("includes/languages_js.php");
	?>
	<!-- end: Includes -->

	<!-- start: JavaScript-->
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery-migrate-1.2.1.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery-ui-1.10.3.custom.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.ui.touch-punch.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/modernizr.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.cookie.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/excanvas.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.flot.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.flot.pie.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.flot.stack.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.flot.resize.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.flot.time.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.uniform.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/ckeditor/adapters/jquery.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.imagesloaded.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.masonry.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.knob.modified.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.sparkline.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/counter.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/raphael.2.1.0.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/justgage.1.0.1.min.js"></script>	
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.autosize.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/retina.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.placeholder.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/core.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/charts.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/custom.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/bootstrap-multiselect.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/knockout-2.3.0.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/bootstrap-select.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/bootstrap-select.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/dropzone/dropzone.js"></script>

	<? // If no one is logged in, then do not include these, since no tasks can be retrieved
	if ($user_id != "" && $user_id != NULL && $user_id != 0) { ?>
		<script type="text/javascript" src="<?=base_url();?>js/donut-chart/jqxcore.js"></script>
		<script type="text/javascript" src="<?=base_url();?>js/donut-chart/jqxdata.js"></script>
		<script type="text/javascript" src="<?=base_url();?>js/donut-chart/jqxchart.js"></script>
		<script type="text/javascript" src="<?=base_url();?>js/donut-chart/donut-chart.js"></script>
	<? } ?>

	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.noty.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.elfinder.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.raty.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.iphone.toggle.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.uploadify-3.1.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.gritter.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/jquery.chosen.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/wizard.min.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/prettify.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/bootstrap/fullcalendar.min.js"></script>

	<script type="text/javascript" src="<?=base_url();?>js/login.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/profile.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/project.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/task.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/members.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/clients.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/settings.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/transaction.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/reports.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/tickets.js"></script>
	<script type="text/javascript" src="<?=base_url();?>js/notifications.js"></script>

	<!-- DateSelector -->
	<script type="text/javascript" src="<?=base_url();?>js/dateselector.js"></script>

	<!-- fnReloadAjax function for datatables -->
	<script type="text/javascript" src="<?=base_url();?>js/fnReloadAjax.js"></script>

	<!-- ZeroClipboard -->
	<script type="text/javascript" src="<?=base_url();?>js/zeroclipboard/ZeroClipboard.js"></script>

	<!-- ColorPicker -->
	<script type="text/javascript" src="<?=base_url();?>js/colorpicker/bootstrap-colorpicker.js"></script>
	<link rel="stylesheet" href="<?=base_url();?>js/colorpicker/colorpicker.css" />

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css" id="ie-style" />
	<![endif]-->
	<!-- end: JavaScript-->
</head>