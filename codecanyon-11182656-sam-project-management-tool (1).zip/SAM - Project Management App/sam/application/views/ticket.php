<?
require_once("top.php");

$CI =& get_instance();
$CI->load->helper('url');
$CI->load->library('session');
$CI->load->library('userslib');

$user_id 	= $CI->session->userdata('user_id');
$user_type 	= $CI->session->userdata('user_type');

$user_info 	= $this->userslib->getUserProfile($user_id);

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

if ($CI->config->item('enable_tickets_system') == 'no')
{
	redirect(base_url());
}

// Translate ticket types
if ($tickets->type == "Problem")
{
	$ticket_type = lang('label_type_problem');
}
elseif ($tickets->type == "Question")
{
	$ticket_type = lang('label_type_question');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Return notifications view -->
	<? require_once('notifications.php'); ?>

	<!-- Answer ticket modal dialog box -->
	<div class="modal hide fade in popup_center" id="answer_ticket_dialog">
		<div class="modal-header">
			<button type="button" class="close answer_close" data-dismiss="modal">×</button>
			<h3>Reply on #<?=$tickets->id;?> - <?=$tickets->subject;?></h3>
		</div>

		<div class="modal-body">
			<form id="answer_ticket_form">
				<div class="box-content">
					<div class="span6">
						<input type="hidden" name="ticket_id" value="<?=$tickets->id;?>" />
						<div class="control-group">
							<div class="controls">
								<div class="input-prepend float-left">
									<span class="add-on float-left"><i class="fa fa-user"></i></span>
							  		<input type="text" id="name" name="name" class="input-medium float-left" value="<?=$tickets->added_by;?>" readonly />
								</div>
							</div>
						</div>
					</div>

					<div class="span6">
						<div class="control-group">
							<div class="controls">
								<div class="input-prepend float-right">
									<span class="add-on float-left"><i class="fa fa-reply"></i></span>
							  		<input type="text" id="subject" name="subject" class="input-medium float-left" value="Reply on #<?=$tickets->id;?> - <?=$tickets->subject;?>" readonly />
								</div>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="message"><?=lang("label_message");?></label>
						<div class="controls">
							<textarea id="answer_message" name="message" class="popup_ckeditor">
								<p>&nbsp;</p>
								<?=$user_info->first_name." ".$user_info->last_name;?><br />
								----------<br />
								<?=$CI->config->item('company');?><br />
								<?=strlen($user_info->telephone) > 0 ? $user_info->telephone.'<br />' : "";?>
								<?=$user_info->email;?>
							</textarea>
						</div>
					</div>
				</div>
			</form>
		</div>

		<div class="modal-footer">
			<div class="answer_loader hide margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
			<a href="#" class="btn btn-primary" onclick="answerTicket.call(this, event);"><?=lang("btn_send_message");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		</div>
	</div>

	<!-- Change ticket status to closed modal dialog box -->
	<div class="modal fade in hide" id="close_ticket_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>

		<div class="modal-body">
			<form id="close_ticket_form">
				<div class="control-group">
					<label class="control-label" for="message"><?=lang("label_message");?></label>
					<div class="controls">
						<textarea id="close_message" name="message" class="popup_ckeditor"></textarea>
					</div>
				</div>

				<input type="hidden" id="ticket_id" name="ticket_id" />
			</form>
		</div>

		<div class="modal-footer center_text">
			<div class="close_loader hide margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
			<a href="#" class="btn btn-primary" onclick="closeTicket.call(this, event);"><?=lang("btn_close");?></a>
			<a href="#" class="btn close_ticket_dialog" data-dismiss="modal"><?=lang("btn_cancel");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_ticket");?> <?=$tickets->subject;?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<div class="row-fluid">
					<div class="span6">
						<h5><?=lang("label_added_by");?></h5>
						<div class="tooltip-demo well">
							<div class="row-fluid">
								<div class="span12">
									<p><b><?=lang("label_view_name");?></b> <?=$tickets->added_by;?></p>
									<p><b><?=lang("label_view_email");?></b> <?=$tickets->email;?></p>
									<p><b><?=lang("label_view_phone");?></b> <?=$tickets->phone;?></p>
								</div>
							</div>
						</div>
					</div>

					<div class="span6">
						<h5><?=lang("label_details");?></h5>
						<div class="tooltip-demo well">
							<div class="row-fluid">
								<div class="span12">
									<p><b><?=lang("label_view_added");?></b> <?=$tickets->added_on;?></p>
									<p><b><?=lang("label_view_type");?></b> <?=$ticket_type;?></p>
									<p><b><?=lang("label_view_app_url");?></b> <a href="http://<?=$tickets->domain;?>" target="_blank"><?=$tickets->domain;?></a></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="row-fluid">
					<div class="span12">
						<h5><?=lang("label_desc");?></h5>
						<div class="tooltip-demo well"><?=$tickets->message;?></div>
					</div>
				</div>

				<? if (is_object($respondent_info)) { ?>
					<div class="row-fluid">
						<div class="span12">
							<h5><?=lang("label_answered_by");?> <?=$respondent_info->first_name." ".$respondent_info->last_name;?></h5>
							<div class="tooltip-demo well"><?=$tickets->answer;?></div>
						</div>
					</div>
				<? } ?>

				<? if (is_object($closer_info)) { ?>
					<div class="row-fluid">
						<div class="span12">
							<h5><?=lang("label_closed_by");?> <?=$closer_info->first_name." ".$closer_info->last_name;?></h5>
							<div class="tooltip-demo well"><?=$tickets->close_message;?></div>
						</div>
					</div>
				<? } ?>

				<div class="control-group text-right margin-top40">
					<span class="float-left"><a href="<?=base_url();?>tickets"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>
					<? if ($tickets->status_id != 3) { ?>
						<span class="float-right"><a href="#"><button type="button" class="btn btn-warning" onclick="showDialog.call(this, event, 'close_ticket_dialog', <?=$tickets->id;?>, 'ticket_id', '#<?=$tickets->id;?> - <?=$tickets->subject;?>');"><?=lang("btn_close");?></button></a></span>
						<? if (!is_object($respondent_info)) { ?>
							<span class="float-right margin-right5"><a href="#"><button type="button" class="btn btn-primary" onclick="showDialog(event, 'answer_ticket_dialog', '', '', '');"><?=lang("btn_answer");?></button></a></span>
					<? } } ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>