<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

// Include library to get all developers for a single tasks when displaying them
$CI->load->library('taskslib');
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Dialog box to delete task --> 
	<div class="modal fade in hide" id="delete_task_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_task_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_delete_task");?></h2>
					</div>
				</div>
				<input type="hidden" id="task_id" name="task_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="delete_task.call(this, event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>

	<? if ($user_type <= 2) { ?>
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_managed_tasks");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
				<? if ($user_type != 3) { ?><a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>tasks/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_task");?></a><? } ?>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="completed_task_form" id="completed_tas_form">
					<div id="DataTables_Table_2_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered" id="managed-tasks-table" aria-describedby="DataTables_Table_2_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_task");?></th>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_added");?></th>
										<th><?=$user_types[2]->name;?></th>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>   
						  
					  			<tbody></tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<? } ?>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_in_progress_tasks");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
				<? if ($user_type != 3) { ?><a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>tasks/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_task");?></a><? } ?>
			</div>
			<div class="box-content">
				<form class="form-horizontal" name="in_progress_task_form" id="in_progress_task_form">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable show_5" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_task");?></th>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_added");?></th>
										<th><?=lang("thead_due_date");?></th>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>   
						  
					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? $odd_even = 0; if (is_array($tasks_latest)) foreach ($tasks_latest as $elem) { ?>
						  			<tr class="<?php if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center">
											<? if (strtolower($elem->priority) == 'urgent' ) { ?>
												<i class="fa fa-exclamation-triangle red" title="<?=lang("tooltip_urgent");?>"></i>
											<? } else if (strtolower($elem->priority) == 'high') { ?>
												<i class="fa fa-exclamation-triangle lightOrange" title="<?=lang("tooltip_high");?>"></i>
											<? } ?>
											<?=$elem->name;?>
										</td>
										<td class="center"><?=$elem->pname;?></td>
										<td class="center"><?=date("Y-m-d", strtotime($elem->create_date));?></td>
										<td class="center"><? if ($elem->due_date == "0000-00-00") echo lang("status_not_set"); else echo $elem->due_date; ?></td>
										<td class="center">
											<? switch ($elem->status) {
												case 'Not Assigned':
													echo "<span class='label'>".lang("status_not_assigned")."</span>";
													break;
												case 'Assigned':
													echo "<span class='label label-warning'>".lang("status_assigned")."</span>";
													break;
												case 'In Progress':
													echo "<span class='label label-info'>".lang("status_in_progress")."</span>";
													break;
												case 'Completed':
													echo "<span class='label label-success'>".lang("status_completed")."</span>";
													break;
												default:
													break;
											} ?>
										</td>
										<td class="center">
											<a class="btn btn-success" href="<?=base_url();?>tasks/view/<?=$elem->id;?>" title="<?=lang("btn_view");?>">
												<i class="fa fa-eye"></i>                                            
											</a>
											<? if ($user_type <= 2) { ?>
												<a class="btn btn-info" href="<?=base_url();?>tasks/edit/<?=$elem->id;?>" title="<?=lang("btn_edit");?>">
													<i class="fa fa-pencil"></i>                                            
												</a>
											<? } if ($user_type <= 2) { ?>
												<a class="btn btn-danger" href="#" onclick="showDialog.call(this, event, 'delete_task_dialog', <?=$elem->id;?>, 'task_id', '<?=$elem->name;?>');" title="<?=lang("btn_delete");?>">
													<i class="fa fa-trash-o"></i> 
												</a>
											<? } ?>
										</td>
										<input type="hidden" value="<?=$elem->id;?>" />
									</tr>
									<? $odd_even++;	} ?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_completed_tasks");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-down"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content hide">
				<form class="form-horizontal" name="completed_task_form" id="completed_tas_form">
					<div id="DataTables_Table_1_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable show_5" id="DataTables_Table_1" aria-describedby="DataTables_Table_1_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_task");?></th>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_added");?></th>
										<th><?=lang("thead_due_date");?></th>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>   
						  
					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? $odd_even = 0; if (is_array($tasks_all)) foreach ($tasks_all as $elem) { ?>
						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center">
											<? if (strtolower($elem->priority) == 'urgent' ) { ?>
												<i class="fa fa-exclamation-triangle red" title="<?=lang("tooltip_urgent");?>"></i>
											<? } else if (strtolower($elem->priority) == 'high') { ?>
												<i class="fa fa-exclamation-triangle lightOrange" title="<?=lang("tooltip_high");?>"></i>
											<? } ?>
											<?=$elem->name;?>
										</td>
										<td class="center"><?=$elem->pname;?></td>
										<td class="center"><?=date("Y-m-d", strtotime($elem->create_date));?></td>
										<td class="center"><? if ($elem->due_date == "0000-00-00") echo lang("status_not_set"); else echo $elem->due_date; ?></td>
										<td class="center">
											<? switch ($elem->status) {
												case 'Not Assigned':
													echo "<span class='label'>".lang("status_not_assigned")."</span>";
													break;
												case 'Assigned':
													echo "<span class='label label-warning'>".lang("status_assigned")."</span>";
													break;
												case 'In Progress':
													echo "<span class='label label-info'>".lang("status_in_progress")."</span>";
													break;
												case 'Completed':
													echo "<span class='label label-success'>".lang("status_completed")."</span>";
													break;
												default:
													break;
											} ?>
										</td>
										<td class="center">
											<a class="btn btn-success" href="<?=base_url();?>tasks/view/<?=$elem->id;?>" title="<?=lang("btn_view");?>">
												<i class="fa fa-eye"></i>                                            
											</a>
											<? if ($user_type <= 2) { ?>
												<a class="btn btn-info" href="<?=base_url();?>tasks/edit/<?=$elem->id;?>" title="<?=lang("btn_edit");?>">
													<i class="fa fa-pencil"></i>                                            
												</a>
											<? } if ($user_type <= 2) { ?>
												<a class="btn btn-danger" href="#" onclick="showDialog.call(this, event, 'delete_task_dialog', <?=$elem->id;?>, 'task_id', '<?=$elem->name;?>');" title="<?=lang("btn_delete");?>">
													<i class="fa fa-trash-o"></i> 
												</a>
											<? } ?>
										</td>
										<input type="hidden" value="<?=$elem->id;?>" />
									</tr>
								<? $odd_even++;	} ?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>