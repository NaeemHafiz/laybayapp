<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification buttons -->
	<? require_once('notifications.php'); ?>

	<div class="row-fluid">
		<div class="box span8" onTablet="span6" onDesktop="span8">
			<div class="box-header">
				<h2><i class="fa fa-group"></i><span class="break"></span><?=lang("title_new_client");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="client_add_form" id="client_add_form">
					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_first_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="client_fname" name="client_fname" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_last_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="client_lname" name="client_lname" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_username");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-tag"></i></span>
								<input class="input-xlarge focused" id="client_uname" name="client_uname" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_email");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-envelope"></i></span>
								<input class="input-xlarge focused" id="client_email" name="client_email" onclick="validateEmail.call(this);" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_phone");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-phone"></i></span>
								<input class="input-xlarge focused" id="client_phone" name="client_phone" onkeydown="check_if_number(event);" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="client_pword" name="client_pword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_confirm_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="client_cpword" name="client_cpword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_company");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-globe"></i></span>
								<input class="input-xlarge focused" id="client_cname" name="client_cname" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_url");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-link"></i></span>
								<input class="input-xlarge focused" id="home_page" name="home_page" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_country");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-flag"></i></span>
								<select id ="client_country" name="client_country" class="select select-xlarge">
									<? if (is_array($countries)) { foreach ($countries as $elem) { ?>
										<option value="<?=$elem->id;?>"><?=$elem->country;?></option>
									<? } } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_city");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-map-marker"></i></span>
								<input class="input-xlarge focused" id="client_city" name="client_city" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_send_email");?></label>
						<div class="controls">
							<label class="switch switch-primary">
								<input type="checkbox" id="client_send_email" name="client_send_email" class="switch-input" checked />
								<span class="switch-label" data-on="On" data-off="Off"></span>
								<span class="switch-handle"></span>
							</label>
						</div>
					</div>

					<div class="control-group text-right margin-top40">
						<span class="float-left"><a href="<?=base_url();?>clients"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

						<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
						<button type="button" id="save_client" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
						<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
					</div>
				</form>
			</div>
		</div>

		<div class="box span4" onTablet="span6" onDesktop="span4">
			<div class="box-header">
				<h2><i class="fa fa-user"></i><?=lang("title_last_clients");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="box-content">
				<ul class="dashboard-list">
					<? if (is_array($last_clients)) { foreach ($last_clients as $elem) { ?>
						<li>
							<? if ($elem->picture != "") { ?>
								<a href="<?=base_url();?>clients/edit/<?=$elem->user_id;?>"><img class="avatar" src="<?=base_url();?>uploads/avatars/<?=$elem->picture;?>" alt="avatar" /></a>
							<? } else { ?>
								<a href="<?=base_url();?>clients/edit/<?=$elem->user_id;?>"><img class="avatar" src="<?=base_url();?>img/no_avatar.png" alt="avatar" /></a>
							<? } ?>
							<b><?=lang("label_view_name");?></b> <a href="<?=base_url();?>clients/edit/<?=$elem->user_id;?>"><?=$elem->first_name." ".$elem->last_name;?></a><br />
							<b><?=lang("label_view_company");?></b> <?=$elem->comp_name;?><br />
							<b><?=lang("label_view_since");?></b> <?=$elem->create_date;?>
						</li>
					<? } } else { ?>
						<div class="text-center"><?=lang("status_none");?></div>
					<? } ?>
				</ul>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>