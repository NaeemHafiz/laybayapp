<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('functions');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}
?>
						
<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification messages -->
	<? require_once("notifications.php"); ?>
	
	<!-- Bonus dialog -->
	<? require_once("todo_dialog.php"); ?>

	<!-- Bonus dialog -->
	<? require_once("bonus_dialog.php"); ?>

	<!-- Dashboard for Client -->
	<? if ($user_type == 4) { ?>
		<div class="row-fluid">
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-list-alt blue"></i>
				<span class="title"><?=lang("db_smallstat_title_projects");?></span>
				<span class="value"><?=$client_projects_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-tasks lightBlue"></i>
				<span class="title"><?=lang("db_smallstat_title_in_progress");?></span>
				<span class="value"><?=$client_in_progress_tasks_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-tasks darkGreen"></i>
				<span class="title"><?=lang("db_smallstat_title_completed");?></span>
				<span class="value"><?=$client_completed_tasks_no;?></span>
			</div>
		</div>

		<div class="row-fluid">
			<div class="box blue span7 visible" ontablet="span6" ondesktop="span7">
				<div class="box-header">
					<h2><i class="fa fa-bar-chart-o"></i><?=lang("title_monthly_completed_tasks");?> <?=date("Y");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>

				<div class="box-content">
					<div class="main-chart">
						<? for ($i = 1; $i < 13; $i++) { ?>
							<div class="bar simple">
								<div class="title"><? echo strftime("%b", mktime(0, 0, 0, $i, 1)); ?></div>
								<div class="value" title="<? if ($task_info[$i] != 0) echo count($task_info[$i]).' '; else echo '0 '; ?>tasks" data-containter="body" data-rel="tooltip"><? if ($task_info[$i] != 0) echo (count($task_info[$i])*100/$max); else echo "0"; ?>%</div>
							</div>
						<? } ?>
					</div>
				</div>
			</div>

			<div class="box span5" ontablet="span6" ondesktop="span5">
				<div class="box-header" data-original-title="">
					<h2><i class="fa fa-bar-chart-o"></i><span class="break"></span><?=lang("title_all_tasks");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>

				<div class="box-content">
					 <div id="jqxChart" style="height: 300px;"></div>
				</div>
			</div>
		</div>
	<? } ?>

	<!-- Dashboard for Developer -->
	<? if ($user_type == 3) { ?>
		<div class="row-fluid">
			<div class="span3 smallstat box mobileHalf" ontablet="span6" ondesktop="span3">
				<i class="fa fa-list-alt blue"></i>
				<span class="title"><?=lang("db_smallstat_title_projects");?></span>
				<span class="value"><?=$developer_projects_no;?></span>
			</div>
			
			<div class="span3 smallstat box mobileHalf" ontablet="span6" ondesktop="span3">
				<i class="fa fa-tasks lightOrange"></i>
				<span class="title"><?=lang("db_smallstat_title_assigned_tasks");?></span>
				<span class="value"><?=$developer_assigned_tasks_no;?></span>
			</div>
			
			<div class="span3 smallstat box mobileHalf" ontablet="span6" ondesktop="span3">
				<i class="fa fa-tasks lightBlue"></i>
				<span class="title"><?=lang("db_smallstat_title_in_progress");?></span>
				<span class="value"><?=$developer_progress_tasks_no;?></span>
			</div>

			<div class="span3 smallstat box mobileHalf" ontablet="span6" ondesktop="span3">
				<i class="fa fa-money grey"></i>
				<span class="title"><?=lang("db_smallstat_title_balance");?></span>
				<span class="value"><?=$profile_info->balance;?></span>
			</div>
		</div>

		<div class="row-fluid">
			<div class="box span7 noMargin" ontablet="span12" ondesktop="span7">
				<div class="box-header">
					<h2><i class="fa fa-bar-chart-o"></i><?=lang("title_tasks_per_project");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>
				<div class="box-content">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable dataTable init_datatable_only_pagination" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_assigned");?></th>
										<th><?=lang("thead_in_progress");?></th>
										<th><?=lang("thead_completed");?></th>
									</tr>
								</thead>

					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? $odd_even = 0; if (is_array($developer_tasks_by_project)) { $i=0; foreach ($developer_tasks_by_project as $elem) { ?>
						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center"><?=$elem->project_name;?></td>
										<td class="center"><?=$elem->assigned;?></td>
										<td class="center"><?=$elem->in_progress;?></td>
										<td class="center"><?=$elem->completed;?></td>
									</tr>
								<? $odd_even++;	} } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

			<!-- To-Do window -->
			<div class="box span5 noMargin" ontablet="span12" ondesktop="span5">
				<? require_once("todo.php"); ?>
			</div>
		</div>
	<? } ?>

	<!-- Dashboard for PM -->
	<? if ($user_type == 2) { ?>
		<div class="row-fluid">
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-list-alt blue"></i>
				<span class="title"><?=lang("db_smallstat_title_projects");?></span>
				<span class="value"><?=$project_manager_projects_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-tasks darkGreen"></i>
				<span class="title"><?=lang("db_smallstat_title_tasks");?></span>
				<span class="value"><?=$project_manager_tasks_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-user red"></i>
				<span class="title"><?=lang("db_smallstat_title_clients");?></span>
				<span class="value"><?=$project_manager_clients;?></span>
			</div>
		</div>

		<div class="row-fluid">
			<div class="box span7 noMargin" ontablet="span6" ondesktop="span7">
				<div class="box-header">
					<h2><i class="fa fa-bar-chart-o"></i><?=lang("title_tasks_per_project");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>
				<div class="box-content">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable dataTable init_datatable_only_pagination" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_not_assigned");?></th>
										<th><?=lang("thead_assigned");?></th>
										<th><?=lang("thead_in_progress");?></th>
										<th><?=lang("thead_completed");?></th>
									</tr>
								</thead>
								<tbody>
								<? if (is_array($pm_tasks_by_project)) { for ($i = 0; $i < count($pm_tasks_by_project); $i++) { ?>
									<tr>
										<td><?=$pm_tasks_by_project[$i]['project_name'];?></td>
										<td><?=$pm_tasks_by_project[$i]['not_assigned'];?></td>
										<td><?=$pm_tasks_by_project[$i]['assigned'];?></td>
										<td><?=$pm_tasks_by_project[$i]['in_progress'];?></td>
										<td><?=$pm_tasks_by_project[$i]['completed'];?></td>
									</tr>
								<? } } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>	
			</div>

			<!-- Bonus window -->
			<div class="box span5 noMargin" ontablet="span6" ondesktop="span5">
				<? require_once("shortcuts.php"); ?>
			</div>

			<!-- To-Do window -->
			<div class="box span5 noMargin" ontablet="span6" ondesktop="span5">
				<? require_once("todo.php"); ?>
			</div>
		</div>
	<? } ?>

	<!-- Dashboard for Administrator -->
	<? if ($user_type == 1) { ?>
		<div class="row-fluid">
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-list-alt blue"></i>
				<span class="title"><?=lang("db_smallstat_title_projects");?></span>
				<span class="value"><?=$admin_projects_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-tasks darkGreen"></i>
				<span class="title"><?=lang("db_smallstat_title_tasks");?></span>
				<span class="value"><?=$admin_tasks_no;?></span>
			</div>
			
			<div class="span4 smallstat box mobileHalf" ontablet="span6" ondesktop="span4">
				<i class="fa fa-user red"></i>
				<span class="title"><?=lang("db_smallstat_title_clients");?></span>
				<span class="value"><?=$admin_clients_no;?></span>
			</div>
		</div>

		<div class="row-fluid">
			<div class="box span7 noMargin" ontablet="span6" ondesktop="span7">
				<div class="box-header">
					<h2><i class="fa fa-bar-chart-o"></i><?=lang("title_tasks_per_project");?></h2>
					<div class="box-icon">
						<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>
				<div class="box-content">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable dataTable init_datatable_only_pagination" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_not_assigned");?></th>
										<th><?=lang("thead_assigned");?></th>
										<th><?=lang("thead_in_progress");?></th>
										<th><?=lang("thead_completed");?></th>
									</tr>
								</thead>
								<tbody>
								<? if (is_array($admin_tasks_by_project)) { for ($i = 0; $i < count($admin_tasks_by_project); $i++) { ?>
									<tr>
										<td><?=$admin_tasks_by_project[$i]['project_name'];?></td>
										<td><?=$admin_tasks_by_project[$i]['not_assigned'];?></td>
										<td><?=$admin_tasks_by_project[$i]['assigned'];?></td>
										<td><?=$admin_tasks_by_project[$i]['in_progress'];?></td>
										<td><?=$admin_tasks_by_project[$i]['completed'];?></td>
									</tr>
								<? } } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>	
			</div>

			<!-- Bonus window -->
			<div class="box span5 noMargin" ontablet="span6" ondesktop="span5">
				<? require_once("shortcuts.php"); ?>
			</div>

			<!-- To-Do window -->
			<div class="box span5 noMargin" ontablet="span12" ondesktop="span5">
				<? require_once("todo.php"); ?>
			</div>
		</div>
	<? } ?>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>