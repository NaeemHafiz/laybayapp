<?
$CI = & get_instance();
$CI->load->library('functions');
?>
<div class="box-header">
	<h2><i class="fa fa-check"></i><?=lang("title_todo_list");?></h2>
	<div class="box-icon">
		<a href="#" onclick="showDialog.call(this, event, 'add_todo_all', '', '', '');"><i class="fa fa-plus-square"></i></a>
		<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
		<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	</div>
</div>

<div class="box-content">
	<div class="todo">
		<ul class="todo-list ui-sortable" id="todo_list_ul">
			<? if (is_array($todo_list)) foreach($todo_list as $elem) { ?>
				<li>
					<span class="todo-actions">
						<a onclick="showDialog.call(this, event, 'delete_todo_dialog', <?=$elem->id;?>, 'todo_id', '');"><i class="fa fa-times"></i></a>
						<input type="hidden" class="current_todo_id" value="<?=$elem->id;?>" />
					</span>
					<span class="desc"><?=$elem->task;?></span> 
					<span class="label label-important"><?=$CI->functions->dateFormat($elem->due_date);?></span>
				</li>
			<? } else { ?>
				<li id="no_todos" class="text-center padding_left10"><?=lang("status_no_data_available");?></li>
			<? } ?>
		</ul>
	</div>
</div>