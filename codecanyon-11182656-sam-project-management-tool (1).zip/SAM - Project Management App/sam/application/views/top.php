<?
require_once("header.php");

$CI = & get_instance();
$CI->load->helper('url');
$CI->load->library('session');
$CI->load->library('userslib');
$CI->load->library('notificationslib');
$user_id = $CI->session->userdata('user_id');
$type = $CI->session->userdata('user_type');

// Notification functions
$notifications 	= $CI->notificationslib->getUserNotifications($user_id, 'yes');

if (isset($user_id) && $user_id != "")
{
	$user_data = $CI->userslib->getUserProfile($user_id);
}
else
{
	redirect(base_url().'login');
}
?>

<body>
	<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="fa fa-bars"></span>
				</a>
				<a id="main-menu-toggle" class="hidden-phone open"><i class="fa fa-bars"></i></a>		
				<div class="row-fluid">
					<a href="<?=base_url();?>" class="brand span2"><span><?=$this->config->item("company");?></span></a>
				</div>		
				<!-- start: Header Menu -->
				<div class="nav-no-collapse header-nav">
					<ul class="nav pull-right">
						<!-- start: Notifications Dropdown -->
						<li class="dropdown hidden-phone">
							<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-bell "></i>
								<? if (is_array($notifications) && count($notifications) > 0) { ?>
									<span class="notification_small small notification red"><?=count($notifications);?></span>
								<? } ?>
							</a>
							<ul class="dropdown-menu notifications">
								<? if (is_array($notifications) && count($notifications) > 0) { $count_notifications = count($notifications); ?> 
									<li class="dropdown-menu-title">
	 									<span><?=lang("last_notifications");?></span>
									</li>
									<? 
									foreach ($notifications as $key => $value) 
									{ 
										if ($key < 10) 
										{

											// Generating the link
											$link 	= base_url();
											$image 	= $color 	= "";

											switch ($value->type_id) 
											{
												// New project added
												case 1:
													$link 	.= "projects/view/";
													$image 	.= "<i class='fa fa-list-alt'></i>";
													$color  = "blue";
													break;

												// New task added
												case 2:
													$link 	.= "tasks/view/";
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "darkGreen";
													break;

												// Task assigned
												case 4:
													$link 	.= "tasks/view/";
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";
													break;

												// Task Quoted
												case 5:
													$link 	.= "tasks/view/";
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";
													break;

												// Task Completed
												case 6:
													$link 	.= "tasks/view/";
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";
													break;

												// New comment added
												case 3:
													$link 	.= "tasks/view/";
													$image 	.= "<i class='fa fa-comment'></i>";
													$color  = "orange";
													break;

												// New Support Ticket
												case 7:
													$link 	.= "tickets/view/";
													$image 	.= "<i class='fa fa-support'></i>";
													$color  = "pink";
													break;

												default:
													break;
											} ?>
		                            	<li>
		                                    <a href="<?=$link.$value->object_id;?>" onclick="readNotification(<?=$user_id;?>, <?=$value->id;?>);">
												<span class="icon <?=$color;?>"><?=$image;?></span>
												<span class="message"><?=$value->title;?></span>
												<span class="time"><?=$CI->notificationslib->timing(strtotime($value->added));?></span> 
											</a>
										</li>
	                            <? } } } else { ?>
		                            <li class="dropdown-menu-title">
	 									<span><?=lang("no_notifications");?></span>
									</li>
	                            	<li class="text-center">
	                            		<a href="#">
											<span class="message"><?=lang('status_no_data_available');?></span>
										</a>
	                                </li>
	                            <? } ?>
                                <li class="dropdown-menu-sub-footer">
                            		<span class="float-left dropdown-menu-sub-footer-link"><a href="<?=base_url();?>notifications/all"><?=lang("view_all_notifications");?></a></span>
                            		<span class="float-right blue dropdown-menu-sub-footer-icon" onclick="readNotification(<?=$user_id;?>, '');"><i class="fa fa-eraser" title="<?=lang('btn_mark_as_read');?>"></i></span>
                            		<div class="clear"></div>
								</li>	
							</ul>
						</li>
						<!-- end: Notifications Dropdown -->

						<!-- start: User Dropdown -->
						<li class="dropdown">
							<a class="btn account dropdown-toggle" data-toggle="dropdown" href="#">
								<? if ($user_data->picture != "") { ?>
									<div class="avatar"><img src="<?=base_url();?>uploads/avatars/<?=$user_data->picture;?>" alt="Avatar" /></div>
								<? } else {  ?>
									<div class="avatar"><img src="<?=base_url();?>img/no_avatar.png" alt="Avatar" /></div>
								<? } ?>
								<div class="user">
									<span class="hello"><?=lang("top_welcome");?></span>
									<span class="name"><?=$user_data->first_name;?></span>
								</div>
							</a>
							<ul class="dropdown-menu">
								<li class="dropdown-menu-title"></li>
								<li><a href="<?=base_url();?>profile"><i class="fa fa-user"></i> <?=lang("top_profile");?></a></li>
								<? if ($type <= 3) { ?>
									<li><a href="<?=base_url();?>transactions"><i class="fa fa-exchange"></i> <?=lang("top_transactions");?></a></li>
								<? } ?>
								<li><a href="<?=base_url();?>login/doLogout"><i class="fa fa-power-off"></i> <?=lang("top_logout");?></a></li>
							</ul>
						</li>
						<!-- end: User Dropdown -->
					</ul>
				</div>
				<!-- end: Header Menu -->
				
			</div>
		</div>
	</div>
	<!-- start: Header -->
	
		<div class="container-fluid-full">
		<div class="row-fluid">
				
			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="row-fluid actions">
					<!-- <input type="text" class="search span12" placeholder="..." /> -->
				</div>	
				
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li><a href="<?=base_url();?>dashboard"><i class="fa fa-dashboard"></i><span class="hidden-tablet"> <?=lang("menu_dashboard");?></span></a></li>	

						<li><a href="<?=base_url();?>projects"><i class="fa fa-list-alt"></i><span class="hidden-tablet"> <?=lang("menu_projects");?></span></a></li>
						
						<li><a href="<?=base_url();?>tasks"><i class="fa fa-tasks"></i><span class="hidden-tablet"> <?=lang("menu_tasks");?></span></a></li>

						<? if ($type == 1) { ?>
							<li><a href="<?=base_url();?>clients"><i class="fa fa-user"></i><span class="hidden-tablet"> <?=lang("menu_clients");?></span></a></li>

							<li><a href="<?=base_url();?>members"><i class="fa fa-group"></i><span class="hidden-tablet"> <?=lang("menu_members");?></span></a></li>

						<? } if ($type <= 2) { ?>
							<li><a href="<?=base_url();?>reports"><i class="fa fa-bar-chart-o"></i><span class="hidden-tablet"> <?=lang("menu_reports");?></span></a></li>
							<? if ($CI->config->item("enable_tickets_system") == "yes") { ?>
								<li>
									<a class="dropmenu" href="#"><i class="fa fa-support"></i><span class="hidden-tablet"> <?=lang("menu_support_tickets");?></span> <span class="label">2</span></a>
									<ul>
										<li><a href="<?=base_url();?>tickets"><i class="fa fa-tags"></i><span class="hidden-tablet"> <?=lang("menu_tickets");?></span></a></li>
										<li><a href="<?=base_url();?>tickets/settings"><i class="fa fa-gear"></i><span class="hidden-tablet"> <?=lang("menu_tickets_settings");?></span></a></li>
									</ul>
								</li>
							<? } ?>

						<? } if ($type == 1) { ?>
							<li><a href="<?=base_url();?>log"><i class="fa fa-clipboard"></i><span class="hidden-tablet"> <?=lang("menu_log");?></span></a></li>

							<li><a href="<?=base_url();?>settings"><i class="fa fa-cogs"></i><span class="hidden-tablet"> <?=lang("menu_settings");?></span></a></li>
						<? } ?>
						
						<li><hr class="topline hide_on_mobile" /></li>
						<li class="text-center hide_on_mobile"><a href="<?=base_url();?>"><img src="<?=base_url();?>img/logo.png" width="80" height="80" alt="logo" /></a></li>
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->