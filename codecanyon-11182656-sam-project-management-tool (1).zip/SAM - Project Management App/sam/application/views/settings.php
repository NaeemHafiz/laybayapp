<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'login');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-cogs"></i><?=lang("title_settings");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<ul class="nav tab-menu nav-tabs margin-right65" id="myTab">
					<li><a href="#groups"><?=lang("title_groups");?></a></li>
					<li><a href="#general"><?=lang("title_general");?></a></li>
				</ul>
				 
				<div id="myTabContent" class="tab-content">
					<!-- Notification buttons view -->
					<? require_once('notifications.php'); ?>

					<!-- General Tab -->
					<div class="tab-pane" id="general">
						<div class="box-content">
							<form class="form-horizontal" name="settings_edit_form" id="settings_edit_form">
								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_company");?></label>
									<div class="controls">
										<div class="input-prepend input-append">
											<span class="add-on"><i class="fa fa-globe"></i></span>
											<input class="input-xlarge focused" id="company" name="company" type="text" value="<?=$CI->config->item('company');?>" />
											<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_name_of_your_company");?>">
												<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
											</a>
										</div>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_contact_email");?></label>
									<div class="controls">
										<div class="input-prepend input-append">
											<span class="add-on"><i class="fa fa-envelope"></i></span>
											<input class="input-xlarge focused" id="contact_email" name="contact_email" type="text" value="<?=$CI->config->item('contact_email');?>" />
											<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_contact_email");?>">
												<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
											</a>
										</div>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_accounting_email");?></label>
									<div class="controls">
										<div class="input-prepend input-append">
											<span class="add-on"><i class="fa fa-envelope"></i></span>
											<input class="input-xlarge focused" id="accounting_email" name="accounting_email" type="text" value="<?=$CI->config->item('accounting_email');?>" />
											<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_accounting_email");?>">
												<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
											</a>
										</div>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_sender_name");?></label>
									<div class="controls">
										<div class="input-prepend input-append">
											<span class="add-on"><i class="fa fa-user"></i></span>
											<input class="input-xlarge focused" id="sender_name" name="sender_name" type="text" value="<?=$CI->config->item('sender_name');?>" />
											<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_name_for_sending_emails");?>">
												<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
											</a>
										</div>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_sender_email");?></label>
									<div class="controls">
										<div class="input-prepend input-append">
											<span class="add-on"><i class="fa fa-envelope"></i></span>
											<input class="input-xlarge focused" id="sender_email" name="sender_email" onblur="validateEmail.call(this);" type="text" value="<?=$CI->config->item('sender_email');?>" />
											<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_email_for_sending_emails");?>">
												<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
											</a>
										</div>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_enable_emails");?></label>
									<div class="controls">
										<label class="switch switch-primary">
											<? if (($CI->config->item('send_emails') == "yes") || ($CI->config->item('send_emails') == "")) { ?>
												<input type="checkbox" id="send_emails" name="send_emails" class="switch-input" checked />
											<? } if ($CI->config->item('send_emails') == "no") { ?>
												<input type="checkbox" id="send_emails" name="send_emails" class="switch-input" />
											<? } ?>
											<span class="switch-label" data-on="On" data-off="Off"></span>
											<span class="switch-handle"></span>
										</label>

										<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_enable_sending_emails");?>">
											<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
										</a>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_multi_language");?></label>
									<div class="controls">
										<label class="switch switch-primary">
											<? if (($CI->config->item('multi_language') == "yes") || ($CI->config->item('multi_language') == "")) { ?>
												<input type="checkbox" id="multi_language" name="multi_language" class="switch-input" checked />
											<? } if ($CI->config->item('multi_language') == "no") { ?>
												<input type="checkbox" id="multi_language" name="multi_language" class="switch-input" />
											<? } ?>
											<span class="switch-label" data-on="On" data-off="Off"></span>
											<span class="switch-handle"></span>
										</label>

										<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_enable_multi_language");?>">
											<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
										</a>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_enable_tickets");?></label>
									<div class="controls">
										<label class="switch switch-primary">
											<? if (($CI->config->item('enable_tickets_system') == "yes") || ($CI->config->item('enable_tickets_system') == "")) { ?>
												<input type="checkbox" id="enable_tickets" name="enable_tickets" class="switch-input" checked />
											<? } if ($CI->config->item('enable_tickets_system') == "no") { ?>
												<input type="checkbox" id="enable_tickets" name="enable_tickets" class="switch-input" />
											<? } ?>
											<span class="switch-label" data-on="On" data-off="Off"></span>
											<span class="switch-handle"></span>
										</label>

										<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_enable_tickets_system");?>">
											<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
										</a>
									</div>
								</div>

								<div class="control-group">
									<label class="control-label" for="focusedInput"><?=lang("label_show_credits");?></label>
									<div class="controls">
										<label class="switch switch-primary">
											<? if (($CI->config->item('show_credits') == "yes") || ($CI->config->item('show_credits') == "")) { ?>
												<input type="checkbox" id="show_credits" name="show_credits" class="switch-input" checked />
											<? } if ($CI->config->item('show_credits') == "no") { ?>
												<input type="checkbox" id="show_credits" name="show_credits" class="switch-input" />
											<? } ?>
											<span class="switch-label" data-on="On" data-off="Off"></span>
											<span class="switch-handle"></span>
										</label>

										<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_show_credits");?>">
											<span class="add-on"><i class="fa fa-question-circle text-blue for-switch"></i></span>
										</a>
									</div>
								</div>

								<div class="control-group text-right margin-top40">
									<span class="float-left"><a href="<?=base_url();?>dashboard"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

									<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
									<button type="button" id="save_settings" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
									<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
								</div>
							</form>
						</div>
					</div>

					<!-- Groups Tab -->
					<div class="tab-pane" id="groups">
						<form class="form-horizontal" id ="user_types_form" name="user_types_form">
							<? $current_nr = 0; for ($i = 0; $i < count($user_types); $i++) { if (($i == 0) || ($i == 3)) { ?>
								<div class="control-group">
									<? $current_nr = $i+1; ?>
									<label class="control-label" for="focusedInput"><?=lang("label_group")." ".$current_nr;?></label>
									<div class="controls">
										<div class="input-prepend">
											<span class="add-on"><i class="fa fa-group"></i></span>
											<input class="input-xlarge focused disabled" id="user_type_<?=$i;?>" name="user_type_<?=$i;?>" type="text" value="<?=$user_types[$i]->name;?>" disabled/>
											<input type ="hidden" id="user_type_nr_<?=$i;?>" name="user_type_nr_<?=$i;?>" value="<?=$user_types[$i]->name;?>" />
										</div>
									</div>
								</div>
							<? } else { ?>
								<div class="control-group">
									<? $current_nr = $i+1; ?>
									<label class="control-label" for="focusedInput"><?=lang("label_group")." ".$current_nr;?></label>
									<div class="controls">
										<div class="input-prepend">
											<span class="add-on"><i class="fa fa-group"></i></span>
											<input class="input-xlarge focused" id="user_type_nr_<?=$i;?>" name="user_type_nr_<?=$i;?>" type="text" value="<?=$user_types[$i]->name;?>" />
										</div>
									</div>
								</div>
							<? } } ?>

							<input type="hidden" id="user_types_nr" name="user_types_nr" value="<?=$current_nr-1;?>" />

							<div class="control-group text-right margin-top40">
								<span class="float-left"><a href="<?=base_url();?>dashboard"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

								<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
								<button type="button" id="save_user_types_settings" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
								<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>