<? require_once("header.php"); ?>

<body class="login">
	<!-- Notifications messages view -->
	<? require_once('notifications.php'); ?>

	<div class="container-fluid-full">
		<div class="row-fluid">		
			<div class="row-fluid">
				<div class="login-box">
					<div>
						<div class="small_logo"><a href="<?=base_url();?>"><img src="<?=base_url();?>img/logo_small.png" width="50" height="50" alt="logo" /></a></div>
						<div class="small_company text-right"><h3><?=$this->config->item("company");?></h3></div>
						<div class="clearfix"></div>
					</div>
					<hr />
					<h2><?=lang("lgn_login_account");?></h2>

					<form class="form-horizontal" name="login_form" id="login_form">
						<fieldset>
							<input class="input-large span12" name="username" id="username" type="text" placeholder="<?=lang("lgn_username");?>" />
							<input class="input-large span12" name="password" id="password" type="password" placeholder="<?=lang("lgn_password");?>" />
							<div class="clearfix"></div>

							<label class="remember" for="remember"><input type="checkbox" id="remember" name="remember" /><?=lang("lgn_remember_me");?></label>
							<div class="clearfix"></div>

							<button type="button" class="btn btn-primary span12" name="login_button" id="login_button"><?=lang("btn_login");?></button>
						</fieldset>	
					</form>

					<hr />
					<h3><?=lang("lgn_forgot_pass");?></h3>
					<p><?=lang("lgn_no_problem");?> <a href="<?=base_url();?>recover"><?=lang("lgn_click_here");?></a> <?=lang("lgn_get_new_pass");?></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>