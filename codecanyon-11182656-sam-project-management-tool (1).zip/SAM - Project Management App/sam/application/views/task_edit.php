<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

if ($user_type > 2)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification messages -->
	<? require_once("notifications.php"); ?>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_edit_task");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="edit_task_form" id="edit_task_form">
					<fieldset>	
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_title");?></label>
							<div class="controls">
								<input class="input-xlarge focused" id="tedit_name" name="tedit_name" type="text" value="<?=$task_info->name;?>" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label"><?=lang("label_project");?></label>
							<div class="controls">
								<select id="task_edit_projects" class="selectpicker form-control" name="tedit_projid">
									<? if (is_array($projects)) { foreach ($projects as $elem) { if ($elem->id == $task_info->project_id) { ?>
										<option value="<?=$elem->id;?>" selected><?=$elem->name;?></option>
									<? } else { ?> 
										<option value="<?=$elem->id;?>"><?=$elem->name;?></option>
									<? } } } ?>
							  	</select>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label"><?=lang('label_priority');?></label>
							<div class="controls">
							  	<select id="tedit_priority">
									<? if (is_array($task_priority)) { foreach ($task_priority as $elem) { ?>
										<option value="<?=$elem->id;?>" <? if ($elem->id == $task_info->priority_id) echo "selected";?>><?=$elem->name;?></option>
									<? } } ?>
							  	</select>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label"><?=$user_types[2]->name;?></label>
							<div class="controls">
							  	<select id="edit_assigned_to" class="margin-left multiselect" multiple="multiple">
							  		<? 
							  		if (is_array($workers)) 
							  		{ 
							  			if ((is_array($task_assigned))) 
							  			{ 
							  				foreach ($workers as $elem) 
							  				{ ?>
							  					<option value="<?=$elem->id;?>" <? if (in_array($elem->id, $task_assigned)) echo "selected"; ?>><?=$elem->first_name." ".$elem->last_name;?></option>
							  			<?  } 
							  			}  
										else 
										{ 
											foreach ($workers as $elem) 
											{ ?>
												<option value="<?=$elem->id;?>"><?=$elem->first_name." ".$elem->last_name;?></option>
										<?  } 
										} 
									} ?>	
							  	</select>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_desc");?></label>
							<div class="controls">
								<textarea class="common_ckeditor tdesc" id="edit_textarea2" name="tedit_desc" rows="3"><?=$task_info->description;?></textarea>
							</div>
						</div>		

						<? if (($task_info->estimated_time != 0) && ($task_info->due_date)) { ?>

							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_cost");?></label>
								<div class="controls">
									<div class="input-prepend input-append">
										<span class="add-on float-left"><i class="fa fa-clock-o"></i></span>
								  		<input type="text" class="input-small focused" id="tedit_estimated_cost" name="tedit_estimated_cost" value="<?=$task_info->estimated_time;?>" />
								  		<span class="add-on"><?=lang("label_hours");?></span>
									</div>
								</div>
							</div>
	 
							<div class="control-group">
								<label class="control-label" for="focusedInput"><?=lang("label_due_date");?></label>
								<div class="controls">
									<div class="input-prepend">
										<span class="add-on float-left"><i class="fa fa-calendar"></i></span>
								  		<input type="text" class="datepicker input-small" data-date-format="yyyy-mm-dd" id="tedit_due_date" name="tedit_due_date" value="<? if ($task_info->due_date == '0000-00-00') echo ""; else echo $task_info->due_date; ?>" />
									</div>
								</div>
							</div>
						
						<? } ?>
					</fieldset>
				</form>

				<div class="form-horizontal">
					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_attachment");?></label>
						<div class="controls">
							<form action="<?=base_url();?>tasks/uploadTaskAttachment" id="upload_task_picture_form" class="dropzone span8">
								<div class="fallback">
									<input name="file" type="file" multiple="" />
								</div>
								<input type="hidden" name="task_id" id="task_id" value="<?=$task_info->id;?>" />
								<input type="hidden" name="from" id="from" value="edit" />
							</form>
							<div class="span9" style="margin: -15px 0px 0px 0px;"><?=lang("label_allowed_file_types");?></div>
						</div>
					</div>
				</div>

				<!-- Check if we have attachments -->
				<? if ($task_info->attachments != "") { $exist = "yes"; ?>
					<div class="row-fluid">
						<div class="span12">
							<h5><?=lang("label_attachment");?></h5>
							<div class="tooltip-demo well">
								<div class="message">
									<div class="attachments" style="margin: 0px !important;">
										<ul>
											<?
											$attachments 	= substr($task_info->attachments, 0, -1);
											$att_arr 		= explode(',', $attachments);

											// Download path
											$path = FCPATH.'uploads/';

											foreach ($att_arr as $elem)
											{
												$end_pos 		= strrpos($elem, '.');
												$extension 		= ltrim(substr($elem, $end_pos), '.');
												$label_type		= "";

												if (file_exists($path.$elem))
												{
													$filesize = filesize($path.$elem);

													if ($filesize >= 1048576)
											        {
											            $filesize = number_format($filesize / 1048576, 2) .' MB';
											        }
											        elseif ($filesize >= 1024)
											        {
											            $filesize = number_format($filesize / 1024, 2) .' KB';
											        }
											        elseif ($filesize > 1)
											        {
											            $filesize = $filesize .' bytes';
											        }

											        $extension = strtolower($extension);

											        if ($extension == 'zip' || $extension == 'psd' || $extension == 'ai')
													{
														$label_type = "label-important";
													}
													elseif ($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg')
													{
														$label_type = "label-warning";
													}
													elseif ($extension == 'xls' || $extension == 'xlsx' || $extension == 'doc' || $extension == 'docx' || $extension == 'odt')
													{
														$label_type = "label-success";
													}
													elseif ($extension == 'pdf' || $extension == 'csv' || $extension == 'txt')
													{
														$label_type = "label-info";
													}
													else
													{
														$label_type = "label-info";
													}
											    }
												else
												{
													$filesize = "File does not exist. Please check folder rights!";
													$exist = "no";
												}

												$start_pos 		= $end_pos - 20;
												$stripped_name 	= substr_replace($elem, '', $start_pos, 20); ?>

												<li>
													<span class="label <?=$label_type;?>"><?=$extension;?></span> <b><?=$stripped_name;?></b>&nbsp;&nbsp;<i>(<?=$filesize;?>)</i>

													<? if ($exist == "yes") { ?>
														<span class="quickMenu">
															<a href="<?=base_url();?>tasks/downloadAttachment/<?=$elem;?>">
																<span class="add-on"><i class="fa fa-cloud-download"></i></span>
															</a>
															&nbsp;
															<input type="hidden" value="<?=$task_info->id;?>" />
															<input type="hidden" value="<?=$elem;?>" />
															<span class="add-on clickable" onclick="remove_task_attachment.call(this);"><i class="fa fa-times-sign"></i></span>
														</span>
													<? } ?>
												</li>
											<? } ?>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				<? } ?>

				<div class="control-group text-right margin-top40">
					<span class="float-left"><a href="<?=$_SERVER['HTTP_REFERER'];?>"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

					<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
					<button type="button" id="save_task_changes" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
					<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
					<input type="hidden" id="task_id" name="task_id" value="<?=$task_info->id;?>" />
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>