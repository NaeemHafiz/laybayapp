<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('projectslib');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}
?>

<!-- start: Content -->
<div id="content" class="span10">

	<!-- Dialog box to delete project --> 
	<div class="modal fade in hide" id="delete_project_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_project_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_delete_project");?></h2>
					</div>
				</div>
				<input type="hidden" id="pro_id" name="pro_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="delete_project.call(this,event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-list-alt"></i><span class="break"></span><?=lang("menu_projects");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>

				<? if ($user_type <= 2) { ?>
					<a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>projects/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_project");?></a>
				<? } ?>
			</div>
			
			<div class="box-content">
				<form class="form-horizontal" name="projects_form" id="projects_form">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable datatable dataTable projects-table" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_project");?></th>
										<? if ($user_type != 4) { ?>
											<th><?=lang("thead_client");?></th>
										<? } ?>
										<th><?=lang("thead_added");?></th>
										<th><?=lang("thead_due_date");?></th>
										<th><?=lang("thead_status");?></th>
										<? if ($user_type != 4) { ?>
											<th><?=lang("thead_actions");?></th>
										<? } ?>
									</tr>
								</thead>

					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? $odd_even = 0; if (is_array($projects)) { $i = 0; foreach ($projects as $elem) { 
					  				// We get project completion rate
					  				$uncompleted_tasks = $CI->projectslib->getProjectCompletion($elem->projectid);
					  				// For each project we get the clients separately 
					  				$clients = $CI->projectslib->getClientsForProjects($elem->projectid);
					  				?>

						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center">
											<?=$elem->name;?>
											<div class="progress progress-success height8" style="margin: 3px 0px;"  title="<?=$uncompleted_tasks;?>% <?=lang('status_completed');?>">
												<div class="bar" style="width: <?=$uncompleted_tasks;?>%"></div>
											</div>
										</td>

										<? if ($user_type != 4) { ?>
											<td class="center">
												<? // If we have clients to the project
												if (is_array($clients))
												{
													// Names string wil contain the names with comma as a separator
													$names_string = ""; 

													// We go through all clients and save their name to the string
													for ($i = 0; $i < count($clients); $i++)
													{
														// We want a max of 2 clients displayed, so we stop when we reach it
														if ($i == 2)
														{
															// strip the comma from the end, then concatenate with ...
															$names_string = substr($names_string, 0, -2).'...';
															break;
														}
														// Else add string to the actual string
														else
														{
															$names_string .= $clients[$i]->first_name.' '.$clients[$i]->last_name.', ';
														}
													}

													// We count the cients
													if (count($clients) < 3)
														echo substr($names_string, 0, -2);
													else
														echo $names_string;
												} else { } ?>
											</td>
										<? } ?>
										<td class="center"><?=$elem->create_date;?></td>
										<td class="center"><?=$elem->end_date;?></td>
										<td class="center">
											<? if ($elem->status == "In Progress") { ?>
												<span class="label label-info"><?=lang("status_in_progress");?></span>
											<? } else if ($elem->status == "Completed") { ?>
												<span class="label label-success"><?=lang("status_completed");?></span>
											<? } ?>
										</td>
										<? if ($user_type != 4) { ?>
											<td class="center">
													<a class="btn" href="<?=base_url();?>tasks/project_tasks/<?=$elem->projectid;?>" title="<?=lang("btn_view_tasks");?>">
														<i class="fa fa-tasks"></i>
													</a>
													<a class="btn btn-success" href="<?=base_url();?>projects/view/<?=$elem->projectid;?>" title="<?=lang("btn_view");?>">
														<i class="fa fa-eye"></i>
													</a>
												<? if ($user_type <= 2) { ?>
													<a class="btn btn-info" href="<?=base_url();?>projects/edit/<?=$elem->projectid;?>" title="<?=lang("btn_edit");?>">
														<i class="fa fa-pencil"></i>
													</a>
													<a class="btn btn-danger" href="#" onclick="showDialog.call(this, event, 'delete_project_dialog', <?=$elem->projectid;?>, 'pro_id', '<?=$elem->name;?>');" title="<?=lang("btn_delete");?>">
														<i class="fa fa-trash-o"></i>
													</a>
													<input type="hidden" value="<?=$elem->projectid;?>" />
												<? } ?>
											</td>
										<? } ?>
										<input type="hidden" value="<?=$elem->projectid;?>" />
									</tr>
									<? $odd_even++;	} } ?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>