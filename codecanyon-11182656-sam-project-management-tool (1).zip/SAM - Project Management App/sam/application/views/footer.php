		<footer>
			<p>
				<span class="float-left text-left">Copyright &copy; 2013 - <?=date("Y");?> <a href="<?=base_url();?>" class="link">SAM</a> v1.4.5</span>
				<? if ($this->config->item("show_credits") == "yes") { ?>
					<span class="float-right text-right">Powered by <a href="https://intelcoder.com" class="link" target="_blank">IntelCoder</a></span>
				<? } ?>
			</p>
		</footer>
	</div>
</body>
</html>