<?
require_once("top.php");

$CI =& get_instance();

$CI->load->library('session');

$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

if ($user_type >= 3)
{
	redirect(base_url().'dashboard');
}

if ($CI->config->item('enable_tickets_system') == 'no')
{
	redirect(base_url());
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification messages -->
	<? require_once("notifications.php"); ?>
	
	<div class="row-fluid">
		<div class="box span12 visible">
			<div class="box-header">
				<h2><i class="fa fa-list-alt"></i><span class="break"></span><?=lang("title_edit_settings");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="edit_settings_form" id="edit_settings_form">
					<fieldset>	
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_active");?></label>
							<div class="controls">
								<label class="switch switch-primary">
									<input type="checkbox" class="switch-input" onclick="if (this.checked) document.getElementById('active').value = 'yes'; else document.getElementById('active').value = 'no';" <? if ($settings_info->active == 'yes') echo 'checked'; ?> />
									<input type="hidden" id="active" name="active" value="<?=$settings_info->active;?>" />
									<span class="switch-label" data-on="On" data-off="Off"></span>
									<span class="switch-handle"></span>
								</label>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_client");?></label>
							<div class="controls">
								<div class="input-prepend">
									<span class="add-on"><i class="fa fa-user"></i></span>
									<select id="client" name="client" class="margin-left" onchange="removePValidation.call(this);">
										<option value=""><?=lang("label_select");?></option>
										<? if (is_array($clients))
										{
											foreach ($clients as $elem)
											{ ?>
												<option value="<?=$elem['id'];?>" <? if ($elem['id'] == $settings_info->client_id) echo "selected"; ?>><?=$elem['first_name']." ".$elem['last_name'];?></option>
										<?	}
										} ?>
									</select>
								</div>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_private_key");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-key"></i></span>
									<input type="text" class="input-xlarge" name="client_key" id="client_key" value="<?=$settings_info->client_key;?>" readonly />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_generate_private_key");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
								&nbsp;&nbsp;<button type="button" class="btn btn-warning" onclick="generateClientKey.call(this);" title="<?=lang("btn_generate");?>"><i class="fa fa-refresh"></i></button>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_text_button");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-file-text-o"></i></span>
									<input type="text" class="input-xlarge" name="btn_text" id="btn_text" value="<?=$settings_info->button_text;?>" onblur="removePValidation.call(this);" />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_text_button");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_text_color");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-tint"></i></span>
									<input type="text" class="input-small colorpicker" name="text_col" id="text_col" value="<?=$settings_info->text_color;?>" onblur="removePValidation.call(this);" />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_text_color");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_button_color");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-tint"></i></span>
									<input type="text" class="input-small colorpicker" name="btn_col" id="btn_col" value="<?=$settings_info->button_color;?>" onblur="removePValidation.call(this);" />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_color_button");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_app_url");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-link"></i></span>
									<input type="text" class="input-xlarge" id="app_url" name="app_url" value="<?=$settings_info->app_url;?>" onblur="removeValidation.call(this);" onblur="removePValidation.call(this);" />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_client_domain_url");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_notified_emails");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-envelope"></i></span>
									<input type="text" class="input-xlarge" id="notified_emails" name="notified_emails" value="<?=$settings_info->notification_email;?>" onblur="removePValidation.call(this);" />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_notified_emails");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
							</div>
						</div>

						<!-- <div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_api_script");?></label>
							<div class="controls">
								<div class="input-prepend input-append">
									<span class="add-on"><i class="fa fa-code"></i></span>
									<input type="text" name="script" onblur="removeValidation.call(this);" class="input-xxlarge" value="<?=htmlspecialchars($settings_info->script);?>" onblur="removePValidation.call(this);" readonly />
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_copy_api_script");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
								&nbsp;&nbsp;<button type="button" id="script_copy_btn" class="btn btn-info" data-clipboard-text="<?=htmlspecialchars($settings_info->script);?>"><i class="fa fa-copy"></i></button>
							</div>
						</div> -->

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_api_script");?></label>
							<div class="controls">
								<div class="span7 input-append margin_right35">
									<textarea name="script" onblur="removeValidation.call(this);" class="span12 tickets_textarea" readonly><?=htmlspecialchars($settings_info->script);?></textarea>
									<a href="#" data-rel="popover" title="<?=lang("label_information");?>" data-content="<?=lang("msg_copy_api_script");?>">
										<span class="add-on"><i class="fa fa-question-circle text-blue"></i></span>
									</a>
								</div>
								<button type="button" id="script_copy_btn" class="btn btn-info" data-clipboard-text="<?=htmlspecialchars($settings_info->script);?>" title="<?=lang("btn_copy");?>"><i class="fa fa-copy"></i></button>
							</div>
						</div>

						<div class="control-group text-right margin-top40">
							<span class="float-left"><a href="<?=base_url();?>tickets/settings"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

							<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
							<button type="button" class="btn btn-primary" onclick="saveSettings.call(this);"><?=lang("btn_generate_script");?></button>
							<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
							<input type="hidden" id="settings_id" name="settings_id" value="<?=$settings_info->id;?>" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>