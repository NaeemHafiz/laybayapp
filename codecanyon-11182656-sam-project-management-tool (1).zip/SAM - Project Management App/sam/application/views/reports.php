<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('functions');
$user_type = $CI->session->userdata('user_type');

if ($user_type >= 3)
{
	redirect(base_url().'login');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-bar-chart-o"></i><?=lang("title_reports");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<div class="row-fluid form-horizontal">
					<!-- Tabs -->
					<ul class="nav tab-menu nav-tabs margin-right65" id="myTab">
						<li><a href="#nrtpd"><?=lang("title_nr_tasks_per").' '.$CI->functions->getUserTypeName(3)->name;?></a></li>
						<li><a href="#tpd"><?=lang("title_tasks_per").' '.$CI->functions->getUserTypeName(3)->name;?></a></li>
					</ul>

					<div id="myTabContent" class="tab-content">
						<!-- Nr of tasks per developer -->
						<div class="tab-pane" id="nrtpd">
							<table class="table table-striped table-bordered" id="reports-table" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_name");?></th>
										<th><?=lang("thead_assigned");?></th>
										<th><?=lang("thead_in_progress");?></th>
										<th><?=lang("thead_completed");?></th>
										<th><?=lang("thead_hours");?></th>
										<th><?=lang("thead_balance");?></th>
									</tr>
								</thead>

								<tbody></tbody>
							</table>
						</div>
						
						<!-- Tasks per developer -->
						<div class="tab-pane" id="tpd">
							<table class="table table-striped table-bordered" id="reports-per-developer-table" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_name");?></th>
										<th><?=lang("thead_project");?></th>
										<th><?=lang("thead_added");?></th>
										<th><?=lang("thead_due_date");?></th>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>

								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>