<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');
$CI->load->library('functions');
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification buttons view -->
	<? require_once('notifications.php'); ?>

	<!-- Dialog box to show task message --> 
	<div class="modal fade in hide" id="show_notification_message">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<div id="notification_text"></div>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-bell"></i><span class="break"></span><?=lang("title_notifications");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal">
					<div class="row-fluid">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
							<thead>
								<tr>
									<th><?=lang('thead_type');?></th>
									<th><?=lang('thead_title');?></th>
									<th><?=lang('thead_message');?></th>
									<th><?=lang('thead_added');?></th>
									<th><?=lang('thead_actions');?></th>
								</tr>
							</thead>
							<tbody>
								<? if (is_array($noti_info)) foreach ($noti_info as $key => $value)
								{ ?>
									<tr>
										<td class="center_text">
											<? 
											$image = "";
											$color = "";

											switch ($value->type) 
											{
												// New project added
												case "New Project Added":
													$image 	.= "<i class='fa fa-list-alt'></i>";
													$color  = "blue";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// New task added
												case "New Task Added":
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "darkGreen";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// Task Assigned
												case "Task Assigned":
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// Task Quoted
												case "Task Quoted":
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// Task Completed
												case "Task Completed":
													$image 	.= "<i class='fa fa-tasks'></i>";
													$color  = "lightOrange";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// New comment added
												case "New Comment":
													$image 	.= "<i class='fa fa-comment'></i>";
													$color  = "orange";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												// New Support Ticket
												case "New Support Ticket":
													$image 	.= "<i class='fa fa-support'></i>";
													$color  = "pink";

													echo "<div class='background_box backgroundColor ".$color."'>".$image."</div>";
													break;

												default:
													break;
											} ?>
										</td>
										<td><?=$value->title;?></td>
										<td>
											<? // Get second sentence from original text
											if (strlen($value->message) > 0)
											{
												$position 	= stripos($value->message, ',');
												$position2 	= stripos($value->message, '!', $position + 1);
												echo str_replace(array('<br/>', '<br />', '<br>', '!<'), array(' ', ' ', ' ', '!'), substr($value->message, $position + 1, $position2 - 1));
											}
											?>
										</td>
										<td><?=$CI->functions->datetimeFormatMin($value->added);?></td>
										<td>
											<a class="btn btn-success" href="#" onclick="showDialog.call(this, event, 'show_notification_message', 'dummy', 'notification_text', '<?=$value->title;?>', 'div');" title="<?=lang("btn_disable");?>">
												<i class="fa fa-eye"></i>
											</a>
											<input type="hidden" value="<?=htmlspecialchars($value->message);?>">
										</td>
									</tr>
								<? } ?>
							</tbody>
						</table>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>