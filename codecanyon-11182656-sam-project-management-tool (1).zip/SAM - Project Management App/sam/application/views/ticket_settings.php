<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('functions');
$user_type = $CI->session->userdata('user_type');

if ($user_type >= 3)
{
	redirect(base_url().'login');
}

if ($CI->config->item('enable_tickets_system') == 'no')
{
	redirect(base_url());
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Remove settings modal dialog box -->
	<div class="modal fade in hide" id="delete_setting_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_ticket_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_delete_settings");?></h2>
					</div>
				</div>
				<input type="hidden" id="setting_id" name="setting_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="deleteTicketSetting.call(this, event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn close_ticket_dialog" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-gear"></i><?=lang("title_ticket_settings");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>

				<? if ($user_type <= 2) { ?>
					<a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>tickets/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_ticket_settings");?></a>
				<? } ?>
			</div>

			<div class="box-content">
				<div class="row-fluid form-horizontal">
					<table class="table table-striped table-bordered" id="ticket-settings-table">
						<thead>
							<tr role="row">
								<th><?=lang("label_app_url");?></th>
								<th><?=lang("thead_client");?></th>
								<th><?=lang("thead_status");?></th>
								<th><?=lang("thead_actions");?></th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>