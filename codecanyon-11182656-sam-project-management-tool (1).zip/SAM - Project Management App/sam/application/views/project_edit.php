<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id = $CI->session->userdata('user_id');
$user_type = $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL )
{
	redirect(base_url().'login');
}

if ($user_type != 1 && $user_type != 2)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification messages -->
	<? require_once("notifications.php"); ?>
	
	<div class="row-fluid">
		<div class="box span12 visible">
			<div class="box-header">
				<h2><i class="fa fa-list-alt"></i><span class="break"></span><?=lang("title_edit_project");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="edit_project_form" id="edit_project_form">
					<fieldset>	
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_title");?></label>
							<div class="controls">
								<input class="input-xlarge focused" id="pname" name="pname" type="text" value="<?=$project->name;?>" />
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("label_desc");?></label>
							<div class="controls">
								<textarea class="common_ckeditor pdesc" id="textarea2" name="pdesc" rows="3"><?=$project->description;?></textarea>
							</div>
						</div>

						<div class="control-group">
							<label class="control-label" for="pddate"><?=lang("label_due_date");?></label>
							<div class="controls">
								<div class="input-prepend">
									<span class="add-on"><i class="fa fa-calendar"></i></span>
							  		<input type="text" class="input-small datepicker pdate" id="pddate" name="pddate" data-date-format="yyyy-mm-dd" value="<?=$project->end_date;?>" />
							  	</div>
							</div>
						</div>		

						<div class="control-group">
							<label class="control-label" for="selectError1"><?=$user_types[1]->name;?></label>
							<div class="controls">
							  	<select id="pms_select" class="margin-left multiselect" multiple="multiple">
									<?  if (is_array($pm_names)) 
										{ 
											if (is_array($assigned_pm)) 
											{ 
												foreach ($pm_names as $elem) 
												{ ?>
													<option value="<?=$elem->user_id;?>" <? if (in_array($elem->user_id, $assigned_pm)) echo "selected"; ?>><?=$elem->first_name." ".$elem->last_name;?></option>
											<?  } 
											} 
										} ?>	
								</select>
							</div>
						</div>
						
						<div class="control-group">
							<label class="control-label" for="focusedInput"><?=lang("subtitle_client");?></label>
							<div class="controls">
							  	<select id="clients_select" class="margin-left multiselect" multiple="multiple">
									<?  if (is_array($client_names))
										{
											if (is_array($assigned_client)) 
											{ 
												foreach ($client_names as $elem) 
												{ 
												?>
													<option value="<?=$elem->user_id;?>" 
														<? 
															if (in_array($elem->user_id, $assigned_client)) echo "selected"; 
														?>
														><?=$elem->first_name." ".$elem->last_name;?>
													</option>
											<?	} 
											} 
											else foreach ($client_names as $elem) 
											{ ?>
												<option value="<?=$elem->user_id;?>"><?=$elem->first_name." ".$elem->last_name;?></option>
										<?	} 
										} ?>
								</select>
							</div>
						</div>

						<div class="control-group text-right margin-top40">
							<span class="float-left"><a href="<?=$_SERVER['HTTP_REFERER'];?>"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

							<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
							<button type="button" id="save_project_changes" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
							<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
							<input type="hidden" id="project_id" name="project_id" value="<?=$project->id;?>" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>