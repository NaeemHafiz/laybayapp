<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Notification buttons -->
	<? require_once('notifications.php'); ?>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-group"></i><span class="break"></span><?=lang("title_edit_client");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="client_edit_form" id="client_edit_form">
					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_first_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="client_fname" name="client_fname" value="<?=$client_info->first_name;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_last_name");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-user"></i></span>
								<input class="input-xlarge focused" id="client_lname" name="client_lname" value="<?=$client_info->last_name;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_email");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-envelope"></i></span>
								<input class="input-xlarge focused" id="client_email" name="client_email" value="<?=$client_info->email;?>" onclick="validateEmail.call(this);" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_phone");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-phone"></i></span>
								<input class="input-xlarge focused" id="client_phone" name="client_phone" value="<?=$client_info->telephone;?>" onkeydown="check_if_number(event);" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="client_pword" name="client_pword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_confirm_pass");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-lock"></i></span>
								<input class="input-xlarge focused" id="client_cpword" name="client_cpword" type="password" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_company");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-globe"></i></span>
								<input class="input-xlarge focused" id="client_cname" name="client_cname" value="<?=$client_info->comp_name;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_url");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-link"></i></span>
								<input class="input-xlarge focused" id="edit_home_page" name="edit_home_page" value="<?=$client_info->homepage;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_country");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-flag"></i></span>
								<select id="client_country" name="client_country" class="select select-xlarge">
									<? if (is_array($countries)) { foreach ($countries as $elem) { if ($client_info->id_country == $elem->id) { ?>
										<option value="<?=$elem->id;?>" selected><?=$elem->country;?></option>
									<? } else { ?> 
										<option value="<?=$elem->id;?>"><?=$elem->country;?></option>
									<? } } } ?>
								</select>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_city");?></label>
						<div class="controls">
							<div class="input-prepend">
								<span class="add-on"><i class="fa fa-map-marker"></i></span>
								<input class="input-xlarge focused" id="client_city" name="client_city" value="<?=$client_info->city;?>" type="text" />
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="focusedInput"><?=lang("label_active");?></label>
						<div class="controls">
							<label class="switch switch-primary">
								<input type="checkbox" id="status_active" name="status_active" class="switch-input" <?=($client_info->active == "yes" ? "checked" : "");?> />
								<span class="switch-label" data-on="On" data-off="Off"></span>
								<span class="switch-handle"></span>
							</label>
						</div>
					</div>

					<input type="hidden" id="client_id" name="client_id" value="<?=$client_info->user_id;?>" />

					<div class="control-group text-right margin-top40">
						<span class="float-left"><a href="<?=base_url();?>clients"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>

						<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
						<button type="button" id="save_edit_client" class="btn btn-primary"><?=lang("btn_save_changes");?></button>
						<button type="reset" class="btn"><?=lang("btn_cancel");?></button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>