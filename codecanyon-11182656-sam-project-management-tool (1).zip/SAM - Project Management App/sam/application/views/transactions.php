<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('functions');
$user_type = $CI->session->userdata('user_type');

if ($user_type == 4)
{
	redirect(base_url().'dashboard');
}
?>

<!-- start: Content -->
<div id="content" class="span10">

	<!-- Dialog box to tell user to add a paypal account --> 
	<div class="modal fade in hide" id="paypal_account_check">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3><?=lang("popup_title_paypal_account");?></h3>
		</div>
		<div class="modal-body">
			<div class="control-group">
				<div class="controls center_text popup_text">
					<h2><?=lang("msg_need_paypal_account");?></h2>
				</div>
			</div>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header backgroundColor white text-black">
				<h2><i class="fa fa-clock-o"></i><?=lang("title_balance");?>: <?=$profile_info->balance;?> <?=lang("title_hours");?></h2>
				
				<input type="button" class="btn btn-success add-project-right" id="cash_out_button" name="cash_out_button" value="<?=lang("btn_cashout");?>" paypalaccount="<?=$profile_info->paypal_account;?>" />
				<div class="input-prepend float-right margin0">
					<span class="add-on margin-top3"><i class="fa fa-money"></i></span>
					<input class="input-small focused input_box_header" id="cash_out" name="cash_out" onkeydown="check_if_number(event);" type="text" />
				</div>
			</div>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-exchange"></i><span class="break"></span><?=lang("title_transactions");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			
			<div class="box-content">
				<form class="form-horizontal" name="clients_form" id="clients_form">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable datatable dataTable members-table" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_date");?></th>
										<th><?=lang("thead_title");?></th>
										<th><?=lang("thead_debit");?></th>
										<th><?=lang("thead_credit");?></th>
										<th><?=lang("thead_balance");?></th>
									</tr>
								</thead>

					  			<tbody class="ajax_transaction" role="alert" aria-live="polite" aria-relevant="all">
					  			<? $odd_even = 0; if (is_array($transactions)) { foreach ($transactions as $elem) { ?>
						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center"><?=$CI->functions->datetimeFormatMin($elem->transaction_date);?></td>
										<!-- verify title is cashou or task title-->
										<? if ($elem->task_id == 0) { ?>
											<td class="center"><?=$elem->title;?></td>
										<? } else { ?>
											<td class="center"><a href="<?=base_url()?>/tasks/view/<?=$elem->task_id;?>"><?=$elem->title;?></a></td>
										<? } ?>
										<td class="center"><?=$elem->debit;?></td>
										<td class="center"><?=$elem->credit;?></td>
										<td class="center"><?=$elem->balance;?></td>

										<input type="hidden" id="transaction_id" name="transaction_id" value="<?=$elem->id;?>" />
									</tr>
								<? $odd_even++;	} } ?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>