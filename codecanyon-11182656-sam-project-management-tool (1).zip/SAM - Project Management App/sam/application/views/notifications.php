<!-- Success Messages -->

<!-- Success message notification -->
<button class="noty hide" id="success_notification" data-noty-options='{"text":"<?=lang("msg_changes_saved");?>", "layout":"topRight", "type":"success"}'><i class="fa fa-bell"></i></button>

<!-- Password changes successfully message notification -->
<button class="noty hide" id="password_change_success_notification" data-noty-options='{"text":"<?=lang("msg_new_login_details");?>", "layout":"topRight", "type":"success"}'><i class="fa fa-bell"></i></button>

<!-- Copied to clipboard notification -->
<button class="noty hide" id="copy_successful" data-noty-options='{"text":"<?=lang("msg_copied_to_clipboard");?>", "layout":"topRight", "type":"success"}'><i class="fa fa-bell"></i></button>


<!-- Error Messages -->

<!-- Uncomplete message notification -->
<button class="noty hide" id="uncomplete_notification" data-noty-options='{"text":"<?=lang("msg_complete_all_fields");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Error cost(on task complete) message notification -->
<button class="noty hide" id="error_cost_notification" data-noty-options='{"text":"<?=lang("msg_invalid_cost");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Error message notification -->
<button class="noty hide" id="error_notification" data-noty-options='{"text":"<?=lang("msg_changes_not_saved");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Incomplet task message notification -->
<button class="noty hide" id="incomplete_task_notification" data-noty-options='{"text":"<?=lang("msg_task_not_completed");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Existent email message notification -->
<button class="noty hide" id="existent_email_notification" data-noty-options='{"text":"<?=lang("msg_email_already_exist");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Unsaved password message notification -->
<button class="noty hide" id="unsaved_password_notification" data-noty-options='{"text":"<?=lang("msg_pass_not_saved");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Inexistent email message notification -->
<button class="noty hide" id="inexistent_email_notification" data-noty-options='{"text":"<?=lang("msg_email_not_exist");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Password change, user not notified message notification -->
<button class="noty hide" id="user_not_notified_notification" data-noty-options='{"text":"<?=lang("msg_pass_changed_not_notified");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Passwords do not match message notification -->
<button class="noty hide" id="invalid_password_notification" data-noty-options='{"text":"<?=lang("msg_passwords_not_match");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Incorrect password message notification -->
<button class="noty hide" id="invalid_curr_password_notification" data-noty-options='{"text":"<?=lang("msg_invalid_password");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Invalid username message notification -->
<button class="noty hide" id="invalid_username_notification" data-noty-options='{"text":"<?=lang("msg_username_already_exist");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Invalid user or email message notification -->
<button class="noty hide" id="invalid_user_email_notification" data-noty-options='{"text":"<?=lang("msg_username_and_email_already_exist");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>

<!-- Invalid username or password message notification -->
<button class="noty hide" id="invalid_combo_notification" data-noty-options='{"text":"<?=lang("msg_invalid_username_password");?>", "layout":"topRight", "type":"error"}'><i class="fa fa-bell"></i></button>