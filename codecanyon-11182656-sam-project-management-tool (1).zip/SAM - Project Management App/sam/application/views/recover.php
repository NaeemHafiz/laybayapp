<? require_once("header.php"); ?>

<body class="login">
	<!-- Notification messages -->
	<? require_once("notifications.php"); ?>

	<div class="container-fluid-full">
		<div class="row-fluid">		
			<div class="row-fluid">
				<div class="login-box">
					<div>
						<div class="small_logo"><a href="<?=base_url();?>"><img src="<?=base_url();?>img/logo_small.png" /></a></div>
						<div class="small_company text-right"><h3><?=$this->config->item("company");?></h3></div>
						<div class="clearfix"></div>
					</div>
					<hr />
					<h2><?=lang("lgn_recover_pass");?></h2>

					<form class="form-horizontal" name="recover_form" id="recover_form">
						<fieldset>
							<input class="input-large span12" name="recover_email" id="recover_email" type="text" onblur="validateEmail.call(this);" placeholder="<?=lang("lgn_email");?>" />

							<button type="button" class="btn btn-primary span12" name="recover_button" id="recover_button"><?=lang("btn_recover");?></button>
						</fieldset>	
					</form>

					<div class="loader text-center margin-top20"><img src="<?=base_url();?>img/loader.gif" /></div>
					<div class="text-center return_message_success margin-top20"><?=lang("msg_new_login_details");?></div>
					<div class="text-center return_message_error user_not_notified margin-top20"><?=lang("msg_pass_changed_not_notified");?></div>
					<div class="text-center return_message_error password_not margin-top20"><?=lang("msg_pass_not_saved");?></div>
					<div class="text-center return_message_error invalid_email margin-top20"><?=lang("msg_email_not_exist");?></div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>