<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('functions');
$user_id = $CI->session->userdata('user_id');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}
?>

<!-- start: Content -->
<div id="content" class="span10">

	<!-- Dialog box to delete task --> 
	<div class="modal fade in hide" id="delete_task_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3 id="dialogbox_title"></h3>
		</div>
		<div class="modal-body">
			<form id="delete_task_form">
				<div class="control-group">
					<div class="controls center_text popup_text">
					  	<h2><?=lang("msg_want_delete_task");?></h2>
					</div>
				</div>
				<input type="hidden" id="task_id" name="task_id" />
			</form>
		</div>
		<div class="modal-footer center_text">
			<a href="#" class="btn btn-primary" onclick="delete_task.call(this, event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		</div>
	</div>
	
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_tasks_for")." ".$project_name->name;?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
				
				<a class="add-project-right btn btn-success fontsize14" href="<?=base_url();?>tasks/add"><i class="fa fa-plus-square"></i> <?=lang("btn_new_task");?></a>
			</div>

			<div class="box-content">
				<form class="form-horizontal" name="tasks_form" id="tasks_form">
					<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper" role="grid">
						<div class="row-fluid">
							<table class="table table-striped table-bordered bootstrap-datatable datatable dataTable" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info">
								<thead>
									<tr role="row">
										<th><?=lang("thead_task");?></th>
										<th><?=lang("thead_added");?></th>
										<th><?=lang("thead_due_date");?></th>
										<!-- <th><?=lang("thead_completed");?></th> -->
										<? if ($user_type <= 2) { ?>
										<th><?=$user_types[2]->name;?></th>
										<? } ?>
										<th><?=lang("thead_status");?></th>
										<th><?=lang("thead_actions");?></th>
									</tr>
								</thead>   
						  
					  			<tbody role="alert" aria-live="polite" aria-relevant="all">
					  			<? 
					  			$odd_even = 0;

					  			if (is_array($tasks))
					  			{
									foreach ($tasks as $elem)
									{
									?>
						  			<tr class="<? if ($odd_even % 2 == 0) echo "even"; else echo "odd"; ?>">
										<td class="center">
											<? if (strtolower($elem->priority) == 'urgent' ) { ?>
												<i class="fa fa-exclamation-triangle red" title="<?=lang("tooltip_urgent");?>"></i>
											<? } else if (strtolower($elem->priority) == 'high') { ?>
												<i class="fa fa-exclamation-triangle lightOrange" title="<?=lang("tooltip_high");?>"></i>
											<? } ?>
											<?=$elem->name;?>
										</td>
										<td class="center"><?=$CI->functions->dateFormat($elem->create_date);?></td>
										<td class="center"><? if ($elem->due_date == "0000-00-00") echo lang("status_not_set"); else echo $elem->due_date; ?></td>
										<!-- <td class="center"><? // if (strtotime($elem->complete_date) < 0) echo lang("status_not_completed"); else echo date("Y-m-d", strtotime($elem->complete_date)); ?></td> -->
										<? if ($user_type <= 2) { if ($elem->developers != "") { ?>
											<td class="center"><?=$elem->developers;?></td>
										<? } else { ?> 
											<td class="center"><?=lang("status_none");?></td>
										<? } } ?>
										<td class="center">
											<? if ($elem->status == "Not Assigned") { ?>
												<span class="label"><?=lang("status_not_assigned");?></span>
											<? } if ($elem->status == "Assigned") { ?>
												<span class="label label-warning"><?=lang("status_assigned");?></span>
											<? } if ($elem->status == "In Progress") { ?>
												<span class="label label-info"><?=lang("status_in_progress");?></span>
											<? } if ($elem->status == "Completed") { ?>
												<span class="label label-success"><?=lang("status_completed");?></span>
											<? } ?>
										</td>
										<td class="center">
											<a class="btn btn-success" href="<?=base_url();?>tasks/view/<?=$elem->id;?>" title="<?=lang("btn_view");?>"><i class="fa fa-eye"></i></a>
											<? if ($user_type <= 2) { ?>
												<a class="btn btn-info" href="<?=base_url();?>tasks/edit/<?=$elem->id;?>" title="<?=lang("btn_edit");?>"><i class="fa fa-pencil"></i></a>
											<? } ?>
											<? if ($user_type <= 2) { ?>
												<a class="btn btn-danger btn_task_delete" href="#" onclick="showDialog.call(this, event, 'delete_task_dialog', <?=$elem->id;?>, 'task_id', '<?=$elem->name;?>');" title="<?=lang("btn_delete");?>"><i class="fa fa-trash-o"></i></a>
											<? } ?>
										</td>
										<input type="hidden" value="<?=$elem->id;?>" />
									</tr>
									<?
									$odd_even++;
									}
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>