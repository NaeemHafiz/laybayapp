<?
require_once("top.php");

$CI =& get_instance();
$CI->load->helper('url');
$CI->load->library('session');
$CI->load->library('functions');
$user_id 	= $CI->session->userdata('user_id');
$user_type 	= $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

// Check from where had we accessed this page
$back_button_link = $from_where = "";

if (isset($_SERVER['HTTP_REFERER']))
{
	$from_where = $_SERVER['HTTP_REFERER'];
}

if (strpos($from_where, 'project_tasks_show') !== false) 
{
    $back_button_link = $_SERVER['HTTP_REFERER'];
}
else
{
	$back_button_link = base_url().'tasks';
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<!-- Return notifications view -->
	<? require_once('notifications.php'); ?>

	<!-- Quote task dialog box -->
	<div class="modal hide fade in popup_center" id="start_task_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3><?=$task->name;?></h3>
		</div>

		<div class="modal-body">
			<form id="start_task_form">
				<div class="control-group">
					<label class="control-label control-label-popup float-left" for="start_work_estimated_time"><?=lang("label_cost");?></label>
					<div class="controls">
						<div class="input-prepend float-left">
							<span class="add-on float-left"><i class="fa fa-clock-o"></i></span>
					  		<input type="text" id="start_work_estimated_time" name="start_work_estimated_time" onkeydown="check_if_float(event);" class="input-small float-left" placeholder="0.00" />
						</div>
					</div>
					<label class="control-label-popup">&nbsp;&nbsp;<?=lang("label_hours");?>&nbsp;&nbsp;<?=lang("label_hours_info");?></label>
					<div class="clear"></div>
				</div>

				<div class="control-group">
					<label class="control-label control-label-popup float-left" for="start_work_estimated_time"><?=lang("label_due_date");?></label>
					<div class="controls">
						<div class="input-prepend float-left">
							<span class="add-on float-left"><i class="fa fa-calendar"></i></span>
					  		<input type="text" id="start_work_due_date" name="start_work_due_date" class="datepicker input-small" data-date-format="yyyy-mm-dd" />
						</div>
					</div>
					<div class="clear"></div>
				</div>

				<div class="control-group">
					<label class="control-label" for="focusedInput"><?=lang("label_comment");?></label>
					<div class="controls">
						<textarea class="popup_ckeditor tdesc" id="start_work_comment" name="start_work_comment"></textarea>
					</div>
				</div>
			</form>
		</div>

		<div class="modal-footer">
			<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
			<a href="#" class="btn btn-primary" onclick="task_actions.call(this, event, 'start');"><?=lang("btn_save_changes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		</div>
	</div>

	<!-- Complete task dialog box -->
	<div class="modal hide fade in popup_center" id="complete_task_dialog">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3><?=$task->name;?></h3>
		</div>

		<div class="modal-body">
			<form id="complete_task_form">
				<div class="control-group">
					<label class="control-label" for="focusedInput"><?=lang("label_comment");?></label>
					<div class="controls">
						<textarea class="popup_ckeditor tdesc" id="complete_work_comment" name="complete_work_comment"></textarea>
					</div>
				</div>
			</form>
		</div>

		<div class="modal-footer">
			<div class="loader margin-right20"><img src="<?=base_url();?>img/loader.gif" /></div>
			<a href="#" class="btn btn-primary" onclick="task_actions.call(this, event, 'complete');"><?=lang("btn_save_changes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		</div>
	</div>

	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-tasks"></i><span class="break"></span><?=lang("title_task");?> <?=$task->name;?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<div class="row-fluid">
					<div class="span6">
						<h5><?=lang("label_added_by");?></h5>
						<div class="tooltip-demo well">
							<div class="row-fluid">
								<div class="span3">
									<? if ($author_info->picture != "") { ?>
										<img src="<?=base_url();?>uploads/avatars/<?=$author_info->picture;?>" alt="avatar" class="img_task" />
									<? } else { ?>
										<img src="<?=base_url();?>img/no_avatar.png" alt="avatar" class="img_task" />
									<? } ?>
								</div>

								<div class="span9">
									<p><b><?=lang("label_view_name");?></b> <?=$author_info->first_name." ".$author_info->last_name;?></p>
									<p><b><?=lang("label_view_company");?></b> <?=$author_info->comp_name;?></p>
									<p><b><?=lang("label_view_url");?></b> <a href="http://<?=$author_info->homepage;?>" target="_blank"><?=$author_info->homepage;?></a></p>
									<p><b><?=lang("label_view_group");?></b> <?=$author_info->type;?></p>
								</div>
							</div>
						</div>
					</div>

					<div class="span6">
						<h5><?=lang("label_quote");?></h5>
						<div class="tooltip-demo well">
							<? if ($task->estimated_time == 0) { ?>
								<p><b><?=lang("label_view_cost");?></b> <?=lang("status_not_available");?></p>
							<? } else { ?>
						  		<p><b><?=lang("label_view_cost");?></b> <?=$task->estimated_time;?> <?=lang("label_hours");?></p>						  	
						  	<? } 
						  	if ((is_array($developer_info)) && (is_object($developer_info[0]))) 
						  	{   
						  		$developers = "";
						  		$numItems = count($task_assigned);
								$j = 0;

								for ($i = 0; $i < count($developer_info); $i++) 
								{ 
									if (($developer_info[$i]->first_name != "") && ($developer_info[$i]->last_name != "")) 
									{
										if (++$j === $numItems) 
										{	if ($developer_info[$i]->deleted == 'yes')
											{
												$developers .= '<i>'.$developer_info[$i]->first_name." ".$developer_info[$i]->last_name.'</i>';
											}
											else
											{
												$developers .= $developer_info[$i]->first_name." ".$developer_info[$i]->last_name;
											}
										}
										else
										{	if ($developer_info[$i]->deleted == 'yes')
											{
												$developers .= '<i>'.$developer_info[$i]->first_name." ".$developer_info[$i]->last_name."</i>, ";
											}
											else
											{
												$developers .= $developer_info[$i]->first_name." ".$developer_info[$i]->last_name.", ";
											}
										}
									} 
								}
						  	?>
						  		<p><b><?=$user_types[2]->name;?></b>: <?=$developers;?></p>
						  	<? } else { ?>
						  		<p><b><?=$user_types[2]->name;?></b>: <?=lang("status_none");?></p>
						  	<? } ?>
						  	<p><b><?=$user_types[1]->name;?></b>: <? $numItems = count($project_managers_info); $i = 0; foreach ($project_managers_info as $elem) 
						  	{ if (++$i === $numItems) { echo $elem->first_name." ".$elem->last_name; } else { echo $elem->first_name." ".$elem->last_name.", "; } } ?></p>
						  	<? if ($task->status == "Completed") { ?>
						  		<p><b><?=lang("label_view_completed");?></b> <?=$CI->functions->dateFormat($task->complete_date);?></p>
						  	<? } else { ?>
						  		<p class="float-left"><b><?=lang("label_view_added");?></b> <?=$CI->functions->dateFormat($task->create_date);?></p>
						  		<? if ($task->due_date != 0) { ?>
						  			<p class="float-left margin-left20"><b><?=lang("label_view_due_date");?></b> <?=$task->due_date;?></p> 
						  		<? } ?>
						  		<div class="clear"></div>
						  	<? } ?>
						</div>
					</div>
				</div>

				<div class="row-fluid">
					<div class="span12">
						<h5><?=lang("label_desc");?></h5>
						<div class="tooltip-demo well"><?=$task->description;?></div>
					</div>
				</div>

				<? if ($task->attachments != "") { $exist = "yes"; ?>
				<div class="row-fluid">
					<div class="span12">
						<h5><?=lang("label_attachment");?></h5>
						<div class="tooltip-demo well">
							<div class="message">
								<div class="attachments" style="margin: 0px !important;">
									<ul>
										<?
										$attachments 	= substr($task->attachments, 0, -1);
										$att_arr 		= explode(',', $attachments);

										// Download path
										$path = FCPATH.'uploads/';

										foreach ($att_arr as $elem)
										{
											$end_pos 		= strrpos($elem, '.');
											$extension 		= ltrim(substr($elem, $end_pos), '.');
											$label_type		= "";

											if (file_exists($path.$elem))
											{
												$filesize = filesize($path.$elem);

												if ($filesize >= 1048576)
										        {
										            $filesize = number_format($filesize / 1048576, 2) .' MB';
										        }
										        elseif ($filesize >= 1024)
										        {
										            $filesize = number_format($filesize / 1024, 2) .' KB';
										        }
										        elseif ($filesize > 1)
										        {
										            $filesize = $filesize .' bytes';
										        }

										        $extension = strtolower($extension);

										        if ($extension == 'zip' || $extension == 'psd' || $extension == 'ai')
												{
													$label_type = "label-important";
												}
												elseif ($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg')
												{
													$label_type = "label-warning";
												}
												elseif ($extension == 'xls' || $extension == 'xlsx' || $extension == 'doc' || $extension == 'docx' || $extension == 'odt')
												{
													$label_type = "label-success";
												}
												elseif ($extension == 'pdf' || $extension == 'csv' || $extension == 'txt')
												{
													$label_type = "label-info";
												}
												else
												{
													$label_type = "label-info";
												}
										    }
											else
											{
												$filesize = "File does not exist. Please check folder rights!";
												$exist = "no";
											}

											$start_pos 		= $end_pos - 20;
											$stripped_name 	= substr_replace($elem, '', $start_pos, 20); ?>

											<li>
												<span class="label <?=$label_type;?>"><?=$extension;?></span> <b><?=$stripped_name;?></b>&nbsp;&nbsp;<i>(<?=$filesize;?>)</i>
												
												<? if ($exist == "yes") { ?>
													<span class="quickMenu">
														<a href="<?=base_url();?>tasks/downloadAttachment/<?=$elem;?>">
															<span class="add-on"><i class="fa fa-cloud-download"></i></span>
														</a>
													</span>
												<? } ?>
											</li>
										<? } ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<? } ?>

				<div class="control-group text-right margin-top40">
					<span class="float-left"><a href="<?=$back_button_link;?>"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>
					<? if (($task->status == "Assigned") && ($user_type != 4)) { ?>
						<button type="button" class="btn btn-primary" id="start_task_btn" onclick="showDialog.call(this, event, 'start_task_dialog', '', '', '');"><?=lang("btn_quote_task");?></button>
					<? } else if (($task->status == "In Progress") && ($user_type != 4)) { ?>
						<button type="button" class="btn btn-primary" id="complete_task_btn" onclick="showDialog.call(this, event, 'complete_task_dialog', '', '', '');"><?=lang("btn_complete_task");?></button>
					<? } if ($user_type <= 2) { ?>
						<a href="<?=base_url();?>tasks/edit/<?=$task->id;?>"><button type="button" class="btn btn-info"><?=lang("btn_edit_task");?></button></a>
					<? } ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>

	<div class="row-fluid">
		<div class="span12 discussions">
			<ul>
				<li>
					<div class="author">
						<img src="<?=base_url();?>img/logo.png" alt="avatar" />
					</div>
					
					<div class="name"><?=lang("label_system");?></div>
					<? if (is_array($task_assigned)) { ?>
						<div class="date"><?=$CI->functions->datetimeFormatMin($task_assigned[0]->create_date);?></div>
					<? } ?>
					<div class="delete"><i class="fa fa-comments"></i></div>
					
					<? 
					if ( (is_array($task_assigned)) && ($task_assigned[0]->user_id != 0 ) ) 
					{ 
						$developers = "";
						$numItems = count($task_assigned);
						$j = 0;

						for ($i = 0; $i < count($task_assigned); $i++)
						{ 
							if (($task_assigned[$i]->first_name != "") && ($task_assigned[$i]->last_name != "")) 
							{
								if (++$j === $numItems) 
								{
									$developers .= $task_assigned[$i]->first_name." ".$task_assigned[$i]->last_name;
								}
								else
								{
									$developers .= $task_assigned[$i]->first_name." ".$task_assigned[$i]->last_name.", ";
								}
							} 
						}
					?>
						<div class="message"><?=lang("msg_task_assigned_to")." ".$developers;?></div>
					<? } else { ?> 
						<div class="message"><?=lang("msg_task_not_assigned");?></div>
					<? } ?>
					
					<ul>
						<? if (is_array($task_comments)) { foreach ($task_comments as $element) { ?>
							<li>
								<div class="author">
									<? if ($element->picture != "") { ?>
										<img src="<?=base_url();?>uploads/avatars/<?=$element->picture;?>" alt="avatar" />
									<? } else { ?>
										<img src="<?=base_url();?>img/no_avatar.png" alt="avatar" />
									<? } ?>
								</div>
								<div class="name"><?=$element->first_name." ".$element->last_name;?></div>
								<? $old_date = $element->create_date; $new_date = $CI->functions->datetimeFormatMin($old_date); ?>
								
								<div class="date"><?=$new_date;?></div>
								<div class="delete"><i class="fa fa-comment"></i></div>
								<div class="message">
									<div class="message_text">
										<?=$element->comment;?>
									</div>

									<? if (strlen($element->attachments) > 0) { $exist = "yes";?>
									<div class="attachments">
										<ul>
											<?
											$attachments 	= substr($element->attachments, 0, -1);
											$att_arr 		= explode(',', $attachments);

											// Download path
											$path = FCPATH.'uploads/';

											foreach ($att_arr as $elem)
											{
												$end_pos 		= strrpos($elem, '.');
												$extension 		= ltrim(substr($elem, $end_pos), '.');
												$label_type		= "";

												if (file_exists($path.$elem))
												{
													$filesize = filesize($path.$elem);

													if ($filesize >= 1048576)
											        {
											            $filesize = number_format($filesize / 1048576, 2) .' MB';
											        }
											        elseif ($filesize >= 1024)
											        {
											            $filesize = number_format($filesize / 1024, 2) .' KB';
											        }
											        elseif ($filesize > 1)
											        {
											            $filesize = $filesize .' bytes';
											        }

											        $extension = strtolower($extension);

													if ($extension == 'zip' || $extension == 'psd' || $extension == 'ai')
													{
														$label_type = "label-important";
													}
													elseif ($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg')
													{
														$label_type = "label-warning";
													}
													elseif ($extension == 'xls' || $extension == 'xlsx' || $extension == 'doc' || $extension == 'docx' || $extension == 'odt')
													{
														$label_type = "label-success";
													}
													elseif ($extension == 'pdf' || $extension == 'csv' || $extension == 'txt')
													{
														$label_type = "label-info";
													}
													else
													{
														$label_type = "label-info";
													}
												}
												else
												{
													$filesize = "File does not exist. Please check folder rights!";
													$exist = "no";
												}

												$start_pos 		= $end_pos - 20;
												$stripped_name 	= substr_replace($elem, '', $start_pos, 20); ?>

												<li>
													<span class="label <?=$label_type;?>"><?=$extension;?></span> <b><?=$stripped_name;?></b>&nbsp;&nbsp;<i>(<?=$filesize;?>)</i>
													<? if ($exist == "yes") { ?>
														<span class="quickMenu">
															<a href="<?=base_url();?>tasks/downloadAttachment/<?=$elem;?>">
																<span class="add-on"><i class="fa fa-cloud-download"></i></span>
															</a>
														</span>
													<? } ?>
												</li>
											<? } ?>
										</ul>
									</div>
									<? } ?>
								</div>
							</li>
						<? } } ?>

						<li>
							<div class="author">
								<? if ((is_array($user_avatar)) && ($user_avatar->picture != "")) { ?>
									<img src="<?=base_url();?>uploads/avatars/<?=$user_avatar->picture;?>" alt="avatar" />
								<? } else { ?>
									<img src="<?=base_url();?>img/no_avatar.png" alt="avatar" />
								<? } ?>
							</div>

							<textarea class="ckeditor diss-form" id="task_comment" name="task_comment"></textarea>
							<br />

							<form action="<?=base_url();?>tasks/uploadCommentAttachment" id="upload_comment_picture_form" class="dropzone">
								<div class="fallback">
									<input name="file" type="file" multiple="" />
								</div>
								<input type="hidden" name="comment_id" id="comment_id" value="56" />
							</form>
							<div class="span12" style="margin: -15px 0px 0px 0px;"><?=lang("label_allowed_file_types");?></div>

							<input type="hidden" id="client_id" name="client_id" value="<?=$author_info->user_id;?>" />
							<input type="hidden" id="task_id" name="task_id" value="<?=$task_id;?>" />
							<div class="loader loader_center margin-bottom10"><img src="<?=base_url();?>img/loader.gif" /></div>
							<p class="text-center"><a href="#"><button class="addComments btn btn-small btn-primary"><?=lang("btn_send_message");?></button></a></p>
						</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>