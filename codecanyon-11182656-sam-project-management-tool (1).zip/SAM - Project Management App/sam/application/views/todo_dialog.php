<!-- Add To-Do dialog -->
<div class="modal hide fade in popup_center" id="add_todo_all">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
		<h3><?=lang("popup_title_add_todo");?></h3>
	</div>

	<div class="modal-body">
		<form id="add_todo_all_form">
			<div class="control-group">
				<div class="controls">
					<label class="control-label control-label-popup float-left" for="focusedInput"><?=lang("label_due_date");?></label>
					<div class="controls">
						<div class="input-prepend">
							<span class="add-on"><i class="fa fa-calendar"></i></span>
							<input type="text" data-date-format="yyyy-mm-dd" id="todo_due_date_all" name="todo_due_date" class="input-small datepicker" />
						</div>
					</div>
				</div>
			</div>

			<div class="control-group">
				<div class="controls">
					<label class="control-label" for="focusedInput"><?=lang("popup_title_todo");?></label>
				  	<textarea type="text" id="todo_task_all" name="todo_task" class="ckeditor"></textarea>
				</div>
			</div>

			<input type="hidden" name="user_id" value="<?=$user_id;?>" />
		</form>
	</div>

	<div class="modal-footer">
		<a href="#" class="btn btn-primary" onclick="todo_add.call(this, event);"><?=lang("btn_save_changes");?></a>
		<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
	</div>
</div>

<!-- Delete To-Do dialog -->
<div class="modal fade in hide" id="delete_todo_dialog">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
		<h3><?=lang("popup_title_delete_todo");?></h3>
	</div>

	<div class="modal-body">
		<form id="delete_project_form">
			<div class="control-group">
				<div class="controls center_text popup_text">
				  	<h2><?=lang("msg_want_delete_item");?></h2>
				</div>
			</div>
		</form>
	</div>

	<div class="modal-footer center_text">
		<a href="#" class="btn btn-primary" onclick="delete_todo.call(this, event);"><?=lang("btn_yes");?></a>
		<input type="hidden" name="todo_id" id="todo_id" />
		<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
	</div>
</div>