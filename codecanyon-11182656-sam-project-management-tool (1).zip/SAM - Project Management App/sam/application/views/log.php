<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$CI->load->library('functions');
$user_type = $CI->session->userdata('user_type');

if ($user_type != 1)
{
	redirect(base_url().'login');
}
?>

<!-- start: Content -->
<div id="content" class="span10">
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-file-text-o"></i><?=lang("title_log");?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<div class="row-fluid form-horizontal">
					<table class="table table-striped table-bordered" id="log-table">
						<thead>
							<tr role="row">
								<th><?=lang("thead_date");?></th>
								<th><?=lang("thead_text");?></th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>