<?
require_once("top.php");

$CI =& get_instance();
$CI->load->library('session');
$user_id 	= $CI->session->userdata('user_id');
$user_type 	= $CI->session->userdata('user_type');

if ($user_id == "" || $user_id == 0 || $user_id == NULL)
{
	redirect(base_url().'login');
}

?>

<!-- start: Content -->
<!-- Dialog box close project button --> 
<div class="modal fade in hide popup_center" id="close_project_dialog">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
		<h3><?=$project->name;?></h3>
	</div>
	<div class="modal-body">
		<form id="close_project_form">
			<? if ($check_task_in_progress == 0) { ?>
				<div class="control-group">
					<div class="controls center_text">
					  	<h2><?=lang("msg_want_close_project");?></h2>
					</div>
				</div>
			<? } else { ?>
				<div class="control-group">
					<div class="controls center_text">
					  	<h2><?=lang("msg_cannot_close_project");?></h2>
					</div>
				</div>
			<? } ?>
			<input type="hidden" id="project_id" name="project_id" value="<?=$project->id;?>" />
		</form>
	</div>
	<div class="modal-footer center_text">
		<? if ($check_task_in_progress == 0) { ?>
			<a href="#" class="btn btn-primary" onclick="close_project.call(this,event);"><?=lang("btn_yes");?></a>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_no");?></a>
		<? } else { ?>
			<a href="#" class="btn" data-dismiss="modal"><?=lang("btn_close");?></a>
		<? } ?>
	</div>
</div>

<div id="content" class="span10">
	<div class="row-fluid">
		<div class="box span12">
			<div class="box-header">
				<h2><i class="fa fa-list-alt"></i><span class="break"></span><?=lang("title_project");?> <?=$project->name;?></h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>

			<div class="box-content">
				<!-- Progress bar -->
				<h5><?=lang("subtitle_progress_bar");?></h5>
				<div class="progress progress-success" title="<?=$uncompleted_tasks;?>% <?=lang('status_completed');?>">
					<div class="bar" style="width: <?=$uncompleted_tasks;?>%"></div>
				</div>

				<div class="row-fluid">
					<div class="span6">
						<h5><?=lang("subtitle_client");?></h5>
						<div class="tooltip-demo well">
							<div class="row-fluid">
								<? 
									$picture 	= "";
									$name 		= "";
									$comp_name  = "";
									$homepage   = "";
									$since      = "";	

									if (is_array($clients))
									{
										$numItems = count($clients); $i = 0;

										foreach ($clients as $elem) 
										{ 
											if (++$i === $numItems) {
												$name .= $elem->first_name." ".$elem->last_name;
											}
											else
											{
												$name .= $elem->first_name." ".$elem->last_name.", ";
											}
										}

										$picture	= $clients[0]->picture;
										$comp_name  = $clients[0]->comp_name;
										$homepage 	= $clients[0]->homepage;
										$since 		= $clients[0]->since;
									}
								?>
								<div class="span3">
									<? if ($picture == "") { ?>
										<img src="<?=base_url();?>img/no_avatar.png" alt="avatar" class="img_task" />
									<? } else { ?>
										<img src="<?=base_url();?>uploads/avatars/<?=$picture;?>" alt="avatar" class="img_task" />
									<? } ?>
								</div>

								<div class="span9">
									<p><b><?=lang("label_view_name");?></b> <?=$name;?></p>
									<p><b><?=lang("label_view_company");?></b> <?=$comp_name;?></p>
									<p><b><?=lang("label_view_url");?></b> <a href="http://<?=$homepage;?>" target="_blank"><?=$homepage;?></a></p>
									<p><b><?=lang("label_view_since");?></b> <?=$since;?></p>
								</div>
							</div>
						</div>
					</div>

					<div class="span6">
						<h5><?=lang("subtitle_details");?></h5>
						<div class="tooltip-demo well">
							<p><b><?=$user_types[1]->name;?></b>: <? $numItems = count($project_managers_info); $i = 0; foreach ($project_managers_info as $elem) 
						  	{ if (++$i === $numItems) { echo $elem->first_name." ".$elem->last_name; } else { echo $elem->first_name." ".$elem->last_name.", "; } } ?></p>
						  	<p><b><?=lang("label_view_added");?></b> <?=$project->create_date;?></p>
						  	<p><b><?=lang("label_view_due_date");?></b> <?=$project->end_date;?></p>
						  	<p><b><?=lang("label_view_status");?></b> <?=$project->status;?></p>
						</div>
					</div>
				</div>

				<div class="row-fluid">
					<div class="span12">
						<h5><?=lang("subtitle_description");?></h5>
						<div class="tooltip-demo well"><?=$project->description;?></div>
					</div>
				</div>

				<div class="control-group text-right margin-top40">
					<span class="float-left"><a href="<?=base_url();?>projects"><button type="button" class="btn"><?=lang("btn_back");?></button></a></span>
					<? if (($project->status == "In Progress") && ($user_type <= 2)) { ?>
						<button type="button" class="btn btn-primary" onclick="showDialog.call(this, event, 'close_project_dialog', '', '', '');"><?=lang("btn_close_project");?></button>
					<? } ?>
					<? if ($user_type <= 2) { ?>
						<a href="<?=base_url();?>projects/edit/<?=$project->id;?>"><button type="button" class="btn btn-info"><?=lang("btn_edit_project");?></button></a>
					<? } ?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>

<div class="clearfix"></div>

<? require_once("footer.php"); ?>