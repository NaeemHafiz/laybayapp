<script type="text/javascript">
	// Global Vars
	var base_url = "<?=base_url();?>";
	var language_file = "<?=base_url();?>js/translations/<?=$language?>.txt";
</script>