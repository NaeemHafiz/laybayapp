<?php 
	$CI 	= & get_instance();
	$CI->load->library('functions');
	$dev 	= $CI->functions->getUserTypeName(3)->name;
?>

<script type="text/javascript">
	// General
	var lang_select 					= "<?=lang('label_select');?>";

	// Status
	var lang_status_not_assigned 		= "<?=lang('status_not_assigned');?>";
	var lang_status_assigned 			= "<?=lang('status_assigned');?>";
	var lang_status_in_progress 		= "<?=lang('status_in_progress');?>";
	var lang_status_completed 			= "<?=lang('status_completed');?>";
	var lang_status_none 				= "<?=lang('status_none');?>";
	var lang_status_no_data_available 	= "<?=lang('status_no_data_available');?>";
	var lang_confirm_delete_ticket 		= "<?=lang('msg_confirm_delete_ticket')?>";

	// Reports
	var label_date			 			= "<?=lang('label_date');?>";
	var label_developer 				= "<?=$dev;?>:";

	// Clients/Members
	var label_status 					= "<?=lang('label_view_status');?>";
	var label_all 						= "<?=lang('label_all');?>";
	var label_active 					= "<?=lang('label_active');?>";
	var label_inactive 					= "<?=lang('label_inactive');?>";
</script>