<?

// Login & Recover
$lang['lgn_login_account'] 						= "Accedi al tuo account";
$lang['lgn_username'] 							= "Username";
$lang['lgn_password'] 							= "Password";
$lang['lgn_remember_me'] 						= "Ricordami accesso";
$lang['lgn_forgot_pass'] 						= "Password dimenticata?";
$lang['lgn_no_problem'] 						= "Nessun problema,";
$lang['lgn_click_here'] 						= "Fai click qui";
$lang['lgn_get_new_pass'] 						= "per avene una nuova password!";
$lang['lgn_recover_pass'] 						= "Recuperare la tua password";
$lang['lgn_email'] 								= "Email";

// Top
$lang['top_welcome'] 							= "Benvenuto,";
$lang['top_profile'] 							= "Profilo";
$lang['top_transactions'] 						= "Transactions";
$lang['top_logout'] 							= "Esci";

// Menu
$lang['menu_dashboard'] 						= "Dashboard";
$lang['menu_projects'] 							= "Progetti";
$lang['menu_tasks'] 							= "Compiti";
$lang['menu_clients'] 							= "Clienti";
$lang['menu_members'] 							= "Membri";
$lang['menu_reports']							= "Report";
$lang['menu_support_tickets']					= "Richieste di supporto";
$lang['menu_tickets']							= "Tickets";
$lang['menu_tickets_settings']					= "Opzioni Tickets";
$lang['menu_log'] 								= "Log";
$lang['menu_settings'] 							= "Opzioni";

// Buttons
$lang['btn_login'] 								= "Login";
$lang['btn_recover'] 							= "Recupera";
$lang['btn_save_changes'] 						= "Salva Cambiamenti";
$lang['btn_cancel'] 							= "Cancella";
$lang['btn_back'] 								= "Indietro";
$lang['btn_upload'] 							= "Upload";
$lang['btn_cashout'] 							= "Cashout";
$lang['btn_yes'] 								= "Si";
$lang['btn_no'] 								= "No";
$lang['btn_new_project'] 						= "Nuovo Progetto";
$lang['btn_view_tasks'] 						= "Vedi Compiti";
$lang['btn_view'] 								= "Vista";
$lang['btn_edit'] 								= "Modifica";
$lang['btn_disable'] 							= "Disabilita";
$lang['btn_delete'] 							= "Cancella";
$lang['btn_close_project'] 						= "Chiudi Progetto";
$lang['btn_edit_project'] 						= "Modifica Progetto";
$lang['btn_new_task'] 							= "Nuovo Compito";
$lang['btn_close'] 								= "Chiudi";
$lang['btn_quote_task'] 						= "Quota Compito";
$lang['btn_edit_task'] 							= "Modifica Compito";
$lang['btn_complete_task'] 						= "Completa Compito";
$lang['btn_send_message'] 						= "Invia Messaggio";
$lang['btn_new_client'] 						= "Nuovo Cliente";
$lang['btn_new_member'] 						= "Nuovo Membro";
$lang['btn_new_ticket_settings'] 				= "New Ticket Settings";
$lang['btn_answer'] 							= "Risposta";
$lang['btn_generate_script'] 					= "Genera Script";
$lang['btn_generate'] 							= "Genera";
$lang['btn_copy'] 								= "Copia";
$lang['btn_mark_as_read'] 						= "Segna come letto";

// Messages
$lang['msg_changes_saved'] 						= "Salvato!";
$lang['msg_passwords_not_match'] 				= "Le Password non corrispondono!";
$lang['msg_email_already_exist'] 				= "Email già registrata!";
$lang['msg_invalid_password'] 					= "Password non corretta!";
$lang['msg_complete_all_fields'] 				= "Per favore compila tutti i campi!";
$lang['msg_changes_not_saved'] 					= "Errore Salvataggio!";
$lang['msg_invalid_username_password'] 			= "Username o Password errati!";
$lang['msg_new_login_details'] 					= "I dettagli per l'accesso sono stati inviati al tuo indizzo email!";
$lang['msg_pass_changed_not_notified'] 			= "Password cambiata, l'utente non è stato avvisato!";
$lang['msg_pass_not_saved'] 					= "La password non può essere cambiata!";
$lang['msg_email_not_exist'] 					= "Email inesistente!";
$lang['msg_want_delete_project'] 				= "Sei sicuro di voler cancellare questo progetto?";
$lang['msg_want_close_project'] 				= "Sei sicuro di voler chiudere questo progetto?";
$lang['msg_want_delete_task'] 					= "Sei sicuro di voler cancellare questo compito?";
$lang['msg_invalid_cost'] 						= "Prezzo non valido!";
$lang['msg_task_not_completed'] 				= "Il compito non può essere completato!";
$lang['msg_task_assigned_to'] 					= "Compito assegnato a";
$lang['msg_task_not_assigned'] 					= "Compito non ancora assegnato";
$lang['msg_want_disable_client'] 				= "Sei sicuro di voler diabilitare questo cliente?";
$lang['msg_want_delete_client'] 				= "Sei sicuro di voler cancellare questo cliente?";
$lang['msg_username_already_exist'] 			= "Username già esistente!";
$lang['msg_username_and_email_already_exist'] 	= "Username e email già esistenti!";
$lang['msg_want_disable_member'] 				= "Sei sicuro di voler disabilitare questo membro?";
$lang['msg_want_delete_member'] 				= "Sei sicuro di voler cancellare questo membro?";
$lang['msg_want_delete_item'] 					= "Sei sicuro di voler cancellare questo oggetto?";
$lang['msg_name_of_your_company'] 				= "Imposta il nome della tua organizzazione.";
$lang['msg_contact_email'] 						= "Imposta il tuo indirizzo email.";
$lang['msg_accounting_email'] 					= "Impostare l'indirizzo di posta elettronica commercialista.";
$lang['msg_name_for_sending_emails'] 			= "Imposta il nome con cui vuoi inviare i tuoi messaggi email";
$lang['msg_email_for_sending_emails'] 			= "Imposta l'indirizzo email con cui vuoi inviare i messaggi. es. noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Abilita l'invio di notifiche email quando un compito viene assegnato, completato ecc.";
$lang['msg_enable_multi_language'] 				= "Abilita multi-language.";
$lang['msg_show_credits'] 						= "Show 'Powered by IntelCoder' on the right bottom of the page.";
$lang['msg_cannot_close_project'] 				= "È necessario completare tutti i compiti prima di chiudere il progetto!";
$lang['msg_receive_email_notifications'] 		= "Abilita la ricezione di email quando un compito viene assegnato, completato ecc.";
$lang['msg_receive_online_notifications']		= "Abilita la ricezione di notifiche online quando un compito viene assegnato, completato ecc.";
$lang['msg_confirm_delete_ticket'] 				= "Sei sicuro di voler cancellare questo ticket?";
$lang['msg_copied_to_clipboard'] 				= "Script copiato negli appunti!";
$lang['msg_enable_tickets_system'] 				= "Abilita il supporto ticket.";
$lang['msg_want_delete_settings'] 				= "Sei sicuro di voler cancellare questa opzione?";
$lang['msg_generate_private_key'] 				= "Genera una chiave privata per il cliente";
$lang['msg_text_button'] 						= "Imposta il testo per il pulsante di supporto";
$lang['msg_text_color'] 						= "imposta colore per il pulsante di supporto";
$lang['msg_color_button'] 						= "Modifica il colore di sfondo del pulsante di controllo";
$lang['msg_client_domain_url'] 					= "Set the domain where the support tickets will be used. You have to enter the domain without 'http://'. e.g. www.domain.com";
$lang['msg_notified_emails'] 					= "Set one or multiple emails, separated by comma, to receive notifications when support tickets are added.";
$lang['msg_copy_api_script'] 					= "In order to display the support form copy and include this script into your client's website.";
$lang['msg_need_paypal_account'] 				= "To cashout your hours, you need to add a PayPal account on your profile page!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Allowed files: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Immagine Profilo";
$lang['title_edit_profile'] 					= "Modifica Profilo";
$lang['title_personal_settings'] 				= "Impostazioni Profilo";
$lang['subtitle_personal_details'] 				= "Dettagli Profilo";
$lang['subtitle_change_password'] 				= "Cambia Password";
$lang['label_first_name'] 						= "Nome";
$lang['label_last_name'] 						= "Cognome";
$lang['label_email'] 							= "Email";
$lang['label_paypal_email'] 					= "PayPal Email";
$lang['label_phone'] 							= "Telefono";
$lang['label_company'] 							= "Società";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Nazione";
$lang['label_city'] 							= "Città";
$lang['label_language'] 						= "Lingua";
$lang['label_current_pass'] 					= "Password Attuale";
$lang['label_new_pass'] 						= "Nuova Password";
$lang['label_confirm_pass'] 					= "Conferma Password";
$lang['label_email_notifications'] 				= "Notifiche Email";
$lang['label_online_notifications']				= "Notifiche Online";

// Transactions
$lang['title_balance'] 							= "Bilancia";
$lang['title_hours'] 							= "ore";
$lang['title_transactions'] 					= "Transazioni";
$lang['thead_date'] 							= "Data";
$lang['thead_title'] 							= "Titolo";
$lang['thead_debit'] 							= "Debito";
$lang['thead_credit'] 							= "Credito";
$lang['thead_balance'] 							= "Bilancia";
$lang['popup_title_paypal_account'] 			= "PayPal Account";

// Status
$lang['status_not_assigned'] 					= "Non Assegnato";
$lang['status_assigned'] 						= "Assegnato";
$lang['status_in_progress'] 					= "In Esecuzione";
$lang['status_completed'] 						= "Completato";
$lang['status_not_completed'] 					= "Non Completato";
$lang['status_none'] 							= "Nessuno Stato";
$lang['status_no_data_available'] 				= "Nessun dato disponibile";
$lang['status_not_set'] 						= "Non Assegnato";
$lang['status_pending'] 						= "In attesa";
$lang['status_open'] 							= "Aperto";
$lang['status_closed'] 							= "Chiuso";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Cancella da fare";
$lang['popup_title_add_todo'] 					= "Aggiungi da fare";
$lang['popup_title_todo'] 						= "Da Fare";
$lang['db_smallstat_title_projects'] 			= "Progetti";
$lang['db_smallstat_title_tasks'] 				= "Compiti";
$lang['db_smallstat_title_clients'] 			= "Clienti";
$lang['db_smallstat_title_assigned_tasks'] 		= "Compiti Assegnati";
$lang['db_smallstat_title_in_progress'] 		= "Compiti in esecuzione";
$lang['db_smallstat_title_completed'] 			= "Compiti terminati";
$lang['db_smallstat_title_balance'] 			= "Bilancia";
$lang['title_monthly_completed_tasks'] 			= "Compiti completati nel mese da:";
$lang['title_all_tasks'] 						= "Tutti i compiti";
$lang['title_tasks_per_project'] 				= "Compiti / Progetti";
$lang['thead_not_assigned'] 					= "Non Assegnato";
$lang['thead_assigned'] 						= "Assegnato";
$lang['thead_in_progress'] 						= "In Esecuzione";
$lang['title_todo_list'] 						= "Lista da fare";

// Quick Buttons
$lang['title_shortcuts'] 						= "Scorciatoie";

// Bonus
$lang['label_bonus'] 							= "Bonus";

// Projects
$lang['thead_project'] 							= "Progetti";
$lang['thead_client'] 							= "Cliente";
$lang['thead_due_date'] 						= "Data di chiusura";
$lang['thead_status'] 							= "Stato";
$lang['thead_actions'] 							= "Azioni";

// View Project
$lang['title_project'] 							= "Progetto:";
$lang['subtitle_progress_bar'] 					= "Barra di progresso";
$lang['subtitle_client'] 						= "Cliente";
$lang['subtitle_details'] 						= "Dettagli";
$lang['subtitle_description'] 					= "Descrizione";
$lang['label_view_name'] 						= "Nome:";
$lang['label_view_company'] 					= "Società:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Cliente da:";
$lang['label_view_added'] 						= "Aggiunto:";
$lang['label_view_due_date'] 					= "Data di completamento:";
$lang['label_view_status'] 						= "Stato:";

// Add Project
$lang['title_new_project'] 						= "Nuovo Progetto";

// Edit Project
$lang['title_edit_project'] 					= "Modifica Progetto";
$lang['label_title'] 							= "Titolo";
$lang['label_desc'] 							= "Descrizione";
$lang['label_due_date'] 						= "Data di chiusura";
$lang['label_client'] 							= "Cliente";

// Tasks per Project
$lang['title_tasks_for'] 						= "Compiti per";
$lang['thead_task'] 							= "Compito";
$lang['thead_added'] 							= "Aggiunto";
$lang['thead_due_date'] 						= "Data di completamento";
$lang['thead_completed'] 						= "Completato";
$lang['thead_developer'] 						= "Sviluppatore";

// My Tasks
$lang['title_managed_tasks']					= "Compiti";
$lang['title_in_progress_tasks'] 				= "Compiti in esecuzione";
$lang['title_completed_tasks'] 					= "Compiti Completati";
$lang['tooltip_urgent'] 						= "Urgente";
$lang['tooltip_high']							= "Alta Priorità";

// View Task
$lang['title_task'] 							= "Compito:";
$lang['label_cost'] 							= "Costo";
$lang['label_hours'] 							= "ore";
$lang['label_hours_info'] 						= "(0.5 = 30 minuti)";
$lang['label_comment'] 							= "Commenta";
$lang['label_added_by'] 						= "Aggiunto da";
$lang['label_view_group'] 						= "Gruppo:";
$lang['label_view_cost'] 						= "Costo:";
$lang['status_not_available'] 					= "Non ancora disponibile";
$lang['label_view_completed'] 					= "Completato:";
$lang['label_quote'] 							= "Cita";
$lang['label_system'] 							= "Sistema";
$lang['label_no_attachment'] 					= "Nessun allegato";

// Add Task
$lang['title_new_task'] 						= "Nuovo Compito";
$lang['label_project'] 							= "Progetto";
$lang['label_attachment']						= "Allegato(i)";
$lang['label_priority']							= "Priorità";
$lang['label_select'] 							= "Seleziona";

// Edit Task
$lang['title_edit_task'] 						= "Modifica compito";

// Clients
$lang['title_clients'] 							= "Clienti";
$lang['thead_name'] 							= "Nome";
$lang['thead_email'] 							= "Email";
$lang['thead_company'] 							= "Società";

// Add Client
$lang['title_new_client'] 						= "Nuovo Cliente";
$lang['label_username'] 						= "Username";
$lang['label_pass'] 							= "Password";
$lang['title_last_clients'] 					= "Ultimi Clienti";
$lang['label_send_email'] 						= "Invia Email";

// Edit Client
$lang['title_edit_client'] 						= "Modifica Cliente";

// Members
$lang['title_members'] 							= "Membri";
$lang['thead_group'] 							= "Gruppo";
$lang['label_all'] 								= "Tutti";

// Add Member
$lang['title_new_member'] 						= "Nuovo Membro";
$lang['label_group'] 							= "Gruppo";
$lang['label_hourly_rate'] 						= "Tariffa oraria";
$lang['label_per_hour'] 						= "/ora";

// Edit Member
$lang['title_edit_member'] 						= "Modifica Membro";

// Reports
$lang['title_reports']							= "Reports";
$lang['title_nr_tasks_per'] 					= "# di Compiti /";
$lang['title_tasks_per']						= "Compiti /";
$lang['label_date'] 							= "Data:";
$lang['thead_hours'] 							= "Ora";

// Tickets
$lang['title_tickets'] 							= "Tickets";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Oggetto";
$lang['thead_added_by'] 						= "Aggunto da";

// View Ticket
$lang['title_ticket'] 							= "Ticket:";
$lang['label_details']							= "Dettagli";
$lang['label_view_email']						= "Email:";
$lang['label_view_phone']						= "Telefono:";
$lang['label_view_type']						= "Tipo:";
$lang['label_view_app_url']						= "Link URL:";
$lang['label_subject'] 							= "Oggetto:";
$lang['label_message']							= "Messaggio:";
$lang['label_answered_by'] 						= "Risposto da";
$lang['label_closed_by'] 						= "Chiuso da";
$lang['label_type_problem'] 					= "Problema";
$lang['label_type_question'] 					= "Domanda";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Opzioni Tickets";
$lang['label_active'] 							= "Attivo";
$lang['label_inactive'] 						= "Non Attivo";
$lang['label_text_button'] 						= "Testo del tasto";
$lang['label_text_color'] 						= "Colore del testo";
$lang['label_button_color']						= "Colore del tasto";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Nuove Impostazioni";
$lang['label_app_url'] 							= "App URL";
$lang['label_private_key']						= "Private Key";
$lang['label_api_script']						= "API Script";
$lang['label_notified_emails'] 					= "Email notificate";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Modifica impostazioni";

// Notifications
$lang['thead_type'] 							= "Tipo";
$lang['thead_message'] 							= "Messaggio";
$lang['title_notifications'] 					= "Notifiche";
$lang['last_notifications'] 					= "Ultime Notifiche";
$lang['view_all_notifications'] 				= "Vedi tutte le notifiche";
$lang['no_notifications'] 						= "Non ha nuove notifiche";

// Log
$lang['title_log'] 								= "Log";
$lang['thead_text'] 							= "Testo";

// Settings
$lang['title_settings'] 						= "Impostazioni";
$lang['title_general'] 							= "Generali";
$lang['title_groups'] 							= "Gruppi";
$lang['label_contact_email'] 					= "Email di contatto";
$lang['label_accounting_email'] 				= "Email di contabilità";
$lang['label_sender_name'] 						= "Mittente";
$lang['label_sender_email'] 					= "Email mittente";
$lang['label_enable_emails'] 					= "Attiva Emails";
$lang['label_multi_language'] 					= "Attiva multi-lingue";
$lang['label_show_credits'] 					= "Mostra crediti";
$lang['label_information'] 						= "Informazioni";
$lang['label_group'] 							= "Gruppo";
$lang['label_enable_tickets'] 					= "Abilita sistema ticket";

?>