<?

// Login & Recover
$lang['lgn_login_account'] 						= "Belépés";
$lang['lgn_username'] 							= "Felhasználónév";
$lang['lgn_password'] 							= "Jelszó";
$lang['lgn_remember_me'] 						= "Maradjak belépve";
$lang['lgn_forgot_pass'] 						= "Elfelejtette a jelszavát?";
$lang['lgn_no_problem'] 						= "Semmi gond,";
$lang['lgn_click_here'] 						= "kattintson ide";
$lang['lgn_get_new_pass'] 						= "egy új jelszóert!";
$lang['lgn_recover_pass'] 						= "Jelszó-pótlás";
$lang['lgn_email'] 								= "Email";

// Top
$lang['top_welcome'] 							= "Hello,";
$lang['top_profile'] 							= "Profil";
$lang['top_transactions'] 						= "Tranzakciók";
$lang['top_logout'] 							= "Kijelentkezés";

// Menu
$lang['menu_dashboard'] 						= "Dashboard";
$lang['menu_projects'] 							= "Projektek";
$lang['menu_tasks'] 							= "Saját feladatok";
$lang['menu_clients'] 							= "Ügyfelek";
$lang['menu_members'] 							= "Tagok";
$lang['menu_reports']							= "Beszámolók";
$lang['menu_support_tickets']					= "Hibajegy";
$lang['menu_tickets']							= "Tikett";
$lang['menu_tickets_settings']					= "Tikett beallítások";
$lang['menu_log'] 								= "Műveleti napló";
$lang['menu_settings'] 							= "Beállítások";

// Buttons
$lang['btn_login'] 								= "Belépés";
$lang['btn_recover'] 							= "Visszaszerez";
$lang['btn_save_changes'] 						= "Mentés";
$lang['btn_cancel'] 							= "Mégsem";
$lang['btn_back'] 								= "Vissza";
$lang['btn_upload'] 							= "Feltölt";
$lang['btn_cashout'] 							= "Kivenni";
$lang['btn_yes'] 								= "Igen";
$lang['btn_no'] 								= "Nem";
$lang['btn_new_project'] 						= "Új projekt";
$lang['btn_view_tasks'] 						= "Feladatok megtekintése";
$lang['btn_view'] 								= "Megnéz";
$lang['btn_edit'] 								= "Szerkeszt";
$lang['btn_disable'] 							= "Letilt";
$lang['btn_delete'] 							= "Töröl";
$lang['btn_close_project'] 						= "Bezár";
$lang['btn_edit_project'] 						= "Szerkeszt";
$lang['btn_new_task'] 							= "Új feladat";
$lang['btn_close'] 								= "Bezár";
$lang['btn_quote_task'] 						= "Feladat értékelése";
$lang['btn_edit_task'] 							= "Szerkeszt";
$lang['btn_complete_task'] 						= "Bezár";
$lang['btn_send_message'] 						= "Üzenet küldése";
$lang['btn_new_client'] 						= "Új ügyfél";
$lang['btn_new_member'] 						= "Új tag";
$lang['btn_new_ticket_settings'] 				= "Új tikett beállítások";
$lang['btn_answer'] 							= "Válaszolj";
$lang['btn_generate_script'] 					= "Szkript generálás";
$lang['btn_generate'] 							= "Generál";
$lang['btn_copy'] 								= "Másol";
$lang['btn_mark_as_read'] 						= "Megjelölés olvasottként";

// Messages
$lang['msg_changes_saved'] 						= "Sikeres mentés!";
$lang['msg_passwords_not_match'] 				= "A jelszavak nem egyeznek!";
$lang['msg_email_already_exist'] 				= "A megadott E-mail már létezik!";
$lang['msg_invalid_password'] 					= "Érvénytelen jelszó!";
$lang['msg_complete_all_fields'] 				= "Kérjük, töltse ki az összes mezőt!";
$lang['msg_changes_not_saved'] 					= "Mentés sikertelen!";
$lang['msg_invalid_username_password'] 			= "Érvénytelen felhasználónév vagy jelszó!";
$lang['msg_new_login_details'] 					= "Az új bejelentkezési adatokat elküldtük a megadott e-mail címre!";
$lang['msg_pass_changed_not_notified'] 			= "Jelszó megváltoztatva, a felhasználót nem lehetett értesíteni!";
$lang['msg_pass_not_saved'] 					= "Jelszót nem lehetett megváltoztatni!";
$lang['msg_email_not_exist'] 					= "Az e-mail cím nem létezik!";
$lang['msg_want_delete_project'] 				= "Biztos benne, hogy törli ezt a projektet?";
$lang['msg_want_close_project'] 				= "Biztos benne, hogy bezárja ezt a projektet?";
$lang['msg_want_delete_task'] 					= "Biztos benne, hogy törli ezt a feladatot?";
$lang['msg_invalid_cost'] 						= "Hibás értékelés!";
$lang['msg_task_not_completed'] 				= "A feladatot nem lehet befejezni!";
$lang['msg_task_assigned_to'] 					= "Feladatra kijelölve";
$lang['msg_task_not_assigned'] 					= "A feladatra nem létezik kijelölt";
$lang['msg_want_disable_client'] 				= "Biztos benne, hogy letiltja ezt az ügyfelet?";
$lang['msg_want_delete_client'] 				= "Biztos benne, hogy törli ezt az ügyfelet?";
$lang['msg_username_already_exist'] 			= "Felhasználónév már létezik!";
$lang['msg_username_and_email_already_exist'] 	= "Felhasználónév és e-mail már létezik!";
$lang['msg_want_disable_member'] 				= "Biztos benne, hogy letiltja ezt a tagot?";
$lang['msg_want_delete_member'] 				= "Biztos benne, hogy törli ezt a tagot?";
$lang['msg_want_delete_item'] 					= "Biztos benne, hogy törli ezt az elemet?";
$lang['msg_name_of_your_company'] 				= "Töltse ki a cég nevét.";
$lang['msg_contact_email'] 						= "Elérhetőségi email cím beállítása.";
$lang['msg_accounting_email'] 					= "Állítsa email cím könyvelő.";
$lang['msg_name_for_sending_emails'] 			= "E-mail küldésére használt nevét állitsa be. pld. Company Name";
$lang['msg_email_for_sending_emails'] 			= "E-mail küldésére használt email címét állitsa be. pld. noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Engedélyezze az email küldését amikor a feladat ki lett jelölve, be lett fejezve, stb.";
$lang['msg_enable_multi_language'] 				= "Engedélyezze a többnyelvű lehetőséget a profil oldalon.";
$lang['msg_show_credits'] 						= "Jelenítse meg 'Powered by IntelCoder' a jobb oldalon a lap alján.";
$lang['msg_cannot_close_project'] 				= "Be kell, hogy fejezze az összes feladatot, hogy bezárhassa a projektet!";
$lang['msg_receive_email_notifications'] 		= "Email-ben értesítés bekapcolása. Email-ben jön majd értesítés a következő esetekben: feladat befejezése, feladat kijelölése, stb.";
$lang['msg_receive_online_notifications']		= "Weboldal értesítés bekapcolása. Értesítés jön a következő esetekben: feladat befejezése, feladat kijelölése, stb.";
$lang['msg_confirm_delete_ticket'] 				= "Biztos benne, hogy törli ezt a tikettet?";
$lang['msg_copied_to_clipboard'] 				= "Script kimásolva!";
$lang['msg_enable_tickets_system'] 				= "Jegy rendszer bekapcsolása.";
$lang['msg_want_delete_settings'] 				= "Biztos törölni akarod ezt a beállítást?";
$lang['msg_generate_private_key'] 				= "Egyedi kulcs generálása az ügyfél számára.";
$lang['msg_text_button'] 						= "Gomb címke beállítása.";
$lang['msg_text_color'] 						= "Gomb címke színének beállítása.";
$lang['msg_color_button'] 						= "Gomb színének beállítása.";
$lang['msg_client_domain_url'] 					= "Ügyfél weboldal címének meghatározása. A cím a kovetkezo keppen kell kinézzen: www.domain.com";
$lang['msg_notified_emails'] 					= "Email címek meghatározása, ahov az értesítések erkeznek. Tobb cím eseten vesszovel valaszuk el oket.";
$lang['msg_copy_api_script'] 					= "A támogatási űrlap megjelenítesere illesze be a kod-ot az ügyfél weboldalára.";
$lang['msg_need_paypal_account'] 				= "A ledolgozott orak kifizetesehez be kell alitania a PayPal felhasznaloi email cimet az on profil oldalan!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Engedélyezett fájltípusok: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Profil kép";
$lang['title_edit_profile'] 					= "Profil szerkesztés";
$lang['title_personal_settings'] 				= "Szamélyes beállítások";
$lang['subtitle_personal_details'] 				= "Személyes adatok";
$lang['subtitle_change_password'] 				= "Jelszó módosítása";
$lang['label_first_name'] 						= "Keresztnév";
$lang['label_last_name'] 						= "Vezetéknév";
$lang['label_email'] 							= "Email";
$lang['label_paypal_email'] 					= "PayPal Email";
$lang['label_phone'] 							= "Telefonszám";
$lang['label_company'] 							= "Vállalat neve";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Ország";
$lang['label_city'] 							= "Város";
$lang['label_language'] 						= "Nyelv";
$lang['label_current_pass'] 					= "Jelenlegi jelszó";
$lang['label_new_pass'] 						= "Új jelszó";
$lang['label_confirm_pass'] 					= "Jelszó megerősítése";
$lang['label_email_notifications'] 				= "Értesítés Email-en";
$lang['label_online_notifications']				= "Értesítés Weboldalon";

// Transactions
$lang['title_balance'] 							= "Egyenleg";
$lang['title_hours'] 							= "Óra szám";
$lang['title_transactions'] 					= "Tranzakciók";
$lang['thead_date'] 							= "Dátum";
$lang['thead_title'] 							= "Cím";
$lang['thead_debit'] 							= "Kimenö összeg";
$lang['thead_credit'] 							= "Bejövö összeg";
$lang['thead_balance'] 							= "Egyenleg";
$lang['popup_title_paypal_account'] 			= "PayPal Számla";

// Status
$lang['status_not_assigned'] 					= "Nincs kijelölve";
$lang['status_assigned'] 						= "Kijelölve";
$lang['status_in_progress'] 					= "Folyamatban";
$lang['status_completed'] 						= "Befejezve";
$lang['status_not_completed'] 					= "Befejezetlen";
$lang['status_none'] 							= "Nem létezik";
$lang['status_no_data_available'] 				= "Nincs adat";
$lang['status_not_set'] 						= "Nincs beállítva";
$lang['status_pending'] 						= "Folyamatban";
$lang['status_open'] 							= "Nyitva";
$lang['status_closed'] 							= "Zarva";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Tennivaló törlése";
$lang['popup_title_add_todo'] 					= "Tennivaló hozzáadása";
$lang['popup_title_todo'] 						= "Tennivaló";
$lang['db_smallstat_title_projects'] 			= "Projektek";
$lang['db_smallstat_title_tasks'] 				= "Feladatok";
$lang['db_smallstat_title_clients'] 			= "Ügyfelek";
$lang['db_smallstat_title_assigned_tasks'] 		= "Kijelölt feladatok";
$lang['db_smallstat_title_in_progress'] 		= "Folyamatban lévő feladatok";
$lang['db_smallstat_title_completed'] 			= "Befejezet feladatok";
$lang['db_smallstat_title_balance'] 			= "Egyenleg";
$lang['title_monthly_completed_tasks'] 			= "Honaponta befejezett feladatok -> ";
$lang['title_all_tasks'] 						= "Minden feladatok";
$lang['title_tasks_per_project'] 				= "Feladatok projektenként";
$lang['thead_not_assigned'] 					= "Nincs kijelölve";
$lang['thead_assigned'] 						= "Kijelölve";
$lang['thead_in_progress'] 						= "Folyamatban";
$lang['title_todo_list'] 						= "Tennivalók lista";

// Quick Buttons
$lang['title_shortcuts'] 						= "Rövidítések";

// Bonus
$lang['label_bonus'] 							= "Bónusz";

// Projects
$lang['thead_project'] 							= "Projekt";
$lang['thead_client'] 							= "Ügyfél";
$lang['thead_due_date'] 						= "Határidő";
$lang['thead_status'] 							= "Állapot";
$lang['thead_actions'] 							= "Műveletek";

// View Project
$lang['title_project'] 							= "Projekt:";
$lang['subtitle_progress_bar'] 					= "Állapotjelző";
$lang['subtitle_client'] 						= "Ügyfél";
$lang['subtitle_details'] 						= "Részletek";
$lang['subtitle_description'] 					= "Leírás";
$lang['label_view_name'] 						= "Név:";
$lang['label_view_company'] 					= "Vállalat:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Regisztrált:";
$lang['label_view_added'] 						= "Hozzáadva:";
$lang['label_view_due_date'] 					= "Határidő:";
$lang['label_view_status'] 						= "Állapot:";

// Add Project
$lang['title_new_project'] 						= "Új projekt";

// Edit Project
$lang['title_edit_project'] 					= "Szerkeszt";
$lang['label_title'] 							= "Cím";
$lang['label_desc'] 							= "Leírás";
$lang['label_due_date'] 						= "Hozzáadva";
$lang['label_client'] 							= "Ügyfél";

// Tasks per Project
$lang['title_tasks_for'] 						= "Feladatok -> ";
$lang['thead_task'] 							= "Feladat";
$lang['thead_added'] 							= "Hozzáadva";
$lang['thead_due_date'] 						= "Határidő";
$lang['thead_completed'] 						= "Befejezve";
$lang['thead_developer'] 						= "Fejlesztő";

// My Tasks
$lang['title_managed_tasks']					= "Kezelt Feladatok";
$lang['title_in_progress_tasks'] 				= "Folyamatban lévő feladatok";
$lang['title_completed_tasks'] 					= "Befejezet feladatok";
$lang['tooltip_urgent'] 						= "Sürgős";
$lang['tooltip_high']							= "Magas";

// View Task
$lang['title_task'] 							= "Feladat:";
$lang['label_cost'] 							= "Kivitelezési ár";
$lang['label_hours'] 							= "óra";
$lang['label_hours_info'] 						= "(0.5 = 30 perc)";
$lang['label_comment'] 							= "Hozzászólás";
$lang['label_added_by'] 						= "Hozzáadta";
$lang['label_view_group'] 						= "Csoport:";
$lang['label_view_cost'] 						= "Kivitelezési ár:";
$lang['status_not_available'] 					= "Nincs megadva";
$lang['label_view_completed'] 					= "Befejezett:";
$lang['label_quote'] 							= "Értékel";
$lang['label_system'] 							= "Rendszer";
$lang['label_no_attachment'] 					= "Nincs melléklet";

// Add Task
$lang['title_new_task'] 						= "Új feladat";
$lang['label_project'] 							= "Projekt";
$lang['label_attachment']						= "Melléklet(ek)";
$lang['label_priority']							= "Prioritás";
$lang['label_select'] 							= "Válassz";

// Edit Task
$lang['title_edit_task'] 						= "Szerkeszt";

// Clients
$lang['title_clients'] 							= "Ügyfelek";
$lang['thead_name'] 							= "Név";
$lang['thead_email'] 							= "Email";
$lang['thead_company'] 							= "Vállalat";

// Add Client
$lang['title_new_client'] 						= "Új ügyfél";
$lang['label_username'] 						= "Felhasználónév";
$lang['label_pass'] 							= "Jelszó";
$lang['title_last_clients'] 					= "Utolsó ügyfelek";
$lang['label_send_email'] 						= "Email Küldes";

// Edit Client
$lang['title_edit_client'] 						= "Szerkeszt";

// Members
$lang['title_members'] 							= "Tagok";
$lang['thead_group'] 							= "Csoport";
$lang['label_all'] 								= "Mind";

// Add Member
$lang['title_new_member'] 						= "Új tag";
$lang['label_group'] 							= "Csoport";
$lang['label_hourly_rate'] 						= "Óradíj";
$lang['label_per_hour'] 						= "/óra";

// Edit Member
$lang['title_edit_member'] 						= "Szerkeszt";

// Reports
$lang['title_reports']							= "Beszámolók";
$lang['title_nr_tasks_per'] 					= "# Feladat /";
$lang['title_tasks_per']						= "Feladatok /";
$lang['label_date'] 							= "Dátum:";
$lang['thead_hours'] 							= "Óraszám";

// Tickets
$lang['title_tickets'] 							= "Tikettek";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Téma";
$lang['thead_added_by'] 						= "Hozzáadta";

// View Ticket
$lang['title_ticket'] 							= "Tikett:";
$lang['label_details']							= "Részletek";
$lang['label_view_email']						= "Email:";
$lang['label_view_phone']						= "Telefon:";
$lang['label_view_type']						= "Típus:";
$lang['label_view_app_url']						= "Alkalmazás URL:";
$lang['label_subject'] 							= "Téma:";
$lang['label_message']							= "Üzenet";
$lang['label_answered_by'] 						= "Választ Írta";
$lang['label_closed_by'] 						= "Bezárta";
$lang['label_type_problem'] 					= "Probléma";
$lang['label_type_question'] 					= "Kérdés";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Tikett Beállítások";
$lang['label_active'] 							= "Aktív";
$lang['label_inactive'] 						= "Tétlen";
$lang['label_text_button'] 						= "Gomb Felirat";
$lang['label_text_color'] 						= "Szoveg Színe";
$lang['label_button_color']						= "Gomb Színe";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Új Beállítás";
$lang['label_app_url'] 							= "Alkalmazás URL";
$lang['label_private_key']						= "Egyedi Kulcs";
$lang['label_api_script']						= "API Script";
$lang['label_notified_emails'] 					= "Értesített emails";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Beállítás Módosítása";

// Notifications
$lang['thead_type'] 							= "Tipus";
$lang['thead_message'] 							= "Üzenet";
$lang['title_notifications'] 					= "Értesítés";
$lang['last_notifications'] 					= "Utolsó értesítések";
$lang['view_all_notifications'] 				= "Tekintsd meg az ősszes értesítést";
$lang['no_notifications'] 						= "Jeleneg 0 értesítés van";

// Log
$lang['title_log'] 								= "Műveleti napló";
$lang['thead_text'] 							= "Szöveg";

// Settings
$lang['title_settings'] 						= "Beállítások";
$lang['title_general'] 							= "Általános";
$lang['title_groups'] 							= "Csoportok";
$lang['label_contact_email'] 					= "Elérhetőségi email cím";
$lang['label_accounting_email'] 				= "Email számviteli";
$lang['label_sender_name'] 						= "Feladó neve";
$lang['label_sender_email'] 					= "Feladó email címe";
$lang['label_enable_emails'] 					= "Emailek küldése";
$lang['label_multi_language'] 					= "Többnyelvü felhasználói felület";
$lang['label_show_credits'] 					= "Fejlesztö megjelenítése";
$lang['label_information'] 						= "Információ";
$lang['label_group'] 							= "Csoport";
$lang['label_enable_tickets'] 					= "Jegy rendszer bekapcsolás";

?>