<?

// Login & Recover
$lang['lgn_login_account'] 						= "Hesabınıza giriş yapın";
$lang['lgn_username'] 							= "Kullanıcı adı";
$lang['lgn_password'] 							= "Şifre";
$lang['lgn_remember_me'] 						= "Beni hatırla";
$lang['lgn_forgot_pass'] 						= "Şifrenizi mi unuttunuz?";
$lang['lgn_no_problem'] 						= "Sorun değil";
$lang['lgn_click_here'] 						= "Buraya Tıklayın";
$lang['lgn_get_new_pass'] 						= "yeni bir şifre almak için!";
$lang['lgn_recover_pass'] 						= "Şifrenizi geri yükleyin";
$lang['lgn_email'] 								= "E-posta";

// Top
$lang['top_welcome'] 							= "Hoş geldiniz";
$lang['top_profile'] 							= "Profil";
$lang['top_transactions'] 						= "İşlemler";
$lang['top_logout'] 							= "Oturumu Kapat";

// Menu
$lang['menu_dashboard'] 						= "Kontrol paneli";
$lang['menu_projects'] 							= "Projeler";
$lang['menu_tasks'] 							= "Görevlerim";
$lang['menu_clients'] 							= "Müşteriler";
$lang['menu_members'] 							= "Üyeler";
$lang['menu_reports'] 							= "Raporlar";
$lang['menu_support_tickets'] 					= "Destek Talepleri";
$lang['menu_tickets'] 							= "Bildirimler";
$lang['menu_tickets_settings'] 					= "Bildirim Ayarları";
$lang['menu_log'] 								= "Kayıt";
$lang['menu_settings'] 							= "Ayarlar";

// Buttons
$lang['btn_login'] 								= "Giriş";
$lang['btn_recover'] 							= "Kurtar";
$lang['btn_save_changes'] 						= "Değişiklikleri Kaydet";
$lang['btn_cancel'] 							= "İptal";
$lang['btn_back'] 								= "Geri";
$lang['btn_upload'] 							= "Yükle";
$lang['btn_cashout'] 							= "Nakit para yatırma";
$lang['btn_yes'] 								= "Evet";
$lang['btn_no'] 								= "Hayır";
$lang['btn_new_project'] 						= "Yeni Proje";
$lang['btn_view_tasks'] 						= "Görevleri Görüntüle";
$lang['btn_view'] 								= "Görünüm";
$lang['btn_edit'] 								= "Düzenle";
$lang['btn_disable'] 							= "Devre Dışı Bırak";
$lang['btn_delete'] 							= "Sil";
$lang['btn_close_project'] 						= "Projeyi Kapat";
$lang['btn_edit_project'] 						= "Projeyi Düzenle";
$lang['btn_new_task'] 							= "Yeni Görev";
$lang['btn_close'] 								= "Kapat";
$lang['btn_quote_task'] 						= "Alıntı Görevi";
$lang['btn_edit_task'] 							= "Görevi Düzenle";
$lang['btn_complete_task'] 						= "Tamamlanmış Görev";
$lang['btn_send_message'] 						= "Mesaj Gönder";
$lang['btn_new_client'] 						= "Yeni Müşteri";
$lang['btn_new_member'] 						= "Yeni Üye";
$lang['btn_new_ticket_settings'] 				= "Yeni Destek Talebi Ayarları";
$lang['btn_answer'] 							= "Cevapla";
$lang['btn_generate_script'] 					= "Komut dosyası oluştur";
$lang['btn_generate'] 							= "Oluşturun";
$lang['btn_copy'] 								= "Kopyala";
$lang['btn_mark_as_read'] 						= "Okundu Olarak İşaretle";

// Messages
$lang['msg_changes_saved'] 						= "Değişiklikler başarıyla kaydedildi!";
$lang['msg_passwords_not_match'] 				= "Parolalar eşleşmiyor!";
$lang['msg_email_already_exist'] 				= "E-posta zaten var!";
$lang['msg_invalid_password'] 					= "Geçersiz geçerli şifre!";
$lang['msg_complete_all_fields'] 				= "Lütfen tüm alanları doldurun!";
$lang['msg_changes_not_saved'] 					= "Değişiklikler kaydedilemedi!";
$lang['msg_invalid_username_password'] 			= "Geçersiz kullanıcı adı veya şifre!";
$lang['msg_new_login_details'] 					= "Yeni oturum açma bilgileriniz e-posta adresinize gönderildi!";
$lang['msg_pass_changed_not_notified'] 			= "Şifre değiştirildi, kullanıcıya bildirim yapılmadı!";
$lang['msg_pass_not_saved'] 					= "Parola değiştirilemedi!";
$lang['msg_email_not_exist'] 					= "E-posta adresi mevcut değil!";
$lang['msg_want_delete_project'] 				= "Bu projeyi silmek istediğinizden emin misiniz?";
$lang['msg_want_close_project'] 				= "Bu projeyi kapatmak istediğinizden emin misiniz?";
$lang['msg_want_delete_task'] 					= "Bu görevi silmek istediğinizden emin misiniz?";
$lang['msg_invalid_cost'] 						= "Geçersiz maliyet!";
$lang['msg_task_not_completed'] 				= "Görev tamamlanamadı!";
$lang['msg_task_assigned_to'] 					= "Göreve atandı";
$lang['msg_task_not_assigned'] 					= "Görev henüz atanmadı";
$lang['msg_want_disable_client'] 				= "Bu Müşteriyi devre dışı bırakmak istediğinizden emin misiniz?";
$lang['msg_want_delete_client'] 				= "Bu Müşteriyi silmek istediğinizden emin misiniz?";
$lang['msg_username_already_exist'] 			= "Kullanıcı adı zaten var!";
$lang['msg_username_and_email_already_exist'] 	= "Kullanıcı adı ve e-posta zaten var!";
$lang['msg_want_disable_member'] 				= "Bu üyeyi devre dışı bırakmak istediğinizden emin misiniz?";
$lang['msg_want_delete_member'] 				= "Bu üyeyi silmek istediğinizden emin misiniz?";
$lang['msg_want_delete_item'] 					= "Bu öğeyi silmek istediğinizden emin misiniz?";
$lang['msg_name_of_your_company'] 				= "Şirketinizin adını ayarlayın.";
$lang['msg_contact_email'] 						= "İletişim e-posta adresini ayarlayın.";
$lang['msg_accounting_email'] 					= "Set the accountant email address.";
$lang['msg_name_for_sending_emails'] 			= "E-posta göndermek için kullanılmak istenen ismi ayarlayın; ör. Şirket Adı";
$lang['msg_email_for_sending_emails'] 			= "E-posta gönderirken kullanmak istediğiniz e-posta adresini ayarlayın; ör. Noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Görevler atandığında, tamamlandığında e-postaları göndermeyi etkinleştir";
$lang['msg_enable_multi_language'] 				= "Profil sayfasındaki çok dilli seçeneği etkinleştirin.";
$lang['msg_show_credits'] 						= "Sayfanın sağ alt köşesinde Ayyıldız Software ile Güçlendirilmiş göster.";
$lang['msg_cannot_close_project'] 				= "Projeyi kapatmak için tüm görevleri tamamlamanız gerekiyor!";
$lang['msg_receive_email_notifications'] 		= "Görevler eklendiğinde, tamamlandığında e-postaları almaya izin ver";
$lang['msg_receive_online_notifications'] 		= "Görevler eklendiğinde, tamamlandığında çevrimiçi bildirim almayı etkinleştirin vb.";
$lang['msg_confirm_delete_ticket'] 				= "Bu Destek Talebini silmek istediğinizden emin misiniz?";
$lang['msg_copied_to_clipboard'] 				= "Komut dosyası panoya kopyalanmış!";
$lang['msg_enable_tickets_system'] 				= "Destek Talebi sistemini etkinleştirin.";
$lang['msg_want_delete_settings'] 				= "Bu ayarı silmek istediğinizden emin misiniz?";
$lang['msg_generate_private_key'] 				= "Müşteriniz için özel anahtar oluşturun.";
$lang['msg_text_button'] 						= "Destek düğmesi için metin ayarla.";
$lang['msg_text_color'] 						= "Destek düğmesinin metin rengini ayarlayın.";
$lang['msg_color_button'] 						= "Destek düğmesinin arka plan rengini ayarla.";
$lang['msg_client_domain_url'] 					= "Destek Taleplerinin kullanılacağı alanı ayarla: 'http: //' olmadan alan adını girmelisin, örn. Www.domain.com";
$lang['msg_notified_emails'] 					= "Destek Talepleri eklendiğinde bildirim almak için virgülle ayrılmış bir veya daha fazla e-posta ayarlayın.";
$lang['msg_copy_api_script'] 					= "Destek formunu görüntülemek için kopyala ve bu betiği müşterinin web sitesine ekle.";
$lang['msg_need_paypal_account'] 				= "To cashout your hours, you need to add a PayPal account on your profile page!";

// Dropzone
$lang['label_allowed_file_types'] 				= "İzin Verilen Dosyalar: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Profil Resmi";
$lang['title_edit_profile'] 					= "Profilini Düzenle";
$lang['title_personal_settings'] 				= "Kişisel Ayarlar";
$lang['subtitle_personal_details'] 				= "Kişisel Bilgiler";
$lang['subtitle_change_password'] 				= "Parolayı Değiştir";
$lang['label_first_name'] 						= "Adı";
$lang['label_last_name'] 						= "Soyadı";
$lang['label_email'] 							= "E-posta";
$lang['label_paypal_email'] 					= "PayPal E-posta";
$lang['label_phone'] 							= "Telefon";
$lang['label_company'] 							= "Şirket";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Ülke";
$lang['label_city'] 							= "Şehir";
$lang['label_language'] 						= "Dil";
$lang['label_current_pass'] 					= "Geçerli Parola";
$lang['label_new_pass'] 						= "Yeni Parola";
$lang['label_confirm_pass'] 					= "Parolayı Onayla";
$lang['label_email_notifications'] 				= "E-posta Bildirimleri";
$lang['label_online_notifications'] 			= "Online Bildirimler";

// Transactions
$lang['title_balance'] 							= "Dengeleme";
$lang['title_hours'] 							= "Saat";
$lang['title_transactions'] 					= "İşlemler";
$lang['thead_date'] 							= "Tarih";
$lang['thead_title'] 							= "Başlık";
$lang['thead_debit'] 							= "Borçlanma";
$lang['thead_credit'] 							= "Kredi";
$lang['thead_balance'] 							= "Dengeleme";
$lang['popup_title_paypal_account'] 			= "PayPal Account";

// Status
$lang['status_not_assigned'] 					= "Atanmadı";
$lang['status_assigned'] 						= "Atandı";
$lang['status_in_progress'] 					= "İlerleme Sürüyor";
$lang['status_completed'] 						= "Tamamlandı";
$lang['status_not_completed'] 					= "Tamamlanmadı";
$lang['status_none'] 							= "Hiçbiri";
$lang['status_no_data_available'] 				= "Veri yok";
$lang['status_not_set'] 						= "Ayarlanmadı";
$lang['status_pending'] 						= "Beklemede";
$lang['status_open'] 							= "Açık";
$lang['status_closed'] 							= "Kapatıldı";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Yapılacak İşlemi Sil";
$lang['popup_title_add_todo'] 					= "Yapılacak İş Ekle";
$lang['popup_title_todo'] 						= "Yapılacak İş";
$lang['db_smallstat_title_projects'] 			= "Projeler";
$lang['db_smallstat_title_tasks'] 				= "Görevler";
$lang['db_smallstat_title_clients'] 			= "Müşteriler";
$lang['db_smallstat_title_assigned_tasks'] 		= "Atanan Görevler";
$lang['db_smallstat_title_in_progress'] 		= "İlerleme Görevleri";
$lang['db_smallstat_title_completed'] 			= "Tamamlanan Görevler";
$lang['db_smallstat_title_balance'] 			= "Dengeleme";
$lang['title_monthly_completed_tasks'] 			= "Aylık Tamamlanan Görevler İçin";
$lang['title_all_tasks'] 						= "Tüm Görevler";
$lang['title_tasks_per_project'] 				= "Görevler / Projeler";
$lang['thead_not_assigned'] 					= "Atanmadı";
$lang['thead_assigned'] 						= "Atandı";
$lang['thead_in_progress'] 						= "İlerleme Sürüyor";
$lang['title_todo_list'] 						= "Yapılacaklar Listesi";

// Quick Buttons
$lang['title_shortcuts'] 						= "Kısayollar";

// Bonus
$lang['label_bonus'] 							= "Bonus";

// Projects
$lang['thead_project'] 							= "Proje";
$lang['thead_client'] 							= "Müşteri";
$lang['thead_due_date'] 						= "Teslim Tarihi";
$lang['thead_status'] 							= "Durum";
$lang['thead_actions'] 							= "İşlemler";

// View Project
$lang['title_project'] 							= "Proje:";
$lang['subtitle_progress_bar'] 					= "İlerleme Çubuğu";
$lang['subtitle_client'] 						= "Müşteri";
$lang['subtitle_details'] 						= "Ayrıntılar";
$lang['subtitle_description'] 					= "Açıklama";
$lang['label_view_name'] 						= "Adı:";
$lang['label_view_company'] 					= "Şirket:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Since :";
$lang['label_view_added'] 						= "Eklendi:";
$lang['label_view_due_date'] 					= "Teslim Tarihi:";
$lang['label_view_status'] 						= "Durum:";

// Add Project
$lang['title_new_project'] 						= "Yeni Proje";

// Edit Project
$lang['title_edit_project'] 					= "Proje Düzenle";
$lang['label_title'] 							= "Başlık";
$lang['label_desc'] 							= "Açıklama";
$lang['label_due_date'] 						= "Bitiş Tarihi";
$lang['label_client'] 							= "Müşteri";

// Tasks per Project
$lang['title_tasks_for'] 						= "Görevler İçin";
$lang['thead_task'] 							= "Görev";
$lang['thead_added'] 							= "Eklendi";
$lang['thead_due_date'] 						= "Teslim Tarihi";
$lang['thead_completed'] 						= "Tamamlandı";
$lang['thead_developer'] 						= "Geliştirici";

// My Tasks
$lang['title_managed_tasks'] 					= "Yönetilen Görevler";
$lang['title_in_progress_tasks'] 				= "İlerleme Görevleri";
$lang['title_completed_tasks'] 					= "Tamamlanan Görevler";
$lang['tooltip_urgent'] 						= "Acil";
$lang['tooltip_high'] 							= "Yüksek";

// View Task
$lang['title_task'] 							= "Görev";
$lang['label_cost'] 							= "Maliyet";
$lang['label_hours'] 							= "Saat";
$lang['label_hours_info'] 						= "(0.5 = 30 dakika)";
$lang['label_comment'] 							= "Yorum";
$lang['label_added_by'] 						= "Tarafından Eklendi";
$lang['label_view_group'] 						= "Grup:";
$lang['label_view_cost'] 						= "Maliyet:";
$lang['status_not_available'] 					= "Henüz erişilemiyor";
$lang['label_view_completed'] 					= "Tamamlandı:";
$lang['label_quote'] 							= "Alıntı";
$lang['label_system'] 							= "Sistem";
$lang['label_no_attachment'] 					= "Ek yok";

// Add Task
$lang['title_new_task'] 						= "Yeni Görev";
$lang['label_project'] 							= "Proje";
$lang['label_attachment'] 						= "Ekler (ler)";
$lang['label_priority'] 						= "Öncelik";
$lang['label_select'] 							= "Seç";

// Edit Task
$lang['title_edit_task'] 						= "Görev Düzenle";

// Clients
$lang['title_clients'] 							= "Müşteri";
$lang['thead_name'] 							= "Adı";
$lang['thead_email'] 							= "E-mail";
$lang['thead_company'] 							= "Firma";

// Add Client
$lang['title_new_client'] 						= "Yeni Müşteri";
$lang['label_username'] 						= "Kullanıcı Adı";
$lang['label_pass'] 							= "Şifre";
$lang['title_last_clients'] 					= "Son Müşteriler";
$lang['label_send_email'] 						= "E-mail Gönder";

// Edit Client
$lang['title_edit_client'] 						= "Müşteri Düzenle";

// Members
$lang['title_members'] 							= "Üyeler";
$lang['thead_group'] 							= "Grup";
$lang['label_all'] 								= "Tümü";

// Add Member
$lang['title_new_member'] 						= "Yeni üye";
$lang['label_group'] 							= "Grup";
$lang['label_hourly_rate'] 						= "Saat Başı Hızı";
$lang['label_per_hour'] 						= "/ saat";

// Edit Member
$lang['title_edit_member'] 						= "Üye Düzenle";

// Reports
$lang['title_reports'] 							= "Raporlar";
$lang['title_nr_tasks_per'] 					= "Görev Sayısı /";
$lang['title_tasks_per'] 						= "Görevler /";
$lang['label_date'] 							= "Tarih:";
$lang['thead_hours'] 							= "Saatler";

// Tickets
$lang['title_tickets'] 							= "Destek Talebi";
$lang['thead_id'] 								= "Talep No";
$lang['thead_subject'] 							= "Konu";
$lang['thead_added_by'] 						= "Ekleyen";

// View Ticket
$lang['title_ticket'] 							= "Destek Talebi:";
$lang['label_details'] 							= "Ayrıntılar";
$lang['label_view_email'] 						= "E-posta:";
$lang['label_view_phone'] 						= "Telefon:";
$lang['label_view_type'] 						= "Tipi:";
$lang['label_view_app_url'] 					= "Uygulama URL'si:";
$lang['label_subject'] 							= "Konu:";
$lang['label_message'] 							= "Mesaj:";
$lang['label_answered_by'] 						= "Yanıtlayan";
$lang['label_closed_by'] 						= "Kapatıldı";
$lang['label_type_problem'] 					= "Sayı";
$lang['label_type_question'] 					= "Soru";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Destek Talebi Ayarları";
$lang['label_active'] 							= "Etkin";
$lang['label_inactive'] 						= "Aktif Değil";
$lang['label_text_button'] 						= "Metin Düğmesi";
$lang['label_text_color'] 						= "Metin Rengi";
$lang['label_button_color'] 					= "Düğme Rengi";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Yeni Ayarlar";
$lang['label_app_url'] 							= "Uygulama URL'si" ;;
$lang['label_private_key'] 						= "Özel Anahtar";
$lang['label_api_script'] 						= "API Komut Dosyası";
$lang['label_notified_emails'] 					= "Onaylanmış E-postalar";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Ayarları Düzenle";

// Notifications
$lang['thead_type'] 							= "Tipi";
$lang['thead_message'] 							= "Mesaj";
$lang['title_notifications'] 					= "Bildirimler";
$lang['last_notifications'] 					= "Son bildirimler";
$lang['view_all_notifications'] 				= "Tüm bildirimleri görüntüle";
$lang['no_notifications'] 						= "0 bildirim hakkınız var";

// Log
$lang['title_log'] 								= "Log";
$lang['thead_text'] 							= "Metin";

// Settings
$lang['title_settings'] 						= "Ayarlar";
$lang['title_general'] 							= "Genel";
$lang['title_groups'] 							= "Gruplar";
$lang['label_contact_email'] 					= "E-posta ile İletişim Kurun";
$lang['label_accounting_email'] 				= "E-posta ile Muhasebe";
$lang['label_sender_name'] 						= "Gönderen Adı";
$lang['label_sender_email'] 					= "Gönderen E-postası";
$lang['label_enable_emails'] 					= "E-postaları Etkinleştir";
$lang['label_multi_language'] 					= "Çoklu Dili Etkinleştir";
$lang['label_show_credits'] 					= "Kredileri Göster";
$lang['label_information'] 						= "Bilgi";
$lang['label_group'] 							= "Grup";
$lang['label_enable_tickets'] 					= "Destek Talebi Sistemini Etkinleştir";

?>