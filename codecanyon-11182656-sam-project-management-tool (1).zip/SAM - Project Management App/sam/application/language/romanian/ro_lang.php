<?

// Login & Recover
$lang['lgn_login_account'] 						= "Intra în cont";
$lang['lgn_username'] 							= "Utilizator";
$lang['lgn_password'] 							= "Parola";
$lang['lgn_remember_me'] 						= "Ține-mă minte";
$lang['lgn_forgot_pass'] 						= "Ai uitat parola?";
$lang['lgn_no_problem'] 						= "Nicio problemă,";
$lang['lgn_click_here'] 						= "click aici";
$lang['lgn_get_new_pass'] 						= "pentru a o recupera!";
$lang['lgn_recover_pass'] 						= "Recuperează parola";
$lang['lgn_email'] 								= "Email";

// Top
$lang['top_welcome'] 							= "Bine ai venit,";
$lang['top_profile'] 							= "Profil";
$lang['top_transactions'] 						= "Tranzacții";
$lang['top_logout'] 							= "Deconectare";

// Menu
$lang['menu_dashboard'] 						= "Dashboard";
$lang['menu_projects'] 							= "Proiecte";
$lang['menu_tasks'] 							= "Task-urile mele";
$lang['menu_clients'] 							= "Clienți";
$lang['menu_members'] 							= "Membri";
$lang['menu_reports']							= "Rapoarte";
$lang['menu_support_tickets']					= "Tichete Suport";
$lang['menu_tickets']							= "Tichete";
$lang['menu_tickets_settings']					= "Setări Tichete";
$lang['menu_log'] 								= "Log";
$lang['menu_settings'] 							= "Setări";

// Buttons
$lang['btn_login'] 								= "Autentificare";
$lang['btn_recover'] 							= "Recuperează";
$lang['btn_save_changes'] 						= "Salvează";
$lang['btn_cancel'] 							= "Renunță";
$lang['btn_back'] 								= "Înapoi";
$lang['btn_upload'] 							= "Upload";
$lang['btn_cashout'] 							= "Retrage";
$lang['btn_yes'] 								= "Da";
$lang['btn_no'] 								= "Nu";
$lang['btn_new_project'] 						= "Proiect Nou";
$lang['btn_view_tasks'] 						= "Vezi Task-uri";
$lang['btn_view'] 								= "Vizualizează";
$lang['btn_edit'] 								= "Modifică";
$lang['btn_disable'] 							= "Dezactivează";
$lang['btn_delete'] 							= "Elimină";
$lang['btn_close_project'] 						= "Închide Proiect";
$lang['btn_edit_project'] 						= "Modifică Proiect";
$lang['btn_new_task'] 							= "Task Nou";
$lang['btn_close'] 								= "Închide";
$lang['btn_quote_task'] 						= "Estimează Task";
$lang['btn_edit_task'] 							= "Modifică Task";
$lang['btn_complete_task'] 						= "Finalizează Task";
$lang['btn_send_message'] 						= "Trimite Mesaj";
$lang['btn_new_client'] 						= "Client Nou";
$lang['btn_new_member'] 						= "Membru Nou";
$lang['btn_new_ticket_settings'] 				= "Setare Nouă";
$lang['btn_answer'] 							= "Răspunde";
$lang['btn_generate_script'] 					= "Generează Script";
$lang['btn_generate'] 							= "Generează";
$lang['btn_copy'] 								= "Copiază";
$lang['btn_mark_as_read'] 						= "Marchează ca Citite";

// Messages
$lang['msg_changes_saved'] 						= "Modificările au fost salvate!";
$lang['msg_passwords_not_match'] 				= "Parolele nu coincid!";
$lang['msg_email_already_exist'] 				= "Email-ul există deja!";
$lang['msg_invalid_password'] 					= "Parola curentă invalida!";
$lang['msg_complete_all_fields'] 				= "Vă rugăm completați toate câmpurile!";
$lang['msg_changes_not_saved'] 					= "Modificările nu s-au putut salva!";
$lang['msg_invalid_username_password'] 			= "Utilizator sau parolă incorectă!";
$lang['msg_new_login_details'] 					= "Noile date de autentificare au fost trimise la adresa de email!";
$lang['msg_pass_changed_not_notified'] 			= "Parola a fost schimbată, utilizatorul nu este notificat!";
$lang['msg_pass_not_saved'] 					= "Parola nu a fost schimbată!";
$lang['msg_email_not_exist'] 					= "Adresa de email nu există!";
$lang['msg_want_delete_project'] 				= "Ești sigur că vrei să elimini acest proiect?";
$lang['msg_want_close_project'] 				= "Ești sigur că vrei să închizi acest proiect?";
$lang['msg_want_delete_task'] 					= "Ești sigur că vrei să elimini acest task?";
$lang['msg_invalid_cost'] 						= "Cost invalid!";
$lang['msg_task_not_completed'] 				= "Task-ul nu s-a putut finaliza!";
$lang['msg_task_assigned_to'] 					= "Task atribuit la";
$lang['msg_task_not_assigned'] 					= "Task neatribuit încă";
$lang['msg_want_disable_client'] 				= "Ești sigur că vrei să dezactivezi acest client?";
$lang['msg_want_delete_client'] 				= "Ești sigur că vrei să elimini acest client?";
$lang['msg_username_already_exist'] 			= "Utilizatorul există deja!";
$lang['msg_username_and_email_already_exist'] 	= "Utilizatorul și email-ul există deja!";
$lang['msg_want_disable_member'] 				= "Ești sigur că vrei să dezactivezi acest membru?";
$lang['msg_want_delete_member'] 				= "Ești sigur că vrei să elimini acest membru?";
$lang['msg_want_delete_item'] 					= "Ești sigur că vrei să elimini acest element?";
$lang['msg_name_of_your_company'] 				= "Setează numele companiei.";
$lang['msg_contact_email'] 						= "Setează adresa de email de contact.";
$lang['msg_accounting_email'] 					= "Setează adresa de email a contabilului.";
$lang['msg_name_for_sending_emails'] 			= "Setează numele care va fi folosit pentru trimiterea de email-uri. ex: Numele Companiei";
$lang['msg_email_for_sending_emails'] 			= "Setează adresă de email care va fi folosită pentru trimiterea de email-uri. ex: noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Activează trimiterea de email-uri când task-urile sunt atribuite, finalizate, etc.";
$lang['msg_enable_multi_language'] 				= "Activează opțiunea multi-limbă din pagina de profil.";
$lang['msg_show_credits'] 						= "Afișează 'Powered by IntelCoder' în colțul din dreapta a paginii.";
$lang['msg_cannot_close_project'] 				= "Trebuie să finalizați toate task-urile, pentru a putea închide acest proiect!";
$lang['msg_receive_email_notifications'] 		= "Activează primirea de email-uri când task-urile sunt adăugate, finalizate, etc.";
$lang['msg_receive_online_notifications']		= "Activează primirea de notificări online când task-urile sunt adăugate, finalizate, etc.";
$lang['msg_confirm_delete_ticket'] 				= "Ești sigur că vrei să elimini acest tichet?";
$lang['msg_copied_to_clipboard'] 				= "Script-ul a fost copiat în clipboard!";
$lang['msg_enable_tickets_system'] 				= "Activează sistemul de tichete.";
$lang['msg_want_delete_settings'] 				= "Ești sigur că vrei să elimini această setare?";
$lang['msg_generate_private_key'] 				= "Generează o cheie privată pentru clientul tau.";
$lang['msg_text_button'] 						= "Setează textul dorit pentru butonul de suport.";
$lang['msg_text_color'] 						= "Setează culoarea textului pentru butonul de suport.";
$lang['msg_color_button'] 						= "Setează culoara butonului de suport.";
$lang['msg_client_domain_url'] 					= "Setează domeniul clientului de pe care se vor trimite tichetele de suport. Trebuie să introduci domeniul fara 'http://'. ex: www.domain.com";
$lang['msg_notified_emails'] 					= "Setează una sau mai multe adrese de email, separate prin virgula, pentru a primii notificări când sunt adaugate tichete de suport.";
$lang['msg_copy_api_script'] 					= "Copiază acest script si include-l in website-ul clientului. Acest script va afișa formularul de suport.";
$lang['msg_need_paypal_account'] 				= "Pentru a retrage orele lucrate, trebuie sa vă adăugați un cont de PayPal în pagina de profil!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Fișiere permise: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Poză Profil";
$lang['title_edit_profile'] 					= "Modifică Profilul";
$lang['title_personal_settings'] 				= "Setări Personale";
$lang['subtitle_personal_details'] 				= "Detalii Personale";
$lang['subtitle_change_password'] 				= "Modifică Parola";
$lang['label_first_name'] 						= "Prenume";
$lang['label_last_name'] 						= "Nume";
$lang['label_email'] 							= "Email";
$lang['label_paypal_email'] 					= "Email PayPal";
$lang['label_phone'] 							= "Telefon";
$lang['label_company'] 							= "Compania";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Țara";
$lang['label_city'] 							= "Oraș";
$lang['label_language'] 						= "Limba";
$lang['label_current_pass'] 					= "Parola Curentă";
$lang['label_new_pass'] 						= "Noua Parolă";
$lang['label_confirm_pass'] 					= "Confirmă Parolă";
$lang['label_email_notifications'] 				= "Notificări prin Email";
$lang['label_online_notifications']				= "Notificări Online";

// Transactions
$lang['title_balance'] 							= "Balanță";
$lang['title_hours'] 							= "ore";
$lang['title_transactions'] 					= "Tranzacții";
$lang['thead_date'] 							= "Data";
$lang['thead_title'] 							= "Titlu";
$lang['thead_debit'] 							= "Debit";
$lang['thead_credit'] 							= "Credit";
$lang['thead_balance'] 							= "Balanța";
$lang['popup_title_paypal_account'] 			= "Cont de PayPal";

// Status
$lang['status_not_assigned'] 					= "Neatribuit";
$lang['status_assigned'] 						= "Atribuit";
$lang['status_in_progress'] 					= "În Proces";
$lang['status_completed'] 						= "Finalizat";
$lang['status_not_completed'] 					= "Nefinalizat";
$lang['status_none'] 							= "Niciunul";
$lang['status_no_data_available'] 				= "Nu sunt date disponibile";
$lang['status_not_set'] 						= "Nu e setată";
$lang['status_pending'] 						= "În Așteptare";
$lang['status_open'] 							= "Deschis";
$lang['status_closed'] 							= "Închis";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Elimină To-Do";
$lang['popup_title_add_todo'] 					= "Adaugă To-Do";
$lang['popup_title_todo'] 						= "To-Do";
$lang['db_smallstat_title_projects'] 			= "Proiecte";
$lang['db_smallstat_title_tasks'] 				= "Task-uri";
$lang['db_smallstat_title_clients'] 			= "Clienți";
$lang['db_smallstat_title_assigned_tasks'] 		= "Task-uri Atribuite";
$lang['db_smallstat_title_in_progress'] 		= "Task-uri In Proces";
$lang['db_smallstat_title_completed'] 			= "Task-uri Finalizate";
$lang['db_smallstat_title_balance'] 			= "Balanță";
$lang['title_monthly_completed_tasks'] 			= "Task-uri Lunare Finalizate Pe";
$lang['title_all_tasks'] 						= "Toate Task-urile";
$lang['title_tasks_per_project'] 				= "Task-uri / Proiect";
$lang['thead_not_assigned'] 					= "Neatribuit";
$lang['thead_assigned'] 						= "Atribuit";
$lang['thead_in_progress'] 						= "În Proces";
$lang['title_todo_list'] 						= "Listă To-Do";

// Quick Buttons
$lang['title_shortcuts'] 						= "Comenzi Rapide";

// Bonus
$lang['label_bonus'] 							= "Bonus";

// Projects
$lang['thead_project'] 							= "Proiect";
$lang['thead_client'] 							= "Client";
$lang['thead_due_date'] 						= "Data Finalizării";
$lang['thead_status'] 							= "Status";
$lang['thead_actions'] 							= "Acțiuni";

// View Project
$lang['title_project'] 							= "Proiect:";
$lang['subtitle_progress_bar'] 					= "Bară de Progres";
$lang['subtitle_client'] 						= "Client";
$lang['subtitle_details'] 						= "Detalii";
$lang['subtitle_description'] 					= "Descriere";
$lang['label_view_name'] 						= "Nume:";
$lang['label_view_company'] 					= "Compania:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Înregistrat:";
$lang['label_view_added'] 						= "Adăugat:";
$lang['label_view_due_date'] 					= "Data Finalizării:";
$lang['label_view_status'] 						= "Status:";

// Add Project
$lang['title_new_project'] 						= "Proiect Nou";

// Edit Project
$lang['title_edit_project'] 					= "Modifică Proiect";
$lang['label_title'] 							= "Titlu";
$lang['label_desc'] 							= "Descriere";
$lang['label_due_date'] 						= "Data Finalizării";
$lang['label_client'] 							= "Client";

// Tasks per Project
$lang['title_tasks_for'] 						= "Task-uri Pentru";
$lang['thead_task'] 							= "Task";
$lang['thead_added'] 							= "Adăugat";
$lang['thead_due_date'] 						= "Data Finalizării";
$lang['thead_completed'] 						= "Finalizat";
$lang['thead_developer'] 						= "Dezvoltator";

// My Tasks
$lang['title_managed_tasks']					= "Task-uri Gestionate";
$lang['title_in_progress_tasks'] 				= "Task-uri În Proces";
$lang['title_completed_tasks'] 					= "Task-uri Finalizate";
$lang['tooltip_urgent'] 						= "Urgent";
$lang['tooltip_high']							= "Ridicat";

// View Task
$lang['title_task'] 							= "Task:";
$lang['label_cost'] 							= "Cost";
$lang['label_hours'] 							= "ore";
$lang['label_hours_info'] 						= "(0.5 = 30 minute)";
$lang['label_comment'] 							= "Mesaj";
$lang['label_added_by'] 						= "Adăugat De";
$lang['label_view_group'] 						= "Grup:";
$lang['label_view_cost'] 						= "Cost:";
$lang['status_not_available'] 					= "Nu este disponibil";
$lang['label_view_completed'] 					= "Finalizat:";
$lang['label_quote'] 							= "Estimare";
$lang['label_system'] 							= "Sistem";
$lang['label_no_attachment'] 					= "Nu sunt atașamente";

// Add Task
$lang['title_new_task'] 						= "Task Nou";
$lang['label_project'] 							= "Proiect";
$lang['label_attachment']						= "Atașament(e)";
$lang['label_priority']							= "Prioritate";
$lang['label_select'] 							= "Alege";

// Edit Task
$lang['title_edit_task'] 						= "Modifică Task";

// Clients
$lang['title_clients'] 							= "Clienți";
$lang['thead_name'] 							= "Nume";
$lang['thead_email'] 							= "Email";
$lang['thead_company'] 							= "Compania";

// Add Client
$lang['title_new_client'] 						= "Client Nou";
$lang['label_username'] 						= "Utilizator";
$lang['label_pass'] 							= "Parola";
$lang['title_last_clients'] 					= "Ultimii Clienți";
$lang['label_send_email'] 						= "Trimite Email";

// Edit Client
$lang['title_edit_client'] 						= "Modifică Client";

// Members
$lang['title_members'] 							= "Membri";
$lang['thead_group'] 							= "Grup";
$lang['label_all'] 								= "Toți";

// Add Member
$lang['title_new_member'] 						= "Membru Nou";
$lang['label_group'] 							= "Grup";
$lang['label_hourly_rate'] 						= "Tarif / Ora";
$lang['label_per_hour'] 						= "/ora";

// Edit Member
$lang['title_edit_member'] 						= "Modifică Membru";

// Reports
$lang['title_reports']							= "Rapoarte";
$lang['title_nr_tasks_per'] 					= "# de Task-uri /";
$lang['title_tasks_per']						= "Task-uri /";
$lang['label_date'] 							= "Data:";
$lang['thead_hours'] 							= "Ore";

// Tickets
$lang['title_tickets'] 							= "Tichete";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Subiect";
$lang['thead_added_by'] 						= "Adăugat De";

// View Ticket
$lang['title_ticket'] 							= "Tichet:";
$lang['label_details']							= "Detalii";
$lang['label_view_email']						= "Email:";
$lang['label_view_phone']						= "Telefon:";
$lang['label_view_type']						= "Tip:";
$lang['label_view_app_url']						= "App URL:";
$lang['label_subject'] 							= "Subiect:";
$lang['label_message']							= "Mesaj";
$lang['label_answered_by'] 						= "Răspuns postat de";
$lang['label_closed_by'] 						= "Închis de";
$lang['label_type_problem'] 					= "Problemă";
$lang['label_type_question'] 					= "Întrebare";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Setări Tichete";
$lang['label_active'] 							= "Activ";
$lang['label_inactive'] 						= "Inactiv";
$lang['label_text_button'] 						= "Textul Butonului";
$lang['label_text_color'] 						= "Culoarea Textului";
$lang['label_button_color']						= "Coloarea Butonului";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Setare Nouă";
$lang['label_app_url'] 							= "App URL";
$lang['label_private_key']						= "Cheie Privată";
$lang['label_api_script']						= "Script API";
$lang['label_notified_emails'] 					= "Email-uri Notificate";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Modifică Setări";

// Notifications
$lang['thead_type'] 							= "Tip";
$lang['thead_message'] 							= "Mesaj";
$lang['title_notifications'] 					= "Notificări";
$lang['last_notifications'] 					= "Ultimele notificări";
$lang['view_all_notifications'] 				= "Vezi toate notificările";
$lang['no_notifications'] 						= "Ai 0 notificări";

// Log
$lang['title_log'] 								= "Log";
$lang['thead_text'] 							= "Text";

// Settings
$lang['title_settings'] 						= "Setări";
$lang['title_general'] 							= "Generale";
$lang['title_groups'] 							= "Grupuri";
$lang['label_contact_email'] 					= "Email de Contact";
$lang['label_accounting_email'] 				= "Email Contabilitate";
$lang['label_sender_name'] 						= "Nume Expeditor";
$lang['label_sender_email'] 					= "Email Expeditor";
$lang['label_enable_emails'] 					= "Activează Email-urile";
$lang['label_multi_language'] 					= "Activează Multi-Limbă";
$lang['label_show_credits'] 					= "Afișează Creditele";
$lang['label_information'] 						= "Informații";
$lang['label_group'] 							= "Grup";
$lang['label_enable_tickets'] 					= "Activează Sistemul de Tichete";

?>