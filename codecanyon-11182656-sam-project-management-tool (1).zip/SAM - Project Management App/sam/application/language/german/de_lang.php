<?

// Login & Recover
$lang['lgn_login_account'] 						= "Zum Benutzerkonto anmelden";
$lang['lgn_username'] 							= "Benutzername";
$lang['lgn_password'] 							= "Kennwort";
$lang['lgn_remember_me'] 						= "Merken";
$lang['lgn_forgot_pass'] 						= "Kennwort vergessen?";
$lang['lgn_no_problem'] 						= "Kein Problem,";
$lang['lgn_click_here'] 						= "Klicke hier";
$lang['lgn_get_new_pass'] 						= "neues Kennwort!";
$lang['lgn_recover_pass'] 						= "Kennwort wiederherstellen";
$lang['lgn_email'] 								= "E-mail";

// Top
$lang['top_welcome'] 							= "Willkommen,";
$lang['top_profile'] 							= "Profil";
$lang['top_transactions'] 						= "Transaktion";
$lang['top_logout'] 							= "Abmelden";

// Menu
$lang['menu_dashboard'] 						= "Dashboard";
$lang['menu_projects'] 							= "Projekte";
$lang['menu_tasks'] 							= "Meine Aufgaben";
$lang['menu_clients'] 							= "Kunden";
$lang['menu_members'] 							= "Mitglieder";
$lang['menu_reports']							= "Berichte";
$lang['menu_support_tickets']					= "Support Tickets";
$lang['menu_tickets']							= "Tickets";
$lang['menu_tickets_settings']					= "Ticket Einstellungen";
$lang['menu_log'] 								= "Log";
$lang['menu_settings'] 							= "Einstellungen";

// Buttons
$lang['btn_login'] 								= "Anmelden";
$lang['btn_recover'] 							= "Wiederherstellen";
$lang['btn_save_changes'] 						= "Speichern";
$lang['btn_cancel'] 							= "Abbrechen";
$lang['btn_back'] 								= "Zurück";
$lang['btn_upload'] 							= "Hochladen";
$lang['btn_cashout'] 							= "Auszahlung";
$lang['btn_yes'] 								= "Ja";
$lang['btn_no'] 								= "Nein";
$lang['btn_new_project'] 						= "Neues projekt";
$lang['btn_view_tasks'] 						= "Aufgaben ansehen";
$lang['btn_view'] 								= "Ansicht";
$lang['btn_edit'] 								= "Bearbeiten";
$lang['btn_disable'] 							= "Deaktivieren";
$lang['btn_delete'] 							= "Löschen";
$lang['btn_close_project'] 						= "Projekt schließen";
$lang['btn_edit_project'] 						= "Projekt bearbeiten";
$lang['btn_new_task'] 							= "Neue aufgabe";
$lang['btn_close'] 								= "Schließen";
$lang['btn_quote_task'] 						= "Aufgabe schätzen";
$lang['btn_edit_task'] 							= "Aufgabe bearbeiten";
$lang['btn_complete_task'] 						= "Aufgabe beenden";
$lang['btn_send_message'] 						= "Nachricht senden";
$lang['btn_new_client'] 						= "Neuer kunde";
$lang['btn_new_member'] 						= "Neues mitlied";
$lang['btn_new_ticket_settings'] 				= "Neue ticket einstellung";
$lang['btn_answer'] 							= "Antworten";
$lang['btn_generate_script'] 					= "Skript generieren";
$lang['btn_generate'] 							= "Generieren";
$lang['btn_copy'] 								= "Kopieren";
$lang['btn_mark_as_read'] 						= "Als gelesen markieren";

// Messages
$lang['msg_changes_saved'] 						= "Änderungen wurden gespeichert!";
$lang['msg_passwords_not_match'] 				= "Kennwort nicht richtig!";
$lang['msg_email_already_exist'] 				= "E-mail existiert bereits!";
$lang['msg_invalid_password'] 					= "Aktuelles Kennwort ungültig!";
$lang['msg_complete_all_fields'] 				= "Bitte alle Felder ausfüllen!";
$lang['msg_changes_not_saved'] 					= "Änderungen können nicht gespeichert werden!";
$lang['msg_invalid_username_password'] 			= "Benutzer oder Kennwort falsch!";
$lang['msg_new_login_details'] 					= "Die neuen Zugangsdaten wurden an Ihre E-mail Adresse versandt!";
$lang['msg_pass_changed_not_notified'] 			= "Kennwort wurde geändert, Benutzer wurde nicht benachtichtigt!";
$lang['msg_pass_not_saved'] 					= "Kennwort wurde nicht geändert!";
$lang['msg_email_not_exist'] 					= "E-mail Adresse existiert nicht!";
$lang['msg_want_delete_project'] 				= "Sind Sie sicher, dass Sie das Projekt löschen möchten?";
$lang['msg_want_close_project'] 				= "Sind Sie sicher, dass Sie das Projekt schließen möchten?";
$lang['msg_want_delete_task'] 					= "Sind Sie sicher, dass Sie die Aufgabe löschen möchten?";
$lang['msg_invalid_cost'] 						= "Ungültige Kosten!";
$lang['msg_task_not_completed'] 				= "Aufgabe konnte nicht beendet werden!";
$lang['msg_task_assigned_to'] 					= "Aufgabe zuordnen zu";
$lang['msg_task_not_assigned'] 					= "Aufgabe noch nicht zugeordnet";
$lang['msg_want_disable_client'] 				= "Sind Sie sicher, dass Sie diesen Kunden deaktivieren möchten?";
$lang['msg_want_delete_client'] 				= "Sind Sie sicher, dass Sie diesen Kunden löschen möchten?";
$lang['msg_username_already_exist'] 			= "Benutzer existiert bereits!";
$lang['msg_username_and_email_already_exist'] 	= "Benutzer und E-mail existieren bereits!";
$lang['msg_want_disable_member'] 				= "Sind Sie sicher, dass Sie dieses Mitglied deaktivieren möchten?";
$lang['msg_want_delete_member'] 				= "Sind Sie sicher, dass Sie dieses Mitglied löschen möchten?";
$lang['msg_want_delete_item'] 					= "Sind Sie sicher, dass Sie dieses Element löschen möchten?";
$lang['msg_name_of_your_company'] 				= "Firmenname festlegen.";
$lang['msg_contact_email'] 						= "Kontakt E-Mail Adresse angeben.";
$lang['msg_accounting_email'] 					= "Buchhaltung E-Mail Adresse angeben.";
$lang['msg_name_for_sending_emails'] 			= "Legen Sie den Namen fest, von welchem die E-mails verschickt werden. Z.B.: Firmenname";
$lang['msg_email_for_sending_emails'] 			= "Legen Sie die E-mail Adresse fest, welche für die E-mails verwendet werden soll. Z.B.: noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "E-mail Versand aktivieren wenn die Aufgaben zugeordnet oder geschlossen, usw. sind.";
$lang['msg_enable_multi_language'] 				= "Aktivieren der Mehrsprachenfähigkeit auf der Benuzerseite.";
$lang['msg_show_credits'] 						= "Zeige 'Powered by IntelCoder' rechts unten auf der Seite.";
$lang['msg_cannot_close_project'] 				= "Sie müssen alle Aufgaben erledigen, um das Projekt zu schließen!";
$lang['msg_receive_email_notifications'] 		= "E-mail Versand aktivieren wenn die Aufgaben hinzugefügt oder abgeschlossen, usw. sind.";
$lang['msg_receive_online_notifications']		= "Online Versand aktivieren wenn die Aufgaben hinzugefügt oder abgeschlossen, usw. sind.";
$lang['msg_confirm_delete_ticket'] 				= "Sind Sie sicher, dass Sie diese Einstellung löschen möchten?";
$lang['msg_copied_to_clipboard'] 				= "Skript in die Zwischenablage kopiert!";
$lang['msg_enable_tickets_system'] 				= "Aktivieren die Ticket-System.";
$lang['msg_want_delete_settings'] 				= "Sind Sie sicher, dass Sie diese Einstellung löschen möchten?";
$lang['msg_generate_private_key'] 				= "Generieren eines eindeutigen Schlüssels für Ihren Kunden.";
$lang['msg_text_button'] 						= "Text für den Support-Button festlegen.";
$lang['msg_text_color'] 						= "Textfarbe für den Support-Button festlegen.";
$lang['msg_color_button'] 						= "Farbe für den Support-Button festlegen.";
$lang['msg_client_domain_url'] 					= "Legen Sie die Domain fest, in der die Tickets genutzt werden. Bitte geben Sie die Domain ohne 'http://' ein. Z. B. www.domain.com";
$lang['msg_notified_emails'] 					= "Legen Sie mehrere Email-Adressen mit Komma getrennt fest, um eine Benachrichtigung zu erhalten wenn ein Ticket hinzugefügt wird.";
$lang['msg_copy_api_script'] 					= "Kopieren Sie dieses Skript und fügen Sie es in die Web-Seite des Kunden ein, um das Support-Formular dort anzuzeigen.";
$lang['msg_need_paypal_account'] 				= "⁠Um Ihre gearbeiteten Stunden ausbezahlt zu bekommen, müssen Sie ein PayPal-Konto zu Ihrer Profilseite hinzufügen!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Zulässige Dateiformate: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Profilbild";
$lang['title_edit_profile'] 					= "Profil bearbeiten";
$lang['title_personal_settings'] 				= "Persönliche Einstellungen";
$lang['subtitle_personal_details'] 				= "Persönliche Details";
$lang['subtitle_change_password'] 				= "Kennwort ändern";
$lang['label_first_name'] 						= "Vorname";
$lang['label_last_name'] 						= "Nachname";
$lang['label_email'] 							= "E-mail";
$lang['label_paypal_email'] 					= "PayPal E-mail";
$lang['label_phone'] 							= "Telefon";
$lang['label_company'] 							= "Firma";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Land";
$lang['label_city'] 							= "Stadt";
$lang['label_language'] 						= "Sprache";
$lang['label_current_pass'] 					= "Aktuelles Kennwort";
$lang['label_new_pass'] 						= "Neues Kennwort";
$lang['label_confirm_pass'] 					= "Kennwort wiederholen";
$lang['label_email_notifications'] 				= "E-mail Benachrichtigungen";
$lang['label_online_notifications']				= "Online Benachrichtigungen";

// Transactions
$lang['title_balance'] 							= "Gleichgewicht";
$lang['title_hours'] 							= "Stunden";
$lang['title_transactions'] 					= "Transaktion";
$lang['thead_date'] 							= "Datum";
$lang['thead_title'] 							= "Titel";
$lang['thead_debit'] 							= "EC-Karte";
$lang['thead_credit'] 							= "Kreditkarte";
$lang['thead_balance'] 							= "Gleichgewicht";
$lang['popup_title_paypal_account'] 			= "PayPal-Konto";

// Status
$lang['status_not_assigned'] 					= "Nicht Zugeordnet";
$lang['status_assigned'] 						= "Zugeordnet";
$lang['status_in_progress'] 					= "In Bearbeitung";
$lang['status_completed'] 						= "Vollständig";
$lang['status_not_completed'] 					= "Nicht Vollständig";
$lang['status_none'] 							= "Niemand";
$lang['status_no_data_available'] 				= "Daten nicht vorhanden";
$lang['status_not_set'] 						= "Nicht festgelegt";
$lang['status_pending'] 						= "Ausstehend";
$lang['status_open'] 							= "Offen";
$lang['status_closed'] 							= "Geschlossen";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Aufgabe löschen";
$lang['popup_title_add_todo'] 					= "Aufgabe hinzufügen";
$lang['popup_title_todo'] 						= "Aufgabe";
$lang['db_smallstat_title_projects'] 			= "Projekte";
$lang['db_smallstat_title_tasks'] 				= "Tasks";
$lang['db_smallstat_title_clients'] 			= "Kunden";
$lang['db_smallstat_title_assigned_tasks'] 		= "Zugeordnete Aufgabe";
$lang['db_smallstat_title_in_progress'] 		= "Aufgaben in Bearbeitung";
$lang['db_smallstat_title_completed'] 			= "Abgeschlossene Aufgaben";
$lang['db_smallstat_title_billable_hours'] 		= "Abrechnungsfähige Stunden";
$lang['title_monthly_completed_tasks'] 			= "Monatlich abgeschlossene Aufgaben für";
$lang['title_all_tasks'] 						= "Alle Aufgaben";
$lang['title_tasks_per_project'] 				= "Aufgan / Projekt";
$lang['thead_not_assigned'] 					= "Nicht Zugeordnet";
$lang['thead_assigned'] 						= "Zugeordnet";
$lang['thead_in_progress'] 						= "In Bearbeitung";
$lang['title_todo_list'] 						= "Aufgabenliste";

// Quick Buttons
$lang['title_shortcuts'] 						= "Abkürzungen";

// Bonus
$lang['label_bonus'] 							= "Bonus";

// Projects
$lang['thead_project'] 							= "Projekt";
$lang['thead_client'] 							= "Kunde";
$lang['thead_due_date'] 						= "Fälligkeit";
$lang['thead_status'] 							= "Status";
$lang['thead_actions'] 							= "Aktionen";

// View Project
$lang['title_project'] 							= "Projekt:";
$lang['subtitle_progress_bar'] 					= "Fortschrittsbalken";
$lang['subtitle_client'] 						= "Kunde";
$lang['subtitle_details'] 						= "Details";
$lang['subtitle_description'] 					= "Beschreibung";
$lang['label_view_name'] 						= "Name:";
$lang['label_view_company'] 					= "Firma:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Seit:";
$lang['label_view_added'] 						= "Hinzugefügt:";
$lang['label_view_due_date'] 					= "Fälligkeit:";
$lang['label_view_status'] 						= "Status:";

// Add Project
$lang['title_new_project'] 						= "Neues Projekt";

// Edit Project
$lang['title_edit_project'] 					= "Bearbeite Projekt";
$lang['label_title'] 							= "Titel";
$lang['label_desc'] 							= "Beschreibung";
$lang['label_due_date'] 						= "Fälligkeit";
$lang['label_client'] 							= "Kunde";

// Tasks per Project
$lang['title_tasks_for'] 						= "Aufgaben für";
$lang['thead_task'] 							= "Aufgabe";
$lang['thead_added'] 							= "Hinzugefügt";
$lang['thead_due_date'] 						= "Fälligkeit";
$lang['thead_completed'] 						= "Abgeschlossen";
$lang['thead_developer'] 						= "Entwickler";

// My Tasks
$lang['title_managed_tasks']					= "Verwaltende Aufgaben";
$lang['title_in_progress_tasks'] 				= "Aufgaben in Bearbeitung";
$lang['title_completed_tasks'] 					= "Abgeschlossene Aufgaben";
$lang['tooltip_urgent'] 						= "Dringend";
$lang['tooltip_high']							= "Hoch";

// View Task
$lang['title_task'] 							= "Aufgabe:";
$lang['label_cost'] 							= "Kosten";
$lang['label_hours'] 							= "Stunden";
$lang['label_hours_info'] 						= "(0,5 = 30 Minuten)";
$lang['label_comment'] 							= "Kommentar";
$lang['label_added_by'] 						= "Hinzugefügt von";
$lang['label_view_group'] 						= "Gruppe:";
$lang['label_view_cost'] 						= "Kosten:";
$lang['status_not_available'] 					= "Gerade nicht verfügbar";
$lang['label_view_completed'] 					= "Abgeschlossen:";
$lang['label_quote'] 							= "Quote";
$lang['label_system'] 							= "System";
$lang['label_no_attachment'] 					= "Keine anlage";

// Add Task
$lang['title_new_task'] 						= "Neue Aufgaben";
$lang['label_project'] 							= "Projekt";
$lang['label_attachment']						= "Anhang";
$lang['label_priority']							= "Priorität";
$lang['label_select'] 							= "Wählen";

// Edit Task
$lang['title_edit_task'] 						= "Aufgabe bearbeiten";

// Clients
$lang['title_clients'] 							= "Kunden";
$lang['thead_name'] 							= "Name";
$lang['thead_email'] 							= "E-mail";
$lang['thead_company'] 							= "Firma";

// Add Client
$lang['title_new_client'] 						= "Neuer Kunde";
$lang['label_username'] 						= "Benutzername";
$lang['label_pass'] 							= "Kennwort";
$lang['title_last_clients'] 					= "Letzter Kunde";
$lang['label_send_email'] 						= "E-Mail Senden";

// Edit Client
$lang['title_edit_client'] 						= "Kunden bearbeiten";

// Members
$lang['title_members'] 							= "Mitglieder";
$lang['thead_group'] 							= "Gruppe";
$lang['label_all'] 								= "Alle";

// Add Member
$lang['title_new_member'] 						= "Neues Mitglied";
$lang['label_group'] 							= "Gruppe";
$lang['label_hourly_rate'] 						= "Stundensatz";
$lang['label_per_hour'] 						= "/Stunde";

// Edit Member
$lang['title_edit_member'] 						= "Mitglied bearbeiten";

// Reports
$lang['title_reports']							= "Berichte";
$lang['title_nr_tasks_per'] 					= "# der Aufgaben /";
$lang['title_tasks_per']						= "Aufgaben /";
$lang['label_date'] 							= "Datum:";
$lang['thead_hours'] 							= "Stunden";

// Tickets
$lang['title_tickets'] 							= "Tickets";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Subjekt";
$lang['thead_added_by'] 						= "Hinzugefügt von";

// View Ticket
$lang['title_ticket'] 							= "Ticket:";
$lang['label_details']							= "Details";
$lang['label_view_email']						= "E-mail:";
$lang['label_view_phone']						= "Telefon:";
$lang['label_view_type']						= "Typ:";
$lang['label_view_app_url']						= "App URL:";
$lang['label_subject'] 							= "Subjekt:";
$lang['label_message']							= "Information";
$lang['label_answered_by'] 						= "Beantwortet von";
$lang['label_closed_by'] 						= "Geschlossen von";
$lang['label_type_problem'] 					= "Problem";
$lang['label_type_question'] 					= "Frage";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Ticket Einstellungen";
$lang['label_active'] 							= "Aktiv";
$lang['label_inactive'] 						= "Inaktiv";
$lang['label_text_button'] 						= "Button-Text";
$lang['label_text_color'] 						= "Textfarbe";
$lang['label_button_color']						= "Button-Farbe";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Neue Einstellung";
$lang['label_app_url'] 							= "App URL";
$lang['label_private_key']						= "Privater Schlüssel";
$lang['label_api_script']						= "API Skript";
$lang['label_notified_emails'] 					= "Benachrichtigte E-Mails";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Einstellungen Bearbeiten";

// Notifications
$lang['thead_type'] 							= "Typ";
$lang['thead_message'] 							= "Information";
$lang['title_notifications'] 					= "Benachrichtigungen";
$lang['last_notifications'] 					= "Letzte benachrichtigungen";
$lang['view_all_notifications'] 				= "Sehe alle benachrichtigungen";
$lang['no_notifications'] 						= "Sie haben 0 benachrichtigungen";

// Log
$lang['title_log'] 								= "Log";
$lang['thead_text'] 							= "Text";

// Settings
$lang['title_settings'] 						= "Einstellungen";
$lang['title_general'] 							= "Generell";
$lang['title_groups'] 							= "Gruppe";
$lang['label_contact_email'] 					= "E-mail Kontakt";
$lang['label_accounting_email'] 				= "E-mail der Buchhaltung";
$lang['label_sender_name'] 						= "Absender Name";
$lang['label_sender_email'] 					= "Absender E-mail";
$lang['label_enable_emails'] 					= "Aktiviere E-mails";
$lang['label_multi_language'] 					= "Aktiviere Mehrsprachenfähigkeit";
$lang['label_show_credits'] 					= "Zeige Info";
$lang['label_information'] 						= "Information";
$lang['label_group'] 							= "Gruppe";
$lang['label_enable_tickets'] 					= "Ticket-System Aktivieren";

?>