<?

// Login & Recover
$lang['lgn_login_account'] 						= "Login to your account";
$lang['lgn_username'] 							= "Username";
$lang['lgn_password'] 							= "Password";
$lang['lgn_remember_me'] 						= "Remember me";
$lang['lgn_forgot_pass'] 						= "Forgot Password?";
$lang['lgn_no_problem'] 						= "No problem,";
$lang['lgn_click_here'] 						= "click here";
$lang['lgn_get_new_pass'] 						= "to get a new password!";
$lang['lgn_recover_pass'] 						= "Recover your password";
$lang['lgn_email'] 								= "Email";

// Top
$lang['top_welcome'] 							= "Welcome,";
$lang['top_profile'] 							= "Profile";
$lang['top_transactions'] 						= "Transactions";
$lang['top_logout'] 							= "Logout";

// Menu
$lang['menu_dashboard'] 						= "Dashboard";
$lang['menu_projects'] 							= "Projects";
$lang['menu_tasks'] 							= "My Tasks";
$lang['menu_clients'] 							= "Clients";
$lang['menu_members'] 							= "Members";
$lang['menu_reports']							= "Reports";
$lang['menu_support_tickets']					= "Support Tickets";
$lang['menu_tickets']							= "Tickets";
$lang['menu_tickets_settings']					= "Tickets Settings";
$lang['menu_log'] 								= "Log";
$lang['menu_settings'] 							= "Settings";

// Buttons
$lang['btn_login'] 								= "Login";
$lang['btn_recover'] 							= "Recover";
$lang['btn_save_changes'] 						= "Save Changes";
$lang['btn_cancel'] 							= "Cancel";
$lang['btn_back'] 								= "Back";
$lang['btn_upload'] 							= "Upload";
$lang['btn_cashout'] 							= "Cashout";
$lang['btn_yes'] 								= "Yes";
$lang['btn_no'] 								= "No";
$lang['btn_new_project'] 						= "New Project";
$lang['btn_view_tasks'] 						= "View Tasks";
$lang['btn_view'] 								= "View";
$lang['btn_edit'] 								= "Edit";
$lang['btn_disable'] 							= "Disable";
$lang['btn_delete'] 							= "Delete";
$lang['btn_close_project'] 						= "Close Project";
$lang['btn_edit_project'] 						= "Edit Project";
$lang['btn_new_task'] 							= "New Task";
$lang['btn_close'] 								= "Close";
$lang['btn_quote_task'] 						= "Quote Task";
$lang['btn_edit_task'] 							= "Edit Task";
$lang['btn_complete_task'] 						= "Complete Task";
$lang['btn_send_message'] 						= "Send Message";
$lang['btn_new_client'] 						= "New Client";
$lang['btn_new_member'] 						= "New Member";
$lang['btn_new_ticket_settings'] 				= "New Ticket Settings";
$lang['btn_answer'] 							= "Answer";
$lang['btn_generate_script'] 					= "Generate Script";
$lang['btn_generate'] 							= "Generate";
$lang['btn_copy'] 								= "Copy";
$lang['btn_mark_as_read'] 						= "Mark as Read";

// Messages
$lang['msg_changes_saved'] 						= "Changes saved successfully!";
$lang['msg_passwords_not_match'] 				= "Passwords do not match!";
$lang['msg_email_already_exist'] 				= "Email already exist!";
$lang['msg_invalid_password'] 					= "Invalid current password!";
$lang['msg_complete_all_fields'] 				= "Please complete all fields!";
$lang['msg_changes_not_saved'] 					= "Changes could not be saved!";
$lang['msg_invalid_username_password'] 			= "Invalid username or password!";
$lang['msg_new_login_details'] 					= "Your new login details have been sent to your email address!";
$lang['msg_pass_changed_not_notified'] 			= "Password changed, user wasn't notified!";
$lang['msg_pass_not_saved'] 					= "Password could not be changed!";
$lang['msg_email_not_exist'] 					= "Email address does not exist!";
$lang['msg_want_delete_project'] 				= "Are you sure you want to delete this project?";
$lang['msg_want_close_project'] 				= "Are you sure you want to close this project?";
$lang['msg_want_delete_task'] 					= "Are you sure you want to delete this task?";
$lang['msg_invalid_cost'] 						= "Invalid cost!";
$lang['msg_task_not_completed'] 				= "Task could not be completed!";
$lang['msg_task_assigned_to'] 					= "Task assigned to";
$lang['msg_task_not_assigned'] 					= "Task not assigned yet";
$lang['msg_want_disable_client'] 				= "Are you sure you want to disable this client?";
$lang['msg_want_delete_client'] 				= "Are you sure you want to delete this client?";
$lang['msg_username_already_exist'] 			= "Username already exist!";
$lang['msg_username_and_email_already_exist'] 	= "Username and email already exist!";
$lang['msg_want_disable_member'] 				= "Are you sure you want to disable this member?";
$lang['msg_want_delete_member'] 				= "Are you sure you want to delete this member?";
$lang['msg_want_delete_item'] 					= "Are you sure you want to delete this item?";
$lang['msg_name_of_your_company'] 				= "Set the name of your company.";
$lang['msg_contact_email'] 						= "Set the contact email address.";
$lang['msg_accounting_email'] 					= "Set the accountant email address.";
$lang['msg_name_for_sending_emails'] 			= "Set the name you want to be used for sending emails. e.g. Company Name";
$lang['msg_email_for_sending_emails'] 			= "Set the email address you want to be used for sending emails. e.g. noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Enable sending emails when tasks are assigned, completed, etc.";
$lang['msg_enable_multi_language'] 				= "Enable the multi-language option from the profile page.";
$lang['msg_show_credits'] 						= "Show 'Powered by IntelCoder' on the right bottom of the page.";
$lang['msg_cannot_close_project'] 				= "You need to complete all tasks, in order to be able to close the project!";
$lang['msg_receive_email_notifications'] 		= "Enable receiving emails when tasks are added, completed, etc.";
$lang['msg_receive_online_notifications']		= "Enable receiving online notifications when tasks are added, completed, etc.";
$lang['msg_confirm_delete_ticket'] 				= "Are you sure you want to delete this ticket?";
$lang['msg_copied_to_clipboard'] 				= "Script copied to clipboard!";
$lang['msg_enable_tickets_system'] 				= "Enable the support ticket system.";
$lang['msg_want_delete_settings'] 				= "Are you sure you want to delete this setting?";
$lang['msg_generate_private_key'] 				= "Generate a private key for your client.";
$lang['msg_text_button'] 						= "Set text for the support button.";
$lang['msg_text_color'] 						= "Set text color for the support button.";
$lang['msg_color_button'] 						= "Set background color for the support button.";
$lang['msg_client_domain_url'] 					= "Set the domain where the support tickets will be used. You have to enter the domain without 'http://'. e.g. www.domain.com";
$lang['msg_notified_emails'] 					= "Set one or multiple emails, separated by comma, to receive notifications when support tickets are added.";
$lang['msg_copy_api_script'] 					= "In order to display the support form copy and include this script into your client's website.";
$lang['msg_need_paypal_account'] 				= "To cashout your hours, you need to add a PayPal account on your profile page!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Allowed files: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Profile Picture";
$lang['title_edit_profile'] 					= "Edit Profile";
$lang['title_personal_settings'] 				= "Personal Settings";
$lang['subtitle_personal_details'] 				= "Personal Details";
$lang['subtitle_change_password'] 				= "Change Password";
$lang['label_first_name'] 						= "First Name";
$lang['label_last_name'] 						= "Last Name";
$lang['label_email'] 							= "Email";
$lang['label_paypal_email'] 					= "PayPal Email";
$lang['label_phone'] 							= "Phone";
$lang['label_company'] 							= "Company";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Country";
$lang['label_city'] 							= "City";
$lang['label_language'] 						= "Language";
$lang['label_current_pass'] 					= "Current Password";
$lang['label_new_pass'] 						= "New Password";
$lang['label_confirm_pass'] 					= "Confirm Password";
$lang['label_email_notifications'] 				= "Email Notifications";
$lang['label_online_notifications']				= "Online Notifications";

// Transactions
$lang['title_balance'] 							= "Balance";
$lang['title_hours'] 							= "hours";
$lang['title_transactions'] 					= "Transactions";
$lang['thead_date'] 							= "Date";
$lang['thead_title'] 							= "Title";
$lang['thead_debit'] 							= "Debit";
$lang['thead_credit'] 							= "Credit";
$lang['thead_balance'] 							= "Balance";
$lang['popup_title_paypal_account'] 			= "PayPal Account";

// Status
$lang['status_not_assigned'] 					= "Not Assigned";
$lang['status_assigned'] 						= "Assigned";
$lang['status_in_progress'] 					= "In Progress";
$lang['status_completed'] 						= "Completed";
$lang['status_not_completed'] 					= "Not Completed";
$lang['status_none'] 							= "None";
$lang['status_no_data_available'] 				= "No data available";
$lang['status_not_set'] 						= "Not set";
$lang['status_pending'] 						= "Pending";
$lang['status_open'] 							= "Open";
$lang['status_closed'] 							= "Closed";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Delete To-Do";
$lang['popup_title_add_todo'] 					= "Add To-Do";
$lang['popup_title_todo'] 						= "To-Do";
$lang['db_smallstat_title_projects'] 			= "Projects";
$lang['db_smallstat_title_tasks'] 				= "Tasks";
$lang['db_smallstat_title_clients'] 			= "Clients";
$lang['db_smallstat_title_assigned_tasks'] 		= "Assigned Tasks";
$lang['db_smallstat_title_in_progress'] 		= "In Progress Tasks";
$lang['db_smallstat_title_completed'] 			= "Completed Tasks";
$lang['db_smallstat_title_balance'] 			= "Balance";
$lang['title_monthly_completed_tasks'] 			= "Monthly Completed Tasks For";
$lang['title_all_tasks'] 						= "All Tasks";
$lang['title_tasks_per_project'] 				= "Tasks / Project";
$lang['thead_not_assigned'] 					= "Not Assigned";
$lang['thead_assigned'] 						= "Assigned";
$lang['thead_in_progress'] 						= "In Progress";
$lang['title_todo_list'] 						= "To-Do List";

// Quick Buttons
$lang['title_shortcuts'] 						= "Shortcuts";

// Bonus
$lang['label_bonus'] 							= "Bonus";

// Projects
$lang['thead_project'] 							= "Project";
$lang['thead_client'] 							= "Client";
$lang['thead_due_date'] 						= "Due Date";
$lang['thead_status'] 							= "Status";
$lang['thead_actions'] 							= "Actions";

// View Project
$lang['title_project'] 							= "Project:";
$lang['subtitle_progress_bar'] 					= "Progress Bar";
$lang['subtitle_client'] 						= "Client";
$lang['subtitle_details'] 						= "Details";
$lang['subtitle_description'] 					= "Description";
$lang['label_view_name'] 						= "Name:";
$lang['label_view_company'] 					= "Company:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Since:";
$lang['label_view_added'] 						= "Added:";
$lang['label_view_due_date'] 					= "Due Date:";
$lang['label_view_status'] 						= "Status:";

// Add Project
$lang['title_new_project'] 						= "New Project";

// Edit Project
$lang['title_edit_project'] 					= "Edit Project";
$lang['label_title'] 							= "Title";
$lang['label_desc'] 							= "Description";
$lang['label_due_date'] 						= "Due Date";
$lang['label_client'] 							= "Client";

// Tasks per Project
$lang['title_tasks_for'] 						= "Tasks For";
$lang['thead_task'] 							= "Task";
$lang['thead_added'] 							= "Added";
$lang['thead_due_date'] 						= "Due Date";
$lang['thead_completed'] 						= "Completed";
$lang['thead_developer'] 						= "Developer";

// My Tasks
$lang['title_managed_tasks']					= "Managed Tasks";
$lang['title_in_progress_tasks'] 				= "In Progress Tasks";
$lang['title_completed_tasks'] 					= "Completed Tasks";
$lang['tooltip_urgent'] 						= "Urgent";
$lang['tooltip_high']							= "High";

// View Task
$lang['title_task'] 							= "Task:";
$lang['label_cost'] 							= "Cost";
$lang['label_hours'] 							= "hours";
$lang['label_hours_info'] 						= "(0.5 = 30 minutes)";
$lang['label_comment'] 							= "Comment";
$lang['label_added_by'] 						= "Added By";
$lang['label_view_group'] 						= "Group:";
$lang['label_view_cost'] 						= "Cost:";
$lang['status_not_available'] 					= "Not available yet";
$lang['label_view_completed'] 					= "Completed:";
$lang['label_quote'] 							= "Quote";
$lang['label_system'] 							= "System";
$lang['label_no_attachment'] 					= "No attachment";

// Add Task
$lang['title_new_task'] 						= "New Task";
$lang['label_project'] 							= "Project";
$lang['label_attachment']						= "Attachment(s)";
$lang['label_priority']							= "Priority";
$lang['label_select'] 							= "Select";

// Edit Task
$lang['title_edit_task'] 						= "Edit Task";

// Clients
$lang['title_clients'] 							= "Clients";
$lang['thead_name'] 							= "Name";
$lang['thead_email'] 							= "Email";
$lang['thead_company'] 							= "Company";

// Add Client
$lang['title_new_client'] 						= "New Client";
$lang['label_username'] 						= "Username";
$lang['label_pass'] 							= "Password";
$lang['title_last_clients'] 					= "Last Clients";
$lang['label_send_email'] 						= "Send Email";

// Edit Client
$lang['title_edit_client'] 						= "Edit Client";

// Members
$lang['title_members'] 							= "Members";
$lang['thead_group'] 							= "Group";
$lang['label_all'] 								= "All";

// Add Member
$lang['title_new_member'] 						= "New Member";
$lang['label_group'] 							= "Group";
$lang['label_hourly_rate'] 						= "Hourly Rate";
$lang['label_per_hour'] 						= "/hour";

// Edit Member
$lang['title_edit_member'] 						= "Edit Member";

// Reports
$lang['title_reports']							= "Reports";
$lang['title_nr_tasks_per'] 					= "# of Tasks /";
$lang['title_tasks_per']						= "Tasks /";
$lang['label_date'] 							= "Date:";
$lang['thead_hours'] 							= "Hours";

// Tickets
$lang['title_tickets'] 							= "Tickets";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Subject";
$lang['thead_added_by'] 						= "Added By";

// View Ticket
$lang['title_ticket'] 							= "Ticket:";
$lang['label_details']							= "Details";
$lang['label_view_email']						= "Email:";
$lang['label_view_phone']						= "Phone:";
$lang['label_view_type']						= "Type:";
$lang['label_view_app_url']						= "App URL:";
$lang['label_subject'] 							= "Subject:";
$lang['label_message']							= "Message:";
$lang['label_answered_by'] 						= "Answered by";
$lang['label_closed_by'] 						= "Closed by";
$lang['label_type_problem'] 					= "Issue";
$lang['label_type_question'] 					= "Question";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Tickets Settings";
$lang['label_active'] 							= "Active";
$lang['label_inactive'] 						= "Inactive";
$lang['label_text_button'] 						= "Text Button";
$lang['label_text_color'] 						= "Text Color";
$lang['label_button_color']						= "Button Color";

// Add Ticket Settings
$lang['title_new_settings'] 					= "New Settings";
$lang['label_app_url'] 							= "App URL";
$lang['label_private_key']						= "Private Key";
$lang['label_api_script']						= "API Script";
$lang['label_notified_emails'] 					= "Notified Emails";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Edit Settings";

// Notifications
$lang['thead_type'] 							= "Type";
$lang['thead_message'] 							= "Message";
$lang['title_notifications'] 					= "Notifications";
$lang['last_notifications'] 					= "Latest notifications";
$lang['view_all_notifications'] 				= "View all notifications";
$lang['no_notifications'] 						= "You have 0 notifications";

// Log
$lang['title_log'] 								= "Log";
$lang['thead_text'] 							= "Text";

// Settings
$lang['title_settings'] 						= "Settings";
$lang['title_general'] 							= "General";
$lang['title_groups'] 							= "Groups";
$lang['label_contact_email'] 					= "Contact Email";
$lang['label_accounting_email'] 				= "Accounting Email";
$lang['label_sender_name'] 						= "Sender Name";
$lang['label_sender_email'] 					= "Sender Email";
$lang['label_enable_emails'] 					= "Enable Emails";
$lang['label_multi_language'] 					= "Enable Multi-Language";
$lang['label_show_credits'] 					= "Show Credits";
$lang['label_information'] 						= "Information";
$lang['label_group'] 							= "Group";
$lang['label_enable_tickets'] 					= "Enable Ticket System";

?>