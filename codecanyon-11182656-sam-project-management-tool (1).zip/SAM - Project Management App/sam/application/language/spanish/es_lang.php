<?

// Login & Recover
$lang['lgn_login_account'] 						= "Iniciar su cuenta";
$lang['lgn_username'] 							= "Usuario";
$lang['lgn_password'] 							= "Contraseña";
$lang['lgn_remember_me'] 						= "Recordarme";
$lang['lgn_forgot_pass'] 						= "Olvidar Contraña?";
$lang['lgn_no_problem'] 						= "Ningun problema,";
$lang['lgn_click_here'] 						= "click aqui";
$lang['lgn_get_new_pass'] 						= "para recibir nueva contraseña!";
$lang['lgn_recover_pass'] 						= "Recuperar contraseña";
$lang['lgn_email'] 								= "Correo Electronico";

// Top
$lang['top_welcome'] 							= "Bienvenido,";
$lang['top_profile'] 							= "Perfil";
$lang['top_transactions'] 						= "Transacciones";
$lang['top_logout'] 							= "Salir";

// Menu
$lang['menu_dashboard'] 						= "Panel Informacion";
$lang['menu_projects'] 							= "Proyectos";
$lang['menu_tasks'] 							= "Mis Tareas";
$lang['menu_clients'] 							= "Clientes";
$lang['menu_members'] 							= "Miembros";
$lang['menu_reports']							= "Informes";
$lang['menu_support_tickets']					= "Tickets de Soporte";
$lang['menu_tickets']							= "Tickets";
$lang['menu_tickets_settings']					= "Configuracion de Tickets";
$lang['menu_log'] 								= "Archivo de Registro";
$lang['menu_settings'] 							= "Ajustes";

// Buttons
$lang['btn_login'] 								= "Entrar";
$lang['btn_recover'] 							= "Recuperar";
$lang['btn_save_changes'] 						= "Guardar Cambios";
$lang['btn_cancel'] 							= "Cancelar";
$lang['btn_back'] 								= "Atras";
$lang['btn_upload'] 							= "Cargar";
$lang['btn_cashout'] 							= "Retirar";
$lang['btn_yes'] 								= "Si";
$lang['btn_no'] 								= "No";
$lang['btn_new_project'] 						= "Nuevo Proyecto";
$lang['btn_view_tasks'] 						= "Visualizar Tareas";
$lang['btn_view'] 								= "Visualizar";
$lang['btn_edit'] 								= "Editar";
$lang['btn_disable'] 							= "Desactivar";
$lang['btn_delete'] 							= "Borrar";
$lang['btn_close_project'] 						= "Cerrar Proyecto";
$lang['btn_edit_project'] 						= "Editar Proyecto";
$lang['btn_new_task'] 							= "Nueva Tarea";
$lang['btn_close'] 								= "Cerrar";
$lang['btn_quote_task'] 						= "Estimacion de Tarea";
$lang['btn_edit_task'] 							= "Redactar Tareas";
$lang['btn_complete_task'] 						= "Completar Tareas";
$lang['btn_send_message'] 						= "Mandar Mensaje";
$lang['btn_new_client'] 						= "Nuevo Cliente";
$lang['btn_new_member'] 						= "Nuevo Miembro";
$lang['btn_new_ticket_settings'] 				= "Nueva Configuracion de Ticket";
$lang['btn_answer'] 							= "Contestar";
$lang['btn_generate_script'] 					= "Generar Script";
$lang['btn_generate'] 							= "Generar";
$lang['btn_copy'] 								= "Copiar";
$lang['btn_mark_as_read'] 						= "Marcar como Leído";

// Messages
$lang['msg_changes_saved'] 						= "Los cambios han guardado correctamente!";
$lang['msg_passwords_not_match'] 				= "Contraseña no coinciden!";
$lang['msg_email_already_exist'] 				= "Correo electronico ya existe!";
$lang['msg_invalid_password'] 					= "Contraseña incorrecta!";
$lang['msg_complete_all_fields'] 				= "Por favor rellenar totdos los campos!";
$lang['msg_changes_not_saved'] 					= "Los cambios no se han podido guardar!";
$lang['msg_invalid_username_password'] 			= "Usuario o contraseña incorrectos!";
$lang['msg_new_login_details'] 					= "Sus nuevos datos de contacto se han mandado a su direccion de correo electronico!";
$lang['msg_pass_changed_not_notified'] 			= "Contraseña cambiada, usuario no avisado!";
$lang['msg_pass_not_saved'] 					= "La contraseña no se ha podido modificar!";
$lang['msg_email_not_exist'] 					= "Direccion de correo inexistente!";
$lang['msg_want_delete_project'] 				= "Seguro que quiere borrar este proyecto?";
$lang['msg_want_close_project'] 				= "Seguro que quiere cerrar este proyecto?";
$lang['msg_want_delete_task'] 					= "Seguro que quiere eliminar esta tarea?";
$lang['msg_invalid_cost'] 						= "Precio invalido!";
$lang['msg_task_not_completed'] 				= "La tarea no ha podido ser acabada!";
$lang['msg_task_assigned_to'] 					= "Tarea asignada a";
$lang['msg_task_not_assigned'] 					= "Tarea no asignada todavia";
$lang['msg_want_disable_client'] 				= "Esta seguro de querer desactivar este cliente?";
$lang['msg_want_delete_client'] 				= "Esta seguro de querer borrar este cliente?";
$lang['msg_username_already_exist'] 			= "Usuario ya existente!";
$lang['msg_username_and_email_already_exist'] 	= "Usuario y contraseña ya existente!";
$lang['msg_want_disable_member'] 				= "Esta seguro de querer desactivar este miembro?";
$lang['msg_want_delete_member'] 				= "Esta seguro de querer borrar este miembro?";
$lang['msg_want_delete_item'] 					= "Esta seguro de querer borrar este elemento?";
$lang['msg_name_of_your_company'] 				= "Asignar nombre para su empresa.";
$lang['msg_contact_email'] 						= "Establecer el correo electronico del contacto.";
$lang['msg_accounting_email'] 					= "Establecer el correo electronico para contabilidad.";
$lang['msg_name_for_sending_emails'] 			= "Eliga el nombre que sera utilizado para mandar mails.";
$lang['msg_email_for_sending_emails'] 			= "Elija la direcction de correo electronico que sera utilizada para mandar mails. p.ej. noreply@domain.com";
$lang['msg_enable_sending_emails'] 				= "Activar recibir correos electronicos cuando las tareas estan añadidas, finalizadas, etc.";
$lang['msg_enable_multi_language'] 				= "Encender el multi-lenguaje en la pagina de inicio.";
$lang['msg_show_credits'] 						= "Mostrar 'Powered by IntelCoder' arriba en la parte derecha de la pagina.";
$lang['msg_cannot_close_project'] 				= "Debe completar todas las tareas, para poder cerrar el proyecto!";
$lang['msg_receive_email_notifications'] 		= "Activar mandar correos electronicos cuando las tareas estan añadidas, finalizadas, etc.";
$lang['msg_receive_online_notifications']		= "Activar mandar online cuando las tareas estan añadidas, finalizadas, etc.";
$lang['msg_confirm_delete_ticket'] 				= "Esta seguro de querer borrar este tiket?";
$lang['msg_copied_to_clipboard'] 				= "Script copiado al clipboard!";
$lang['msg_enable_tickets_system'] 				= "Activar el sistema de tickets.";
$lang['msg_want_delete_settings'] 				= "Esta seguro de querer borrar estos ajustes?";
$lang['msg_generate_private_key'] 				= "Generar una clave unica para vuestro cliente.";
$lang['msg_text_button'] 						= "Establecer texto para boton de soporte.";
$lang['msg_text_color'] 						= "Color del texto establecido para boton de soporte.";
$lang['msg_color_button'] 						= "Establecer el color para boton de soporte.";
$lang['msg_client_domain_url'] 					= "Establecer el URL en el que se utilizarán los tickets de soporte. Tienes que entrar en el URL sin 'http://'. p.ej. www.domain.com";
$lang['msg_notified_emails'] 					= "Establecer uno o mas correos electronicos, separados por coma, para recibir las notificaciones cuando se añaden tickets de soporte.";
$lang['msg_copy_api_script'] 					= "Copiar el script e incluir en la web del cliente. El script mostrará el formulario de soporte.";
$lang['msg_need_paypal_account'] 				= "Para cobrar las horas acumuladas tiene que añadir una cuenta de PayPal en su pagina de perfil!";

// Dropzone
$lang['label_allowed_file_types'] 				= "Archivos permitidos: png / jpg / jpeg / zip / pdf / doc / docx / xls / xlsx / txt / csv / odt / psd / ai";

// Profile
$lang['title_profile_picture'] 					= "Foto de Perfil";
$lang['title_edit_profile'] 					= "Editar Perfil";
$lang['title_personal_settings'] 				= "Ajustes Personales";
$lang['subtitle_personal_details'] 				= "Detalles Personales";
$lang['subtitle_change_password'] 				= "Cambiar Contraseña";
$lang['label_first_name'] 						= "Nombre";
$lang['label_last_name'] 						= "Apellidos";
$lang['label_email'] 							= "Mail";
$lang['label_paypal_email'] 					= "PayPal Mail";
$lang['label_phone'] 							= "Telefono";
$lang['label_company'] 							= "Empresa";
$lang['label_url'] 								= "URL";
$lang['label_country'] 							= "Pais";
$lang['label_city'] 							= "Ciudad";
$lang['label_language'] 						= "Idioma";
$lang['label_current_pass'] 					= "Actual Contraseña";
$lang['label_new_pass'] 						= "Nueva Contraseña";
$lang['label_confirm_pass'] 					= "Confirmar Contraseña";
$lang['label_email_notifications'] 				= "Notificaciones por Correo Electronico";
$lang['label_online_notifications']				= "Notificaciones Online";

// Transactions
$lang['title_balance'] 							= "Saldo";
$lang['title_hours'] 							= "Horas";
$lang['title_transactions'] 					= "Transacciones";
$lang['thead_date'] 							= "Fecha";
$lang['thead_title'] 							= "Titulo";
$lang['thead_debit'] 							= "Debito";
$lang['thead_credit'] 							= "Credito";
$lang['thead_balance'] 							= "Saldo";
$lang['popup_title_paypal_account'] 			= "Cuenta de PayPal";

// Status
$lang['status_not_assigned'] 					= "No Asignado";
$lang['status_assigned'] 						= "Asignado";
$lang['status_in_progress'] 					= "En Proceso";
$lang['status_completed'] 						= "Completo";
$lang['status_not_completed'] 					= "No Finalizado";
$lang['status_none'] 							= "Ninguno";
$lang['status_no_data_available'] 				= "Sin datos disponibles";
$lang['status_not_set'] 						= "No establecido";
$lang['status_pending'] 						= "Pendiente";
$lang['status_open'] 							= "En Curso";
$lang['status_closed'] 							= "Finalizado";

// Dashboard
$lang['popup_title_delete_todo'] 				= "Borrar To-Do";
$lang['popup_title_add_todo'] 					= "Añadir To-Do";
$lang['popup_title_todo'] 						= "To-Do";
$lang['db_smallstat_title_projects'] 			= "Proyectos";
$lang['db_smallstat_title_tasks'] 				= "Tareas";
$lang['db_smallstat_title_clients'] 			= "Clientes";
$lang['db_smallstat_title_assigned_tasks'] 		= "Tareas Asignadas";
$lang['db_smallstat_title_in_progress'] 		= "En Proceso";
$lang['db_smallstat_title_completed'] 			= "Finalizado";
$lang['db_smallstat_title_balance'] 			= "Saldo";
$lang['title_monthly_completed_tasks'] 			= "Tareas Finalizadas Al Mes";
$lang['title_all_tasks'] 						= "Todas Las Tareas";
$lang['title_tasks_per_project'] 				= "Tareas / Proyectos";
$lang['thead_not_assigned'] 					= "No Asignado";
$lang['thead_assigned'] 						= "Asignado";
$lang['thead_in_progress'] 						= "En Proceso";
$lang['title_todo_list'] 						= "Lista To-Do";

// Quick Buttons
$lang['title_shortcuts'] 						= "Accesos Directos";

// Bonus
$lang['label_bonus'] 							= "Prima";

// Projects
$lang['thead_project'] 							= "Proyecto";
$lang['thead_client'] 							= "Cliente";
$lang['thead_due_date'] 						= "Fecha Finalizacion";
$lang['thead_status'] 							= "Estado";
$lang['thead_actions'] 							= "Acciones";

// View Project
$lang['title_project'] 							= "Proyecto:";
$lang['subtitle_progress_bar'] 					= "Barra de Progreso";
$lang['subtitle_client'] 						= "Cliente";
$lang['subtitle_details'] 						= "Detalle";
$lang['subtitle_description'] 					= "Describir";
$lang['label_view_name'] 						= "Nombre:";
$lang['label_view_company'] 					= "Empresa:";
$lang['label_view_url'] 						= "URL:";
$lang['label_view_since'] 						= "Registrado Desde:";
$lang['label_view_added'] 						= "Añadido:";
$lang['label_view_due_date'] 					= "Fecha Finalizacion:";
$lang['label_view_status'] 						= "Estado:";

// Add Project
$lang['title_new_project'] 						= "Nuevo Proyecto";

// Edit Project
$lang['title_edit_project'] 					= "Editar Proyecto";
$lang['label_title'] 							= "Titulo";
$lang['label_desc'] 							= "Descripción";
$lang['label_due_date'] 						= "Fecha Finalizacion";
$lang['label_client'] 							= "Cliente";

// Tasks per Project
$lang['title_tasks_for'] 						= "Tareas Para";
$lang['thead_task'] 							= "Tareas";
$lang['thead_added'] 							= "Añadido";
$lang['thead_due_date'] 						= "Fecha Finalizacion";
$lang['thead_completed'] 						= "Completo";
$lang['thead_developer'] 						= "Revelador";

// My Tasks
$lang['title_managed_tasks']					= "Tareas Gestionadas";
$lang['title_in_progress_tasks'] 				= "Tareas En Proceso";
$lang['title_completed_tasks'] 					= "Tareas Completas";
$lang['tooltip_urgent'] 						= "Urgente";
$lang['tooltip_high']							= "Maxima";

// View Task
$lang['title_task'] 							= "Tareas:";
$lang['label_cost'] 							= "Precio";
$lang['label_hours'] 							= "Horas";
$lang['label_hours_info'] 						= "(0.5 = 30 minutos)";
$lang['label_comment'] 							= "Comentario";
$lang['label_added_by'] 						= "Añadido Por";
$lang['label_view_group'] 						= "Groupo:";
$lang['label_view_cost'] 						= "precio:";
$lang['status_not_available'] 					= "No disponible todavia";
$lang['label_view_completed'] 					= "Completo:";
$lang['label_quote'] 							= "Fecha Probable";
$lang['label_system'] 							= "Sistema";
$lang['label_no_attachment'] 					= "No hay archivos adjuntos";

// Add Task
$lang['title_new_task'] 						= "Nueva Tarea";
$lang['label_project'] 							= "Proyecto";
$lang['label_attachment']						= "Adjuntar Archivo(s)";
$lang['label_priority']							= "Prioridad";
$lang['label_select'] 							= "Seleccionar";

// Edit Task
$lang['title_edit_task'] 						= "Editar Tareas";

// Clients
$lang['title_clients'] 							= "Clientes";
$lang['thead_name'] 							= "Nombre";
$lang['thead_email'] 							= "Correo Electronico";
$lang['thead_company'] 							= "Empresa";

// Add Client
$lang['title_new_client'] 						= "Nuevo Cliente";
$lang['label_username'] 						= "Usuario";
$lang['label_pass'] 							= "Contraseña";
$lang['title_last_clients'] 					= "Ultimos Clientes";
$lang['label_send_email'] 						= "Enviar por Correo Electronico";

// Edit Client
$lang['title_edit_client'] 						= "Editar Cliente";

// Members
$lang['title_members'] 							= "Miembros";
$lang['thead_group'] 							= "Grupos";
$lang['label_all'] 								= "Todos";

// Add Member
$lang['title_new_member'] 						= "Nuevo Miembro";
$lang['label_group'] 							= "Grupo";
$lang['label_hourly_rate'] 						= "Tarifas";
$lang['label_per_hour'] 						= "/hora";

// Edit Member
$lang['title_edit_member'] 						= "Editar Miembros";

// Reports
$lang['title_reports']							= "Informes";
$lang['title_nr_tasks_per'] 					= "# de Tareas /";
$lang['title_tasks_per']						= "Tareas /";
$lang['label_date'] 							= "Fecha:";
$lang['thead_hours'] 							= "Horas";

// Tickets
$lang['title_tickets'] 							= "Tickets";
$lang['thead_id'] 								= "ID";
$lang['thead_subject'] 							= "Sujeto";
$lang['thead_added_by'] 						= "Añadido Por";

// View Ticket
$lang['title_ticket'] 							= "Ticket:";
$lang['label_details']							= "Detalles";
$lang['label_view_email']						= "Correo Electronico:";
$lang['label_view_phone']						= "Telefono:";
$lang['label_view_type']						= "Tipo:";
$lang['label_view_app_url']						= "URL App:";
$lang['label_subject'] 							= "Sujeto:";
$lang['label_message']							= "Mensaje";
$lang['label_answered_by'] 						= "Le ha atendido";
$lang['label_closed_by'] 						= "Finalizado por";
$lang['label_type_problem'] 					= "Problema Tecnico";
$lang['label_type_question'] 					= "Pregunta";

// Ticket Settings
$lang['title_ticket_settings'] 					= "Configuracion de Ticket";
$lang['label_active'] 							= "Activo";
$lang['label_inactive'] 						= "Inactivo";
$lang['label_text_button'] 						= "Boton de Texto";
$lang['label_text_color'] 						= "Color del Texto";
$lang['label_button_color']						= "Color del Boton";

// Add Ticket Settings
$lang['title_new_settings'] 					= "Nueva Configuracion";
$lang['label_app_url'] 							= "URL App";
$lang['label_private_key']						= "Clave Privada";
$lang['label_api_script']						= "API Script";
$lang['label_notified_emails'] 					= "Correos Electronicos Notificados";

// Edit Ticket Settings
$lang['title_edit_settings'] 					= "Editar Configuracion";

// Notifications
$lang['thead_type'] 							= "Tipo";
$lang['thead_message'] 							= "Mensaje";
$lang['title_notifications'] 					= "Avisos";
$lang['last_notifications'] 					= "Últimos avisos";
$lang['view_all_notifications'] 				= "Ver todas las avisos";
$lang['no_notifications'] 						= "Usted tiene 0 avisos";

// Log
$lang['title_log'] 								= "Archivo de Registro";
$lang['thead_text'] 							= "Texto";

// Settings
$lang['title_settings'] 						= "Configuracion";
$lang['title_general'] 							= "General";
$lang['title_groups'] 							= "Grupos";
$lang['label_contact_email'] 					= "Correo Electronico de Contacto";
$lang['label_accounting_email'] 				= "Correo Electronico de Contabilidad";
$lang['label_sender_name'] 						= "Remitente";
$lang['label_sender_email'] 					= "Correo Electronico Remitente";
$lang['label_enable_emails'] 					= "Activar Correos Electronicos";
$lang['label_multi_language'] 					= "Activar Multi-Lenguaje";
$lang['label_show_credits'] 					= "Enseñar Creditos";
$lang['label_information'] 						= "Informacion";
$lang['label_group'] 							= "Grupo";
$lang['label_enable_tickets'] 					= "Activar el Sistema de Tickets";

?>