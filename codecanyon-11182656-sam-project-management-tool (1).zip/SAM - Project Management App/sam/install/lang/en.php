<?php
class Lang
{
	public $hash = array(
		"WELCOME" 								=> array(
			"WELCOME_TITLE" 					=> "Welcome to SAM App Installer",
			"WELCOME_MSG"						=> "Before proceeding with the full installation, we will carry out some tests on your server configuration to ensure that you are able to install and run our software.",
			"WELCOME_REQUIREMENTS" 				=> "Server Requirements",
			"WELCOME_CHECK" 					=> "CHECK",
			"WELCOME_STATUS" 					=> "STATUS",
			"OPTION_OK"  						=> "OK <span class='glyphicon glyphicon-ok' style='color: green;'></span>",
			"OPTION_WRONG" 						=> "NO <span class='glyphicon glyphicon-remove' style='color: red;'>",
			"OPTIONS" 							=> array(),
			"WELCOME_BUTTON_START" 				=> "Start"
		),

		"STEP_1" 								=> array(
			"STEP1_TITLE" 						=> "Folder Path",
			"STEP1_MSG" 						=> "Type here the path where <b>SAM</b> is located. Please make sure everything is correct before you continue on to the next step.<br />If you do something wrong you can correct the path in this file: application/config/config.php",
			"STEP1_PATH_LBL" 					=> "PATH FOR SAM",
			// "STEP1_PATH_PLACEHOLDER" 			=> "http://sam.yourdomain.com/, http://www.yourdomain.com/sam",
			"STEP1_PATH_SUGGESTION" 			=> "<span style='color: red;'>Last slash is required</span> - e.g. http://sam.yourdomain.com/, http://www.yourdomain.com/sam/ or wherever is your SAM located!",
			"STEP1_BUTTON_NEXT" 				=> "Next"
		),

		"STEP_2" 								=> array(
			"STEP2_TITLE" 						=> "Database Connection",
			"STEP2_MSG" 						=> "Specify your database settings here. Please note that the database for our software must be created prior to this step. If you have not created one yet, do so now.",
			"STEP2_DBNAME_LBL" 					=> "DATABASE NAME",
			// "STEP2_DBNAME_PLACEHOLDER" 		=> "The database name",
			"STEP2_DBNAME_SUGGESTION" 			=> "Type here the database name.",
			"STEP2_DBUSER_LBL" 					=> "DATABASE USERNAME",
			// "STEP2_DBUSER_PLACEHOLDER" 		=> "The database username",
			"STEP2_DBUSER_SUGGESTION" 			=> "Type here the database username.",
			"STEP2_DBPASS_LBL" 					=> "DATABASE PASSWORD",
			// "STEP2_DBPASS_PLACEHOLDER" 		=> "The database password",
			"STEP2_DBPASS_SUGGESTION" 			=> "The password to access to the database with the user you have written before.",
			"STEP2_DBHOST_LBL" 					=> "DATABASE HOST",
			"STEP2_DBHOST_SUGGESTION" 			=> "The host where the database is located. Usually it's <b>localhost</b>.",
			"STEP2_DBPREFIX_LBL" 				=> "DATABASE'S TABLES PREFIX",
			"STEP2_DBPREFIX_PLACEHOLDER" 		=> "sam_",
			"STEP2_DBPREFIX_SUGGESTION" 		=> "<b>Optional</b> - Fill this if you wanna have multiple installations of SAM.",
			"STEP2_BUTTON_NEXT" 				=> "Next"
		),

		"STEP_3" 								=> array(
			"STEP3_TITLE" 						=> "Administrator Account",
			"STEP3_MSG" 						=> "Database tables have been <b>successfully created</b>! You may now set up an administrator account for yourself.",
			"STEP3_ADMINUSER" 					=> "ADMIN USERNAME",
			// "STEP3_ADMINUSER_PLACEHOLDER" 	=> "The admin username",
			"STEP3_ADMINUSER_SUGGESTION" 		=> "Type here the admin username.",
			"STEP3_ADMINPASS" 					=> "ADMIN PASSWORD",
			// "STEP3_ADMINPASS_PLACEHOLDER" 	=> "The admin password",
			"STEP3_ADMINPASS_SUGGESTION" 		=> "Type here the password for the admin username.",
			"BUTTON_NEXT" 						=> "Next",
		),

		"STEP_4" 								=> array(
			"STEP4_TITLE" 						=> "Installation Completed",
			"STEP4_MSG" 						=> "The installation process has finished and the Administrator's account has been successfully created.<br />Now, please <font color='red'>remove the installation folder</font> (<b>install</b>) and then you're almost ready to go!"
		)
	);
}
?>