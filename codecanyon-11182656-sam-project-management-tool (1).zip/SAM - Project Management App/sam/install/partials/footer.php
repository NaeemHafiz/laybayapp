<div id="footer">
	<div class="container">
    	<div class="text-muted credit" style="float: left;">Copyright &copy; 2013 - <?=date("Y");?> <a href="https://intelcoder.com" target="_blank">IntelCoder</a></div>
    	<div class="text-muted credit" style="float: right;"><? if (Config::APP_VERS) echo "v".Config::APP_VERS; ?></div>
	</div>
</div>