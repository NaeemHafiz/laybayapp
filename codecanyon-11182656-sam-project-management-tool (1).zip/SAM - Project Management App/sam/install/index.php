<?php require_once "core.php"; ?>

<!doctype html>
<html>
<head>
	<title><?php echo Config::APP_NAME; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/main.css" type="text/css">
	<link rel="shortcut icon" href="img/favicon.ico" />
</head>

<body>
	<div id="wrap">
		<?php include_once Config::TPL_DIR . Config::DIR_SEP . "header.php"; ?>
		<?php include_once Config::TPL_DIR . Config::DIR_SEP . "error.php"; ?>
		<?php $router->check(); ?>
	</div>
	<?php include_once Config::TPL_DIR . Config::DIR_SEP . "footer.php"; ?>
</body>

<script type="text/javascript" src="//code.jquery.com/jquery.js" /></script>
<script type="text/javascript" src="js/bootstrap.min.js" /></script>
</html>