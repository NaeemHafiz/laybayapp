<?php
session_start();

// Load the config file
require_once "config.class.php";

// Load the controller class
require_once "lib/class.db.php";

// Load the controller class
require_once "lib/controllers.php";

// Load the file class
require_once "lib/class.file.php";
require_once "lib/class.file2.php";

// Load the file lang ( this will be dynamic after )
require_once "lang" . Config::DIR_SEP . "en.php";

// Load all the dependencies
require_once "vendor" . Config::DIR_SEP . "autoload.php"; 

class Router{

	protected $route;
	protected $tpl;
	protected $template;
	protected $hash;
	protected $lang;
	protected $_db;
	protected $_file;
	protected $_file2;

	/**
	 *
	 * Constructor Dependency Injection
	 *
	 * @param $tpl instanceof Mustache_Engine
	 * @param $lang instanceof Lang
	 * @param $lang instanceof Config
	 *
	 */
	public function __construct($tpl, $lang, $db, $file, $file2) {
		$this->tpl 		= ($tpl instanceof Mustache_Engine) ? $tpl : die("ERROR: You must pass only Mustache_Engine object.");
		$this->lang		= ($lang instanceof Lang) ? $lang : die("ERROR: You must pass only Lang object.");
		$this->_db 		= ($db instanceof ControllerDB) ? $db : die("ERROR: You must pass only ControllerDB object.");
		$this->_file 	= ($file instanceof File) ? $file : die("ERROR: You must pass only File object.");
		$this->_file2 	= ($file2 instanceof File2) ? $file2 : die("ERROR: You must pass only File2 object.");
		$this->route 	= isset($_GET['step']) ? $_GET['step'] : null ;
		
		//$this->ctrl 	= ($ctrl instanceof Controller) ? $ctrl : die("ERROR: You must pass only Controller object.");

	}

	public function check(){
		switch ($this->route)
		{
			case 1: $this->first(); break;
			case 2: $this->second(); break;
			case 3: $this->third(); break;
			case 4: $this->fourth(); break;
			default: $this->welcome(); break;
		}
	}

	public function welcome()
	{
		$this->template = file_get_contents(Config::TPL_DIR . Config::DIR_SEP . "welcome.mustache");
		$this->hash 	= $this->lang->hash['WELCOME'];
		$this->requiring( ); // compose the lang necessary files
		$this->render();
	}

	public function first()
	{
		$this->template = file_get_contents(Config::TPL_DIR . Config::DIR_SEP . "1step.mustache");
		$this->hash 	= $this->lang->hash['STEP_1'];
		$this->render();
	}

	public function second()
	{
		// Set session path only when don't get the error message
		if (strlen($_GET['error']) < 1)
		{
			$_SESSION['path'] = (isset($_POST['path'])) ? $_POST['path'] : null;
		}

		if ($this->firstStepApply())
		{
			$this->template = file_get_contents(Config::TPL_DIR . Config::DIR_SEP . "2step.mustache");
			$this->hash 	= $this->lang->hash['STEP_2'];
			$this->render();
		}
		else
		{
			if (headers_sent())
			{
			    echo "<script type='text/javascript'>window.location = '".$_SERVER["PHP_SELF"]."?step=1&error=".$_GET['error']."';</script>";
			    die();
			}
			else
			{
			    exit(header("Location: ".$_SERVER["PHP_SELF"]."?step=1&error=".$_GET['error'].""));
			}
		}
	}

	public function third()
	{
		if ($this->secondStepApply())
		{
			$this->template = file_get_contents(Config::TPL_DIR . Config::DIR_SEP . "3step.mustache");
			$this->hash 	= $this->lang->hash['STEP_3'];
			$this->render();
		}
		else
		{
			if (headers_sent())
			{
			    echo "<script type='text/javascript'>window.location = '".$_SERVER["PHP_SELF"]."?step=2&error=".$_GET['error']."';</script>";
			    die();
			}
			else
			{
			    exit(header("Location: ".$_SERVER["PHP_SELF"]."?step=2&error=".$_GET['error'].""));
			}
		}
	}

	public function fourth()
	{
		if ($this->thirdStepApply())
		{
			$this->template = file_get_contents(Config::TPL_DIR . Config::DIR_SEP . "4step.mustache");
			$this->hash 	= $this->lang->hash['STEP_4'];
			$this->render();
		}
		else
		{
			if (headers_sent())
			{
			    echo "<script type='text/javascript'>window.location = '".$_SERVER["PHP_SELF"]."?step=3&error=".$_GET['error']."';</script>";
			    die();
			}
			else
			{
			    exit(header("Location: ".$_SERVER["PHP_SELF"]."?step=3&error=".$_GET['error'].""));
			}
		}
	}



	// Create the config.php file
	public function firstStepApply()
	{
		clearstatcache(); //die("queries.sql");

		if (file_exists(dirname(Config::ROOT) . Config::DIR_SEP . "file_path.txt"))
		{
			$this->_file->write(file_get_contents("file_path.txt"));
			return true;
		}
		else
		{
			$this->logError("Cannot find the file: file_path.txt");
			return false; #die("cannot find the file file_path.txt"); // file queries.sql does not exist
		}
	}

	// Create the database.php file and run the query for database creation
	public function secondStepApply()
	{
		if ($this->_db->createConnection())
		{
			clearstatcache(); //die("queries.sql");
			#chmod(dirname(Config::ROOT).Config::DIR_SEP."file_config.txt", 777);

			if (file_exists(dirname(Config::ROOT) . Config::DIR_SEP . "file_config.txt"))
			{
				$this->_file2->write(file_get_contents("file_config.txt"));
				$this->_db->query( $this->_db->parseMuphVariables(file_get_contents("file_database.txt")));
				return true;
			}
			else
			{
				$this->logError("Cannot find the file: file_config.txt");
				return false; #die("cannot find the file file_config.txt"); // file queries.sql does not exist
			}
		}
		else
		{
			$this->logError("Cannot connect to database or the database does not exist!");
			return false; //die("cannot connect"); // cannot connect to the db
		}		
	}

	// Run the query for the admin account
	public function thirdStepApply()
	{
		if ($this->_db->createConnection())
		{
			$this->_db->setAdminCredentials( Config::APP_ENCRYPT_PWD );
			clearstatcache(); //die("queries.sql");
			#chmod( dirname(Config::ROOT) . Config::DIR_SEP . "file_account.txt", 777 );

			if (file_exists(dirname(Config::ROOT) . Config::DIR_SEP . "file_account.txt"))
			{
				$todo = $this->_db->parseMuphVariables(file_get_contents("file_account.txt"));
				$this->_db->query( $todo );
				return true;
			}
			else
			{
				$this->logError("Cannot find the file: file_account.txt"); // file queries.sql does not exist
				return false;
			}
		}
		else
		{
			$this->logError("Cannot establish connection!");
			return false;
		}
	}

	/**
	*
	* Create the terms for each required option
	*
	*/
	public function requiring( ) {

		// Server path
		$server_path = explode("/", $_SERVER["SCRIPT_FILENAME"]);
		array_pop($server_path);
		array_pop($server_path);
		$server_path = implode("/", $server_path);

		foreach(Config::$requiredOptions as $option => $value) {
			if( $value ) { // is required?
				$result = $this->hash["OPTION_WRONG"];

				if( $option == "writableDir" && is_writable($server_path . Config::APP_CONFIG_FILE_PATH ) && is_writable($server_path . Config::APP_DB_FILE_PATH ) ) // is about dir?
					$result = $this->hash["OPTION_OK"];

				if( $option == "pdo" && defined('PDO::ATTR_DRIVER_NAME') ) // is about PDO?
					$result = $this->hash["OPTION_OK"];

				if( $option == "curl" && in_array('curl', get_loaded_extensions() ) ) // is about cURL?
					$result = $this->hash["OPTION_OK"];

				if( $option == "gd" && count( gd_info() ) ) // is about gd?
					$result = $this->hash["OPTION_OK"];

				if( $option == "phpMin" && phpversion() >= $value ) // is about php min version?
					$result = $this->hash["OPTION_OK"];

				if( $option == "modRewrite" && in_array('mod_rewrite', apache_get_modules() ) ) // is about apache mod rewrite?
					$result = $this->hash["OPTION_OK"];

				array_push( $this->hash["OPTIONS"], array("OPTION" => $option, "RESULT" => $result ) );
			}				
				
		}

	}

	public function logError( $er ) {
		$_GET['error'] = trim($er);
	}

	public function render() {
		echo $this->tpl->render($this->template, $this->hash);
	}
}

// Server path
$server_path = explode("/", $_SERVER["SCRIPT_FILENAME"]);
array_pop($server_path);
array_pop($server_path);
$server_path = implode("/", $server_path);

// Create the files
$router = new Router( new Mustache_Engine, new Lang, new ControllerDB, new File( Config::APP_CONFIG_FILE, $server_path . Config::APP_CONFIG_FILE_PATH ), new File2( Config::APP_DB_FILE, $server_path . Config::APP_DB_FILE_PATH ) );
?>