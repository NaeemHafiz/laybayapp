<?php
class Config
{
	/* YOUR APP'S CONFIGS */
	const APP_NAME	 		= "SAM - Project Management App"; // put here the name of your app
	const APP_VERS	 		= "1.4.5"; 	// put here the version of your app
	const APP_CONFIG_FILE	= "config.php"; // put here the config file of your app
	const APP_DB_FILE		= "database.php"; // put here the database file of your app
	/*****
	 *
	 * rootMuphFolder + <whatDoYouWant> : leave blank to create the config file inside muph's root folder
	 * const APP_CONFIG_FILE_PATH = "/config"; => rootdirOfMuph/config
	 * const APP_CONFIG_FILE_PATH = ""; => rootdir of muph
	 *
	 */
	const APP_CONFIG_FILE_PATH 	= "/application/config";
	const APP_DB_FILE_PATH 		= "/application/config";

	// Write the php function you wanna use to encrypting the admin pwd into the db
	const APP_ENCRYPT_PWD 	= "md5"; // md5 - sha1 - crc32

	public static $requiredOptions = array(
		'writableDir' 	=> true,
		'phpMin'		=> 5,
		'pdo' 			=> false,
		'gd'  			=> false,
		'curl'			=> false,
		'modRewrite'	=> false
	);

	/* DON'T TOUCH ANYTHING BELOW */
	const DIR_SEP 	= DIRECTORY_SEPARATOR;
	const ROOT 		= __FILE__;
	const TPL_DIR	= "partials";
	#const LANG 		= "0";	// not present before version 2 which is not reached yet

	public static $MUPH = array(
		"author" 		=> "Andrea Paciolla",
		"author_email" 	=> "andreapaciolla@gmail.com",
		"author_web" 	=> "http://www.andreapaciolla.it",
		"version"		=> "1.1",
		"released_on"	=> "1st Oct, 2013"
	);
}
?>