﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'is', {
	fontSize: {
		label: 'Leturstærð ',
		voiceLabel: 'Font Size',
		panelTitle: 'Leturstærð '
	},
	label: 'Leturgerð ',
	panelTitle: 'Leturgerð ',
	voiceLabel: 'Leturgerð '
});
