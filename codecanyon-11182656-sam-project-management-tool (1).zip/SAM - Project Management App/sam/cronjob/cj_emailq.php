<?

// Database connection settings
$db_host = "";
$db_name = "";
$db_user = "";
$db_pass = "";

// Database connection
$connection = mysql_connect($db_host, $db_user, $db_pass);

// Timezone settings
date_default_timezone_set("Europe/Bucharest");

// If could not connect to database, display error and kill process
if (!$connection)
{
	echo "Could not establish connection to database!";
}
else
{
	// Select database
	mysql_select_db($db_name);

	// Fuction to send email
	// Parameters
	//  sender   - email address of sender
	//  receiver - email address of receiver
	//  name  	 - name to be displayed in subject
	//  subject  - email subject
	//  message  - email message
	//
	// Return
	//  1 - if sent
	//  0 - if not sent

	function sendEmail($sender, $receiver, $name, $subject, $message)
	{
		$from = $name." <".$sender.">";

		$headers = "From: ".$from."\r\n";
		$headers .= "Reply-To: ".$sender."\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

		$text = "<html><body>";
		$text .= $message;
		$text .= "</body></html>";

		if (mail($receiver, $subject, $text, $headers))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	// Do send email while we still have emails
	do
	{
		// Query to get all unsent emails
		$query 	= "SELECT * FROM emailq WHERE sent = 'no' AND in_progress = 'no' ORDER BY id LIMIT 1";
		$result = mysql_query($query) or die("Internal error 62 - cj_emailq");

		// Count results
		$num_rows = mysql_num_rows($result);

		// While we have unsent email
		while ($row = mysql_fetch_array($result))
		{
			// Query to update progress of email sending to yes
			$query_update  = "UPDATE emailq SET in_progress = 'yes', process_date = '".date("Y-m-d H:i:s")."' WHERE id = ".$row['id'];
			$result_update = mysql_query($query_update) or die("Internal error 72 - cj_emailq");

			// If updated successfully
			if ($result_update == TRUE)
			{
				// We attempt to send the email
				$result_send = sendEmail($row["from"], $row["to"], $row["name"], $row["subject"], $row["message"]);

				// If email was sent successfully
				if ($result_send == 1)
				{
					// We finally update the sent field in database to yes
					$query_update2  = "UPDATE emailq SET sent = 'yes' WHERE id = ".$row['id'];
					$result_update2 = mysql_query($query_update2) or die("Internal error 85 - cj_emailq");

					// If all is good, insert log message
					if ($result_update2 == TRUE)
					{
						$query_log2 = "INSERT INTO log(operation_date, operation_message) VALUES('".date("Y-m-d H:i:s")."', 'Email (".$row['id'].") sent to ".$row['to']."')";
						mysql_query($query_log2) or die("Internal error 91 - cj_emailq");
					}
				}
			}
		}

		// Time delay of 20 seconds between sending emails
		if ($num_rows > 0)
		{
			sleep(20);
		}
	}

	// We do this while we still have unsent emails
	while ($num_rows > 0);

	// Delete old notifications
	$sql = "DELETE FROM notifications WHERE DATE_ADD(added, INTERVAL 30 DAY) < '".date("Y-m-d H:i:s")."'";
	$result = mysql_query($sql) or die("Internal error 109 - cj_emailq.php");
}

?>